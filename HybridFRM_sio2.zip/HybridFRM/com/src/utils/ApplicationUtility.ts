import { expect, Page } from "@playwright/test";
import { CommanUtility } from "../utils/CommanUtility";
import { Locators } from "../../src/ui/Locators";
import { UserData } from "../../src/ui/TestData/UserData";
import constUtils from "../utils/constutils";
import { PageObjectFactory } from "../ui/pages/PageObjectFactory";
import { faker } from "@faker-js/faker/locale/en";
import { StaticFields } from "../constants/StaticFields";
export default class ApplicationUtility extends CommanUtility {
  public commanUtility: CommanUtility;
  constructor(protected page: Page) {
    super(page);
    //this.commanUtility = new CommanUtility(page);
    this.commanUtility = PageObjectFactory.getInstance(page).getCommanUtility();
  }
  //Click Application reusable
   public async clickUtils(text:string,labelName:string,options?: { timeout?: number }){
    await expect(this.page.locator("(//*[normalize-space()='"+text+"'])[1]")).toBeVisible({timeout:options?.timeout??30000});
    await this.commanUtility.Click("locator","(//*[normalize-space()='"+text+"'])[1]",labelName,options);
  }




  //Enter Application reusable

  public async enterValueUtils(text:string,labelName:string){
    await this.commanUtility.Enter("locator","//label[text()='"+text+"']//parent::div//input",labelName,faker.person.fullName())
  }
  



}
