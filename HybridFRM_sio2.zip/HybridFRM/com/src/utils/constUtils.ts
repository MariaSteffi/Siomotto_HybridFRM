export default class constUtils {
  public static application = "Applications";
  public static actionMaster = "Action Master";
  public static templateHub = "Templates Hub";
  public static actionPlan = "Action Plan";
}
