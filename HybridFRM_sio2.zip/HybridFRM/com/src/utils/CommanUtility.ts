import test, { ElementHandle, expect, Locator, Page, TestInfo } from "@playwright/test";
import * as allure from "allure-js-commons";
//import { step, attachment } from 'allure-js-commons';

// @ts-ignore
import path from "path";
import { BasePage } from "../Base/Base";
type LocatorType = "label" | "text" | "locator" | "alttext" | "placeholder";
export class CommanUtility  extends BasePage{
  private Element!: Locator;
  public reporter :any;
   
   





  constructor(protected  page: Page) {
    super(page); 
  }
  private LocateElement(Locator: string,options?:{timeout?:number}) {
    return this.page.locator(Locator);
  }

  public async networkLoad(){
    await this.page.waitForLoadState('networkidle');
  }
  public async ChainInput(locator1: string, locator2: string,text:string,IntractiveElement:string,options?:{timeout?:number}): Promise<void> {
    try{
     const Element =this.page.locator(locator1).locator(locator2);
     await this.stepWithScreenshot(`Entered the ${text} in the ${IntractiveElement} `,async ()=>{
                  await Element.fill(text);
                  console.log(`Entered the ${text} in the ${IntractiveElement}`)
          } );
    }catch(error){
         throw new Error(`The run time error was ${error}`)
    }
  }

  public async pause(){
    await this.page.pause();
  }
  public async watforNetwork(sec? :number){
     await this.page.waitForLoadState("networkidle");
     await this.page.waitForLoadState("domcontentloaded");
     await this.page.waitForTimeout(sec??10); // allow initial calls

  }

  public async waitforfun(locator: string) {
  await this.page.waitForFunction(
    (xpath) => {
      const result = document.evaluate(
        xpath,
        document,
        null,
        XPathResult.ORDERED_NODE_SNAPSHOT_TYPE,
        null
      );
      return result.snapshotLength > 0;
    },
    locator, // 👈 passed explicitly
    { timeout: 15000 }
  );
}
  public async Click(
  locatorType: string,
  locatorValue: string,
  LabelName: string,
  options?: { timeout?: number; force?: boolean }
): Promise<void> {
  try {
    const locatorMap: Record<string, () => any> = {
      label: () => this.page.getByLabel(locatorValue),
      text: () => this.page.getByText(locatorValue),
      locator: () => this.LocateElement(locatorValue),
      alttext: () => this.page.getByAltText(locatorValue),
      placeholder: () => this.page.getByPlaceholder(locatorValue),
    };

    const getElement = locatorMap[locatorType.toLowerCase()];

    if (!getElement) {
      throw new Error(`Invalid locator type: ${locatorType}`);
    }

    this.Element = getElement();
    await this.Element.waitFor({ state: "visible", timeout: options?.timeout });
    await this.stepWithScreenshot(`Clicked on ${LabelName}`, async () => {
      await this.Element.click(options);
      console.log(`Clicked on ${LabelName}`);
    });

  } catch (error) {
    console.error(`Failed to click on element: ${LabelName}`, error);
    throw new Error(`Runtime exception while clicking '${LabelName}': ${error}`);
  }
}
 public async doubleClick(
  locatorType: string,
  locatorValue: string,
  interactiveElement: string,
  options?: { timeout?: number; force?: boolean }
): Promise<void> {
  try {
    const locatorMap: Record<string, () => any> = {
      label: () => this.page.getByLabel(locatorValue),
      text: () => this.page.getByText(locatorValue),
      locator: () => this.LocateElement(locatorValue),
      alttext: () => this.page.getByAltText(locatorValue),
      placeholder: () => this.page.getByPlaceholder(locatorValue),
    };

    const getElement = locatorMap[locatorType.toLowerCase()];

    if (!getElement) {
      throw new Error(`Invalid locator type: ${locatorType}`);
    }

    this.Element = getElement();

    await this.stepWithScreenshot(
      `Double Clicked on ${interactiveElement}`,
      async () => {
        await this.Element.dblclick(options);
        console.log(`Double Clicked on ${interactiveElement}`);
      }
    );

  } catch (error) {
    console.error(`Failed to double click on element: ${interactiveElement}`, error);
    throw new Error(
      `Runtime exception while double-clicking '${interactiveElement}': ${error}`
    );
  }
}

  public async clickByRole(Role: any, roleValue: string, IntractiveElement: string, options?: { timeout?: number; force?: boolean }) {
    try {
      this.Element = this.page.getByRole(Role, { name: roleValue });
      await this.stepWithScreenshot(`Clicked on ${IntractiveElement}`,async ()=>{
                  await this.Element.click(options);
                 console.log(`Clicked on ${IntractiveElement}`)
                   } );
    } catch (error) {
      console.error(`Failed to click on element:${IntractiveElement}`);
      throw new Error(`This is a runtime exception. ${error}`);
    }
  }
  public async InputByRoleBased(
    Role: any,
    value: string,
    IntractiveElement: string,
    InputValue: string,
    options?: { timeout?: number; force?: boolean }
  ): Promise<void> {
    try {
      this.Element = this.page.getByRole(Role, { name: value });
       await this.stepWithScreenshot(`Entered the ${IntractiveElement}`,async ()=>{
                 await  this.Element.fill(InputValue, options);
                 console.log(`Entered the ${IntractiveElement}`)
                   } );
      
    } catch (error) {
      console.error(`Failed to click on element:${IntractiveElement}`);
      throw new Error(`This is a runtime exception. ${error}`);
    }
  }


  
 public async pressBySequence(
  locatorType: string,
  locatorValue: string,
  interactiveElement: string,
  inputValue: string,
  options?: { timeout?: number; force?: boolean }
): Promise<void> {
  try {
    const locatorMap: Record<string, () => any> = {
      label: () => this.page.getByLabel(locatorValue),
      text: () => this.page.getByText(locatorValue),
      locator: () => this.LocateElement(locatorValue),
      alttext: () => this.page.getByAltText(locatorValue),
      placeholder: () => this.page.getByPlaceholder(locatorValue),
    };

    const getElement = locatorMap[locatorType.toLowerCase()];

    if (!getElement) {
      throw new Error(`Invalid locator type: ${locatorType}`);
    }

    this.Element = getElement();

    await this.stepWithScreenshot(
      `Entered '${inputValue}' in ${interactiveElement}`,
      async () => {
        await this.Element.pressSequentially(inputValue, options);
        console.log(`Entered '${inputValue}' in ${interactiveElement}`);
      }
    );

  } catch (error) {
    console.error(`Failed to enter value in element: ${interactiveElement}`, error);
    throw new Error(
      `Runtime exception while entering value in '${interactiveElement}': ${error}`
    );
  }
}
  
// Add strict typing for locator types


public async Enter(
  locatorType: LocatorType,
  locatorValue: string,
  interactiveElement: string,
  inputValue: string,
  options?: { timeout?: number; force?: boolean },
  index?: number
): Promise<String> {
  try {
    const locatorMap: Record<LocatorType, () => Locator> = {
      label: () => this.page.getByLabel(locatorValue),
      text: () => this.page.getByText(locatorValue),
      locator: () => this.LocateElement(locatorValue),
      alttext: () => this.page.getByAltText(locatorValue),
      placeholder: () => this.page.getByPlaceholder(locatorValue),
    };

    const getElement = locatorMap[locatorType];

    if (!getElement) {
      throw new Error(
        `Unsupported locator type: ${locatorType}. Allowed: label, text, locator, alttext, placeholder`
      );
    }

    let element = getElement();

    // Apply index if provided
    if (typeof index === "number") {
      element = element.nth(index);
    }

    await this.stepWithScreenshot(
      `Entered '${inputValue}' in ${interactiveElement}`,
      async () => {
        await element.clear();
        await element.fill(inputValue, options);
        console.log(`Entered '${inputValue}' in ${interactiveElement}`);
      }
    );

  } catch (error) {
    console.error(`Failed to enter value in ${interactiveElement}`, error);
    throw new Error(
      `Runtime exception while entering value in '${interactiveElement}': ${String(error)}`
    );
  }
  return inputValue;
}


  public async FileUplad(
    selector: string,
    InputValue: string,
    labelName: string,
    options?: { timeout?: number; force?: boolean }
  ): Promise<void> {
    try {
      // If the selector is a string, use page.locator
      const element = this.LocateElement(selector);
      await this.stepWithScreenshot(`Uploaded the file '${InputValue}' under '${labelName}'`,async ()=>{
        await element.setInputFiles(
        path.join("./com/test/Resources/Upload", InputValue),
        options
      );
      console.log(`Uploaded the file '${InputValue}' under '${labelName}'`)
      } );
    
    } catch (error) {
      console.error(`Failed to Upload value: ${labelName}`);
      throw new Error(`This is a runtime exception. ${error}`);
    }
  }

  public async getAttribute(
    selector: string,
    tagName: string,
    options?: { timeout?: number }
  ): Promise<string | null> {
    try {
      let Attribute =  this.page.getAttribute(selector, tagName, options);
      console.log(`Attribute value captured: ${Attribute}`);
      return Attribute;
    } catch (e) {
      throw new Error(`This is a runtime exception. ${e}`);
    }
  }
  public async AssertEquals(value:string,expectedValue:string):Promise<void>{
    await this.stepWithScreenshot(`Asserting the value ${value} with expected value ${expectedValue}`,async ()=>{
     expect(value).toBe(expectedValue);
     console.log(`Asserting the value ${value} with expected value ${expectedValue}`);
    } );
  }

public async getText(
  locatorType: LocatorType,
  locatorValue: string,
  labelName: string,
  options?: { timeout?: number; force?: boolean }
): Promise<string> {
  try {
    const locatorMap: Record<LocatorType, () => Locator> = {
      label: () => this.page.getByLabel(locatorValue),
      text: () => this.page.getByText(locatorValue),
      locator: () => this.LocateElement(locatorValue),
      alttext: () => this.page.getByAltText(locatorValue),
      placeholder: () => this.page.getByPlaceholder(locatorValue),
    };

    const getElement = locatorMap[locatorType];

    if (!getElement) {
      throw new Error(
        `Unsupported locator type: ${locatorType}. Allowed: label, text, locator, alttext, placeholder`
      );
    }

    this.Element = getElement();

    let text = "";

    await this.stepWithScreenshot(
      `Captured the text from ${labelName}`,
      async () => {
        text = (await this.Element.textContent(options))?.trim() ?? "";
        console.log(`Captured the text from ${labelName}: ${text}`);
      }
    );

    return text;

  } catch (error) {
    console.error(`Failed to capture text from element: ${labelName}`, error);
    throw new Error(
      `Runtime exception while capturing text from '${labelName}': ${String(error)}`
    );
  }
}
  async TypeHeadDropdownQuickFix(
    EnterSelector: string,
    DropdownSelector: string,
    InputValue: string,
    labelName: string,
    options?: { timeout?: number; delay?: number }
  ): Promise<void> {
    try {
      let element: Locator = this.LocateElement(EnterSelector);

      await element.pressSequentially(InputValue, options);
      const option = this.LocateElement(DropdownSelector).nth(0);
      await expect(option).toContainText(InputValue,{timeout:60000});
      let element1: Locator = this.LocateElement(DropdownSelector);
      let cot = await element1.count();
      
     
       for (let i = 0; i < cot; i++) {
        const text = await element1.nth(i).textContent();
        console.log(`text captured : ${text}`);
        if (text?.includes(InputValue)) {
          
         await this.stepWithScreenshot(`${InputValue} Selected in the ${labelName}`,async ()=>{
                  await element1.nth(i).click(options);
                 console.log(`${InputValue} Selected in the ${labelName}`)
                   } );
          
          break;
        }
      }
      
    } catch (e) {
      throw new Error(`This is a runtime exception. ${e}`);
    }
  }

  async TypeHeadDropdown(
    EnterSelector: string,
    DropdownSelector: string,
    InputValue: string,
    labelName: string,
    options?: { timeout?: number; delay?: number }
  ): Promise<void> {
    try {
      let element: Locator = this.LocateElement(EnterSelector);
       await expect(element).toBeVisible({timeout:60000});
      await element.pressSequentially(InputValue, options);
      let element1: Locator = this.LocateElement(DropdownSelector);
      const loading = element1.filter({ hasText: "Loading..." });
      await loading.waitFor({ state: 'hidden' });
      let cot = await element1.count();
     await element1.first().waitFor({ state: 'attached', timeout: 60000 }); // added
      console.log(`Total count is : ${cot}`);
      //await this.watforNetwork(20000);
      await this.sleep(2000);
      for (let i = 0; i < cot; i++) {
        const text = await element1.nth(i).textContent();

        console.log(`text captured : ${text}`);
        if (text??"no data".includes(InputValue)) {
          
         await this.stepWithScreenshot(`${InputValue} Selected in the ${labelName}`,async ()=>{
                  await element1.nth(i).click(options);
                 console.log(`${InputValue} Selected in the ${labelName}`)
                   } );
          
          break;
        }
      }
    } catch (e) {
      throw new Error(`This is a runtime exception. ${e}`);
    }
  }
  async TypeHeadRandomSelect(
    ClickDropDown: string,
    DropdownSelector: string,
    InputValue: string,
    labelName: string,
    options?: { timeout?: number }
  ): Promise<void> {
    try {
      let element: Locator = this.LocateElement(ClickDropDown);
      await element.pressSequentially(InputValue, { delay: 150 });
      await this.page.waitForSelector(DropdownSelector);
       await this.stepWithScreenshot(`Random value got selected in the ${labelName}`,async ()=>{
        await this.page.waitForTimeout(3000);
                  await this.LocateElement(DropdownSelector).first().click(options);
                 console.log(`Random value got selected in the ${labelName}`)
                   } );
      
      console.log(`User Randomly selected the value in ${labelName}`);
    } catch (e) {
      throw new Error(`This is a runtime exception. ${e}`);
    }
  }

  async RandomSelection(
    selector: string,
    labelName: string,
    options?: { timeout?: number; force?: boolean }
  ): Promise<void> {
    try {
     await this.page.waitForSelector(selector,{state:'visible'});
        await this.stepWithScreenshot(`Random value got selected in the ${labelName}`,async ()=>{
          const option = this.LocateElement(selector).nth(2);
       await expect(option).toBeVisible({timeout:60000});
       await expect(option).not.toHaveCount(0,{timeout:60000});
         await this.LocateElement(selector).first().click(options);
      console.log(`User Randomly selected the value in ${labelName}`);
                   } );
     
    } catch (e) {
        await this.stepWithScreenshot(`Can't select Random value of ${labelName}`,async ()=>{
         throw new Error(`This is a runtime exception. ${e}`);
                   } );
     
    }
  }
   public async toggleButton(locator:string,attribute:string,labelName:string):Promise<void>{
    const att= await this.LocateElement(locator).getAttribute(attribute);
    if(att?.trim()!==""&& att==="false"){
        await this.stepWithScreenshot(`Clicked on the  ${labelName} toggle button`,async ()=>{
        await this.Click("locator",locator,labelName);
                 console.log(`Clicked on the  ${labelName} toggle button`)
                   } );
     

    }else{
      await this.stepWithScreenshot(`  ${labelName} is Already checked`,async ()=>{
               console.log(labelName+" is Already checked");
                   } );
      
    }
    
    
  }
  public async checkAndToggle(locator:string,locator1:string,attribute:string,labelName:string):Promise<void>{
    const att= await this.LocateElement(locator).getAttribute(attribute);
    if(att?.trim()!==""&& att==="false"){
        await this.stepWithScreenshot(`Clicked on the  ${labelName} toggle button`,async ()=>{
        await this.Click("locator",locator1,labelName);
                 console.log(`Clicked on the  ${labelName} toggle button`)
                   } );
     

    }else if(att?.trim()!==""&& att==="true"){
         await this.stepWithScreenshot(`${labelName} is Already checked now unchecking `,async ()=>{
        await this.Click("locator",locator1,labelName);
                 console.log(`${labelName} is Already checked now unchecking`);
                   } );
      
    }else{
      await this.stepWithScreenshot(`  ${labelName} is Already checked`,async ()=>{
               console.log(labelName+" is Already checked");
                   } );

    }
    
    
  }

  public async dragAndDrop(sourceElement:string ,TargetElement :string, labelName:string,option?:{timeout?:number}){
  try {
    await this.sleep(3000);
    const source =this.LocateElement(sourceElement)
    const Target =this.LocateElement(TargetElement).nth(0);
    await this.stepWithScreenshot(`Dragged and  Droped in ${labelName}`,async ()=>{
         
          source.dragTo(Target,option);
                   console.log(`Dragged and  Droped in ${labelName}`);
                     } );
  } catch (err) {
    await this.stepWithScreenshot(`There was run time error in  ${labelName}`,async ()=>{
      throw new Error(`There was run time error in  ${labelName}`)
                     } );
    
  }

  }
   public async ExactDropDown(clickDropDown:string,selector: string,DDValue:string ,InteractiveElement:string,options?: { timeout?: number }) {
   const Element = this.page.locator(clickDropDown);
    await this.stepWithScreenshot(`Clicked on ${InteractiveElement}`,async ()=>{
                  await Element.click(options);
                  // await this.sleep(5000);
                  console.log(`Clicked on ${InteractiveElement}`)
          } );
    let count = await this.page.locator(selector).count();
    for (let i = 0; i <= count; i++) {
     const text:string|null = await this.page.locator(selector).nth(i).textContent();
     console.log(`Dropdown text is : ${text} and Expected text is : ${DDValue}`);
     if(text?.trim() === DDValue){
       await this.stepWithScreenshot(`${DDValue} Selected in the ${InteractiveElement}`,async ()=>{
                 await this.page.locator(selector).nth(i).click();
                 console.log(`${DDValue} Selected in the ${InteractiveElement}`)
                   } );
                   break;  

     }
    }
  }

  public async DropDown(clickDropDown:string,selector: string,DDValue:string ,InteractiveElement:string,options?: { timeout?: number }) {
   const Element = this.page.locator(clickDropDown);
   
    await this.stepWithScreenshot(`Clicked on ${InteractiveElement}`,async ()=>{
                  await Element.click(options);
                  // await this.sleep(5000);
                  console.log(`Clicked on ${InteractiveElement}`)
          } );
       const option = this.LocateElement(selector).nth(2);
    await option.first().waitFor({ state: 'attached', timeout: 60000 });
    let count = await this.page.locator(selector).count();
    for (let i = 0; i <= count; i++) {
     const text:string|null = await this.page.locator(selector).nth(i).textContent();
     if(text?.toLowerCase()?.includes(DDValue.toLowerCase())){
       await this.stepWithScreenshot(`${DDValue} Selected in the ${InteractiveElement}`,async ()=>{
                 await this.page.locator(selector).nth(i).click();
                 console.log(`${DDValue} Selected in the ${InteractiveElement}`)
                   } );
                   break;  

     }
    }
  }
  public async DropDown1(clickDropDown:string,selector: string,DDValue:string ,InteractiveElement:string,options?: { timeout?: number }) {
   const Element = this.page.locator(clickDropDown);
   
    await this.stepWithScreenshot(`Clicked on ${InteractiveElement}`,async ()=>{
                  await Element.click(options);
                  // await this.sleep(5000);
                  console.log(`Clicked on ${InteractiveElement}`)
          } );
       const option = this.LocateElement(selector);
      //  await expect(option).toBeVisible({timeout:60000});
      //  await expect(option).not.toHaveCount(0,{timeout:60000});
      await option.first().waitFor({ state: 'attached', timeout: 60000 });
    let count = await this.page.locator(selector).count();
    for (let i = 0; i < count; i++) {
     const text:string|null = await this.page.locator(selector).nth(i).textContent();
    console.log(DDValue);
     if(text?.trim() === DDValue.trim()){
       console.log(text);
       await this.stepWithScreenshot(`${DDValue} Selected in the ${InteractiveElement}`,async ()=>{
                 await this.page.locator(selector).nth(i).click();
                 console.log(`${DDValue} Selected in the ${InteractiveElement}`)
                 
                   } );
                   break;
                  

     }
    }
  }
  public async sleep(millisecond: number):Promise<void> {
    await this.page.waitForTimeout(millisecond);
  }

  public async getDateValidater(label: string):Promise<string>{
   const monthMap: Record<string, number> = {
    Jan: 1,
    Feb: 2,
    Mar: 3,
    Apr: 4,
    May: 5,
    Jun: 6,
    Jul: 7,
    Aug: 8,
    Sep: 9,
    Oct: 10,
    Nov: 11,
    Dec: 12,
  };
  const locator =`(//label[text()='${label}']//parent::div//div)[1]`;
  const text =await this.getText("locator",locator,label);
  console.log("The captured date is  :"+text);
 let str = text.split(" ");
 const month =monthMap[str[1]];
 const date =str[2];
 const year =str[3];
 const formattedDate = `${date.padStart(2, '0')}-${month.toString().padStart(2, '0')}-${year}`;
return formattedDate;
}  


  public async AutomaticDatePicker(clickDatePicker: string,captureMonthText: string,leftArrow: string,rightArrow: string,labelName: string,userInput:string) {
  //const userInput = "28-04-2026";
  console.log("The user input date is  :"+userInput);
  const [dayStr, monthStr, yearStr] = userInput.split("-");
  const targetDay = parseInt(dayStr);
  const targetMonth = parseInt(monthStr);
  const targetYear = parseInt(yearStr);
  const finaldate = `${targetDay.toString().padStart(2, '0')}-${targetMonth.toString().padStart(2, '0')}-${targetYear}`;

  const monthMap: Record<string, number> = {
    January: 1,
    February: 2,
    March: 3,
    April: 4,
    May: 5,
    June: 6,
    July: 7,
    August: 8,
    September: 9,
    October: 10,
    November: 11,
    December: 12,
  };

  await this.page.locator(clickDatePicker).click();

  while (true) {
    const text = await this.page.locator(captureMonthText).first().textContent();
    if (!text) throw new Error("Could not retrieve month/year text");

    const [currentMonthStr, currentYearStr] = text.trim().split(" ");
    const currentYear = parseInt(currentYearStr);
    const currentMonth = monthMap[currentMonthStr];

    if (currentYear === targetYear && currentMonth === targetMonth) {
      await this.selectDate(targetDay, labelName);
      await this.sleep(1000);
      const formattedDate = await this.getDateValidater(labelName);
      console.log("The selected date is  :"+formattedDate  +" and User input date is :"+finaldate);
      if(formattedDate !==finaldate){
        await this.AutomaticDatePicker(clickDatePicker,captureMonthText,leftArrow,rightArrow,labelName,userInput);
           expect(formattedDate).toBe(userInput);
      }
      break;
    }

    if (currentYear > targetYear || (currentYear === targetYear && currentMonth > targetMonth)) {
      await this.page.locator(leftArrow).first().click();
   
    } else {
      await this.page.locator(rightArrow).first().click();
    }
  }
}

public async selectDate(day: number, labelName: string) {
  for (let i = 1; i <= 6; i++) {
    for (let j = 1; j <= 7; j++) {
      const dayCell = this.page.locator(
        `//label[contains(text(),'${labelName}')]//parent::div//following-sibling::div` +
        `//div//div[@class='datepicker-days']//tbody//tr[${i}]//td[${j}][@class='day' or @class='day weekend']`
      );
      if(await dayCell.count() ==0){
        continue;
      }

      const dayText = await dayCell.textContent();
      if (parseInt(dayText || "") === day) {
        await this.page.locator(
          `//label[contains(text(),'${labelName}')]//parent::div//following-sibling::div` +
          `//div//div[@class='datepicker-days']//tbody//tr[${i}]//td[${j}][@class='day' or @class='day weekend']`
        ).click();
        console.log(" User clicked on "+labelName + "in " + dayText);

        
        return;
      }
    }
  }

  throw new Error(`Day ${day} not found in date picker`);
}

public async getListOfText(selector:string,text:string,options?:{timeout?:number,force?:boolean}):Promise<string|null>{
  const getText= this.page.locator(selector).filter({ hasText: text });
  const ActualText =await getText.textContent(options);
  console.info(ActualText);
  return ActualText;
}
public async clickOnSpecificGirdValue(selector:string,text:string,options?:{timeout?:number,force?:boolean}):Promise<string|null>{
   let actualText: string | null = null;
  try {
    
    //  await expect.poll(async () => {
    //   const condition =  this.page.locator(selector).first().isVisible(options);
    //   return condition;
    // },{ timeout: 190000, intervals: [1000] }).toBe(true);
    
    // const option = this.LocateElement(selector).nth(1);
    //    await expect(option).toBeVisible({timeout:60000});
    const condition =  this.page.locator(selector).first().isVisible(options);
    if(await condition){
    const Element= this.page.locator(selector).filter({ hasText: text });
     actualText =await Element.textContent();
    if(actualText ===text){
       await this.stepWithScreenshot(`clicked on the  ${text} `,async ()=>{
                   await Element.dblclick(options);
                 console.log(`clicked on the  ${text} `)
                   } );
        
    }
  }else{
    await this.pause();
  }
    
   
  } catch (err) {
    console.error(`Error clicking on grid value "${text}":`, err)
  }
   return actualText;
}
public async clickOnFirstIndex(selector:string,text:string,options?:{timeout?:number,force?:boolean}):Promise<void>{
  try {

       await this.stepWithScreenshot(`clicked on the  ${text} `,async ()=>{
                   const Element= this.page.locator(selector+`[1]`);
                   await Element.click(options);
                 console.log(`clicked on the  ${text} `)
                   } );
        
    
    
   
  } catch (err) {
    console.error(`Error clicking on First index "${text}":`, err);
  }
}
public async clickOnSpecificIndex(selector:string,text:string,options?:{timeout?:number,force?:boolean}):Promise<void>{
  try {
    const option = this.LocateElement(selector).nth(1);
       await expect(option).toBeVisible({timeout:60000});
      const length= await this.page.locator(selector).count();
      for(let i=0;i<length;i++){
        const Element= this.page.locator(selector).nth(i);
        const actualText =await Element.textContent();
        if(actualText === text){
          await this.stepWithScreenshot(`clicked on the  ${text} `,async ()=>{
                     await Element.click();
                   console.log(`clicked on the  ${text} `)
                     } );
          break;
        }
      }
        
    
    
   
  } catch (err) {
    console.error(`Error clicking on First index "${text}":`, err);
  }
}
public async EnterOnFirstIndex(selector:string,InputValue:string ,text:string,options?:{timeout?:number,force?:boolean}):Promise<void>{
  try {

       await this.stepWithScreenshot(`clicked on the  ${text} `,async ()=>{
                   const Element= this.page.locator(selector).nth(1);
                   await Element.fill(InputValue);
                 console.log(`clicked on the  ${text} `)
                   } );
        
    
    
   
  } catch (err) {
    console.error(`Error clicking on First index "${text}":`, err);
  }
}

public async clickOnSpecificGirdValueIndex(selector:string,text:string,options?:{timeout?:number,force?:boolean}):Promise<string|null>{
   let actualText: string | null = null;
  try {
    const Element= this.page.locator(selector).filter({ hasText: text }).nth(1);
    console.log(Element);
     actualText =await Element.textContent();
    if(actualText ===text){
       await this.stepWithScreenshot(`clicked on the  ${text} `,async ()=>{
                   await this.page.locator(selector).nth(1).dblclick({timeout:30000});
      
                 console.log(`clicked on the  ${text} `)
                   } );
        
    }
    
   
  } catch (err) {
    console.error(`Error clicking on grid value "${text}":`, err)
  }
   return actualText;
}


public async radioButton(selector:string,getAttributeElement:string,ExpectedValue:string,options?:{timeout:number}):Promise<void>{
    try {
      await this.LocateElement(getAttributeElement).getAttribute("class",options).then(async (clas) => {
        if (clas?.includes("checked")) {
            await this.stepWithScreenshot(`The ${ExpectedValue} is already selected`,async ()=>{
          console.log(`The ${ExpectedValue} is already selected`);
                    } );  
        } else {
          await this.stepWithScreenshot(`Selected the ${ExpectedValue} radio button`,async ()=>{
                   await this.LocateElement(selector).click(options);
                 console.log(`Selected the ${ExpectedValue} radio button`)
                   } );
        } 
      });
    } catch (err) {
      console.error(`Error on Selecting the radio button "${ExpectedValue}":`, err);
    }   
  }


  public async checkFromListOfElement(selector:string,ExpectedValue:string,options?:{timeout:number}):Promise<boolean>{
     let isDisplayed = false;
    try {
      await this.LocateElement(selector).first().waitFor({ state: 'visible', timeout: options?.timeout ?? 30000 });
     //await locator.first().waitFor({ state: 'visible', timeout });
      await this.stepWithScreenshot(`Expected ${ExpectedValue} is displayed `,async ()=>{
      isDisplayed = await this.LocateElement(selector).filter({ hasText: ExpectedValue }).isVisible(options);
        //console.log(`Expected ${ExpectedValue} is displayed : ${isDisplayed}`);
      } );
       
    } catch (err) {
       console.error(`Error on Finding Elements "${ExpectedValue}":`, err);
    }
    return isDisplayed;
  }

//new adition
 public async ListOfElements(selector:string,ExpectedValue:string,options?:{timeout:number}):Promise<boolean>{
     let isDisplayed = false;
    try {
      await this.LocateElement(selector).first().waitFor({ state: 'visible', timeout: options?.timeout ?? 30000 });
     //await locator.first().waitFor({ state: 'visible', timeout });
      await this.stepWithScreenshot(`Expected ${ExpectedValue} is displayed `,async ()=>{
      isDisplayed = await this.LocateElement(selector).filter({ hasText: ExpectedValue }).isVisible(options);
        console.log(`Expected ${ExpectedValue} is displayed : ${isDisplayed}`);
      } );
       
    } catch (err) {
       console.error(`Error on Finding Elements "${ExpectedValue}":`, err);
    }
    return isDisplayed;
  }


  public async ElementDisplayed(selector :string,Message:string,options?:{timeout:number}){

        await this.stepWithScreenshot(`Expected ${Message} is displayed `,async ()=>{
          try {
                    await expect(this.page.locator(selector)).toBeVisible(options);
                   console.log(`Expected ${Message} is displayed`)
                    } catch (e) {
                      await this.stepWithScreenshot(`Expected ${Message} is not displayed `,async ()=>{
                          console.error(`Expected "${Message}" is not visible`);  
                      });
                      throw e;
                    } 
                     } );
    
   

  }

   public async AssertTrue(Message:boolean,Labelname:string){
        await this.stepWithScreenshot(`Expected ${Labelname} is displayed `,async ()=>{
          try {
                   expect(Message).toBe(true);
                   console.log(`Expected ${Labelname} is displayed`)
                 } catch (e) {
                  await this.stepWithScreenshot(`Expected ${Labelname} is not visible `,async ()=>{
                     console.error(`Expected "${Labelname}" is not visible`);
                  });
                    throw e;
                 }
               
                     } );
      
   

  }
   public async AssertFalse(Message:boolean,Labelname:string){
        await this.stepWithScreenshot(`Expected ${Labelname} is not displayed `,async ()=>{
          try {
                   expect(Message).toBe(false);
                   console.log(`Expected ${Labelname} is notdisplayed`)
                 } catch (e) {
                  await this.stepWithScreenshot(`Expected ${Labelname} is  visible `,async ()=>{
                     console.error(`Expected "${Labelname}" is  visible`);
                  });
                    throw e;
                 }
               
                     } );
      
   

  }

  

  public async Equals(ExpectedMessage:string|null,ActualMessage:string,options?:{timeout:number}){
    await this.stepWithScreenshot(`Expected ${ExpectedMessage}  and the ${ActualMessage}is same `,async ()=>{
       try {
                  expect(ExpectedMessage).toContain(ActualMessage);
                 console.log(`Expected "${ExpectedMessage} " and the "${ActualMessage}" is same`)
                 } catch (e) {
                  await this.stepWithScreenshot(`Expected ${ExpectedMessage}  and the ${ActualMessage} is not same `,async ()=>{
                     console.error(`Expected "${ExpectedMessage} " and the "${ActualMessage}" is not same`);
                  });
                    throw e;
                  }
                   } );

  }
   public async haveText(ExpectedMessage:Locator,ActualMessage:string,options?:{timeout:number}){
    await this.stepWithScreenshot(`${ActualMessage}is displayed `,async ()=>{
                  expect(ExpectedMessage).toHaveText(ActualMessage,options);
                 console.log(` ${ActualMessage} is displayed`)
                   } );

  }

  public async LoopClick(selector:string,IntractiveElement:string){
   const count1 = await this.LocateElement(selector).count();
   for(let i=0;i<count1;i++){
    const isDsiplayed =await this.LocateElement(selector).nth(i).isVisible();
    console.log(isDsiplayed);
    if(isDsiplayed){
     
     await this.stepWithScreenshot(`Clicked on ${IntractiveElement}`,async ()=>{
        await this.LocateElement(selector).nth(i).click();
        console.log(`Clicked on ${IntractiveElement}`)
        } );
        break;
    }

   }

  }
   public async  stepWithScreenshot<T>(name: string,stepFn: () => Promise<T>): Promise<T> {
  return await allure.step(name, async () => {
    const result = await stepFn();
     const time =this.getFormattedDateTime();
    const screenshot = await this.page.screenshot({ path: `screenshots/${name}_${time}.png`, fullPage: false });
    allure.attachment(`${name} - Screenshot_`, screenshot, 'image/png');

    return result;
  });
}

 


  public getFormattedDateTime(): string {
  const now = new Date();

  const year = now.getFullYear();
  const month = String(now.getMonth() + 1).padStart(2, '0'); // Months are 0-based
  const day = String(now.getDate()).padStart(2, '0');

  const hours = String(now.getHours()).padStart(2, '0');
  const minutes = String(now.getMinutes()).padStart(2, '0');
  const seconds = String(now.getSeconds()).padStart(2, '0');

  return `${month}_${day}_${year}_${hours}_${minutes}_${seconds}`;
}
 public testDataTimeStamp(): string {
  const now = new Date();

  const year = now.getFullYear();
  const month = String(now.getMonth() + 1).padStart(2, '0'); // Months are 0-based
  const day = String(now.getDate()).padStart(2, '0');

  const hours = String(now.getHours()).padStart(2, '0');
  const minutes = String(now.getMinutes()).padStart(2, '0');
  const seconds = String(now.getSeconds()).padStart(2, '0');

  return `_${minutes}_${day}_${month}_${year}`;
}

  public async refreshPage() {
        await this.page.reload();
    }

  public async DropDownZeroIndex(clickDropDown:string,selector: string,DDValue:string ,InteractiveElement:string,options?: { timeout?: number }) {
   const Element = this.page.locator(clickDropDown);
   
    await this.stepWithScreenshot(`Clicked on ${InteractiveElement}`,async ()=>{
                  await Element.click(options);
                  // await this.sleep(5000);
                  console.log(`Clicked on ${InteractiveElement}`)
          } );
       const option = this.LocateElement(selector);
      // await expect(option).toBeVisible({timeout:60000});
       await expect(option).not.toHaveCount(0,{timeout:60000});
    let count = await this.page.locator(selector).count();
    for (let i = 0; i <= count; i++) {
     const text:string|null = await this.page.locator(selector).nth(i).textContent();
     if(text?.toLowerCase()===(DDValue.toLowerCase())){
       await this.stepWithScreenshot(`${DDValue} Selected in the ${InteractiveElement}`,async ()=>{
                 await this.page.locator(selector).nth(i).click();
                 console.log(`${DDValue} Selected in the ${InteractiveElement}`)
                   } );
                   break;  

     }
    }
  }

  public async clearValues(locator:string):Promise<void>{
    try {
      await this.page.locator(locator).clear();
    } catch (err) {
      console.error(err);
    }
  }

   async TypeHeadStrickDropdown(
    EnterSelector: string,
    DropdownSelector: string,
    InputValue: string,
    labelName: string,
    options?: { timeout?: number; delay?: number }
  ): Promise<void> {
    try {
      let element: Locator = this.LocateElement(EnterSelector);
       await expect(element).toBeVisible({timeout:60000});
      await element.pressSequentially(InputValue, options);
      let element1: Locator = this.LocateElement(DropdownSelector);
      await expect(element1).toBeVisible({timeout:60000});
      await expect(element1).not.toHaveCount(0,{timeout:60000});
      let cot = await element1.count();
      console.log(`Total count is : ${cot}`);
      //await this.watforNetwork(20000);
      await this.sleep(2000);
      for (let i = 0; i < cot; i++) {
        const text = await element1.nth(i).textContent();

        console.log(`text captured : ${text}`);
        if (text ===InputValue) {
          
         await this.stepWithScreenshot(`${InputValue} Selected in the ${labelName}`,async ()=>{
                  await element1.nth(i).click(options);
                 console.log(`${InputValue} Selected in the ${labelName}`)
                   } );
          
          break;
        }
      }
    } catch (e) {
      throw new Error(`This is a runtime exception. ${e}`);
    }
  }





/*keerthana added just to test the dd value--*/


async TypeHeadDropdown1(
  EnterSelector: string,
  DropdownSelector: string,
  InputValue: string,
  labelName: string,
  options?: { timeout?: number; delay?: number }
): Promise<void> {
  try {

    let element: Locator = this.LocateElement(EnterSelector);

    await expect(element).toBeVisible({ timeout: 60000 });

    await element.pressSequentially(InputValue, options);

    let element1: Locator = this.LocateElement(DropdownSelector);

    const loading = element1.filter({ hasText: "Loading..." });

    await loading.waitFor({ state: "hidden" });

    await this.sleep(2000);

    const cot = await element1.count();

    console.log(`Total count is : ${cot}`);

    for (let i = 0; i < cot; i++) {

      const text = (await element1.nth(i).textContent()) ?? "";

      console.log(`text captured : ${text}`);

      if (text.includes(InputValue)) {

        await this.stepWithScreenshot(
          `${InputValue} Selected in the ${labelName}`,
          async () => {

            await element1.nth(i).click();

            console.log(
              `${InputValue} Selected in the ${labelName}`
            );

          }
        );

        return;
      }
    }

    throw new Error(
      `No matching dropdown value found for ${InputValue}`
    );

  } catch (e) {
    throw new Error(`This is a runtime exception. ${e}`);
  }
}










}
