import * as XLSX from 'xlsx';
import * as path from 'path';
import * as fs from 'fs';
import { TestInfo } from '@playwright/test';
import { fa } from '@faker-js/faker';

export class ExcelUtility {
  private static getAbsolutePath(fileName: string): string {
    // Always resolve relative to project root
    return path.resolve(process.cwd(), 'com','src','Resources', fileName);
  }

  static readExcel(fileName: string): Record<string, unknown>[] {
    const filePath = this.getAbsolutePath(fileName);

    if (!fs.existsSync(filePath)) {
      throw new Error(`Excel file not found: ${filePath}`);
    }

    const workbook = XLSX.readFile(filePath,{raw: true});
    const sheetName = workbook.SheetNames[0];
    const sheet = workbook.Sheets[sheetName];
    return XLSX.utils.sheet_to_json<Record<string, unknown>>(sheet,{raw: true, dateNF:"DD-MM-YYYY"});
  }
  static getValueByHeader(HeaderName: string, ID: number): string {
  const rows = this.readExcel("Action _Final.xlsx");
  //console.log(rows);
  //console.log(rows[0]);
  const row = rows.find(r => String(r["Action Reference"]).trim() === String(ID).trim());


  if (!row) {
    throw new Error(`ID "${ID}" not found in the sheet`);
  }

  let value = row[HeaderName as keyof typeof row];
  if ((
  value === undefined ||
  value === null ||
  value === "" ||
  value === " " ||
  String(value).toLowerCase() === "null" ||
  String(value).toLowerCase() === "undefined"
)) {
     value ="nothing";
    //throw new Error(`Header "${HeaderName}" not found in the row`);
  }
  const isDateColumn =
    HeaderName.toLowerCase().includes("date") 
    // HeaderName.toLowerCase().includes("First Target Date") ||
    // HeaderName.toLowerCase().includes("Current Target Date") ||
    // HeaderName.toLowerCase().includes("Date Closed");
  if (typeof value === "number" &&  isDateColumn) {
    const excelEpoch = new Date(Date.UTC(1899, 11, 30));
    const jsDate = new Date(excelEpoch.getTime() + (value as number) * 24 * 60 * 60 * 1000);
    const month = (jsDate.getMonth() + 1).toString().padStart(2, "0");
    const day = jsDate.getDate().toString().padStart(2, "0");
    const year = jsDate.getFullYear();

    return `${day}-${month}-${year}`;
  }
  

  return String(value);
}

static getRAValue(HeaderName: string, ID: number): string {
  const rows = this.readExcel("Action.xlsx");
  const row = rows.find(r => String(r["RA Reference"]).trim() === String(ID).trim());


  if (!row) {
    throw new Error(`ID "${ID}" not found in the sheet`);
  }

  let value = row[HeaderName as keyof typeof row];
  if ((
  value === undefined ||
  value === null ||
  value === "" ||
  value === " " ||
  String(value).toLowerCase() === "null" ||
  String(value).toLowerCase() === "undefined"
)) {
     value ="nothing";
    //throw new Error(`Header "${HeaderName}" not found in the row`);
  }
  const isDateColumn =
    HeaderName.toLowerCase().includes("date") 
    // HeaderName.toLowerCase().includes("First Target Date") ||
    // HeaderName.toLowerCase().includes("Current Target Date") ||
    // HeaderName.toLowerCase().includes("Date Closed");
  if (typeof value === "number" &&  isDateColumn) {
    const excelEpoch = new Date(Date.UTC(1899, 11, 30));
    const jsDate = new Date(excelEpoch.getTime() + (value as number) * 24 * 60 * 60 * 1000);
    const month = (jsDate.getMonth() + 1).toString().padStart(2, "0");
    const day = jsDate.getDate().toString().padStart(2, "0");
    const year = jsDate.getFullYear();

    return `${day}-${month}-${year}`;
  }
  

  return String(value);
}


// static getValueByHeader1(HeaderName:string,ID:number):string{
//   const AllValues = this.readExcel("Action.xlsx");
//   if (!AllValues || AllValues.length === 0) {
//     throw new Error("Excel file is empty or unreadable");
//   }

//   let headerIndex: any ;
//   for (let i = 0; i < AllValues[0].length; i++) {
//     if (AllValues[0][i] === HeaderName) {
//       headerIndex = AllValues[0][i];
//       // console.log(i, "is present in the  " + HeaderName);
//       break;
//     }
//   }
//   //console.log(AllValues[0]);
//   if (headerIndex === " "|| headerIndex === undefined || headerIndex === null) {
//     throw new Error(`Header "${HeaderName}" not found in the sheet`);
//   }

//   let finalValue: any = undefined;
//   for (let j = 1; j < AllValues.length; j++) {
//     let ExcelID =AllValues[j][0]
//     if (ExcelID === ID) {
//       finalValue = AllValues[j][headerIndex];
//       break;
//     }
//   }

//   if (finalValue === undefined) {
//     //finalValue =" ";
//     throw new Error(`ID "${ID}" not found in the first column`);
//   }

//   return String(finalValue);
// }
// static getValueByHeader11(HeaderName:string,ID:number):string{
//   const AllValues = this.readExcel("Action.xlsx");
//   if (!AllValues || AllValues.length === 0) {
//     throw new Error("Excel file is empty or unreadable");
//   }

//   let headerIndex: number = -1;
//   for (let i = 0; i < AllValues[0].length; i++) {
//     if (AllValues[0][i] === HeaderName) {
//       headerIndex = i;
//       // console.log(i, "is present in the  " + HeaderName);
//       break;
//     }
//   }
//   //console.log(AllValues[0]);
//   if (headerIndex === -1) {
//     throw new Error(`Header "${HeaderName}" not found in the sheet`);
//   }

//   let finalValue: any = undefined;
//   for (let j = 1; j < AllValues.length; j++) {
//     let ExcelID =AllValues[j][0]
//     if (ExcelID === ID) {
//       finalValue = AllValues[j][headerIndex];
//       break;
//     }
//   }
//   const isDateColumn =
//   HeaderName.toLowerCase().includes("date") ||
//   HeaderName.toLowerCase().includes("dob") ||
//   HeaderName.toLowerCase().includes("startdate") ||
//   HeaderName.toLowerCase().includes("enddate");
//     if (typeof finalValue === "number"&&isDateColumn) {
//     const excelEpoch = new Date(Date.UTC(1899, 11, 30));
//     const jsDate = new Date(excelEpoch.getTime() + finalValue * 24 * 60 * 60 * 1000);
//     const month = (jsDate.getMonth() + 1).toString().padStart(2, "0");
//     const day = jsDate.getDate().toString().padStart(2, "0");
//     const year = jsDate.getFullYear();

//     return `${day}-${month}-${year}`;
//     //return jsDate.toISOString().split("T")[0]; // -> YYYY-MM-DD
//   }

//   if (finalValue === undefined) {
//     //finalValue =" ";
//     throw new Error(`ID "${ID}" not found in the first column`);
//   }

//   return String(finalValue);
// }
  
  
  // static getValue(testInfo:TestInfo,tcID:string,Header:string):string{
  //   const prop =this.readExcel("Test-Data.xlsx");
  //  const RowCount= prop.length;
  //  let testCaseID  ="";
  //  const ColumnCount=prop[0].length;
  //  let HeaderIndex;
  //  for(let i=0;i<ColumnCount;i++){
  //   if(prop[0][i]===Header){
  //     HeaderIndex =prop[0].indexOf(Header);
  //     console.log(prop[0][i] , "is not present in the  "+ Header,HeaderIndex);
  //   }
  //   // }  else{
  //   //   throw new Error("Header is not present in the excel");
  //   // } 
  //  }
  //  for(let i=0;i<RowCount;i++){
  //   if(prop[i][0] === tcID){
  //      testCaseID =prop[i][HeaderIndex];
  //     console.log(testCaseID );

  //   }

  //  }
    
  //  return testCaseID;

  // }

  static writeExcel(fileName: string, data: any[][], sheetName = 'Sheet1'): void {
    const filePath = this.getAbsolutePath(fileName);

    const workbook = XLSX.utils.book_new();
    const worksheet = XLSX.utils.aoa_to_sheet(data);
    XLSX.utils.book_append_sheet(workbook, worksheet, sheetName);

    XLSX.writeFile(workbook, filePath);
    console.log(`Data written to ${filePath}`);
  }
}