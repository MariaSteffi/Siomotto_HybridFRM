import { test as base } from "@playwright/test";
import { LoginPage } from "../ui/pages/LoginPage";
import { HrmPimPage } from "../ui/pages/HrmPimPage";
import hrmData from "../Resources/HrmTestData.json";

type HrmFixtures = {
  loginPage: LoginPage;
  pimPage: HrmPimPage;
  hrmTestData: typeof hrmData;
};

export const test = base.extend<HrmFixtures>({
  loginPage: async ({ page }, use) => { await use(new LoginPage(page)); },
  pimPage:   async ({ page }, use) => { await use(new HrmPimPage(page)); },
  hrmTestData: async ({}, use)     => { await use(hrmData); },
});

export { expect } from "@playwright/test";