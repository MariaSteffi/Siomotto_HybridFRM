import { test as base, chromium, Browser, BrowserContext, Page, mergeTests } from '@playwright/test'; // NEW: added mergeTests
import { PageObjectFactory } from '../ui/pages/PageObjectFactory';
import { CommanUtility } from '../utils/CommanUtility';
import { Locators } from '../ui/pages/Locators';
import { UserData } from '../ui/TestData/UserData';
import { LoginPage,Role } from '../ui/pages/LoginPage';
import { ExcelUtility } from '../utils/ExcelUtils';
import TesData  from "../Resources/TestData.json";
import { test as hrmFixtureTest } from './HrmFixture';   

type CustomFixtures = {
  launchApp: (role: Role) => Promise<Page>;
  closeApp: () => Promise<void>;
  OpenApp: PageObjectFactory;
  testData :typeof TesData;
};

let context: BrowserContext;
let browser: Browser;
let page: Page;

export const test = base.extend<CustomFixtures>({
  launchApp: async ({}, use,testInfo) => {
    await use(async (role: Role) => {
      browser = await chromium.launch({ headless: false });
      context = await browser.newContext();
      page = await context.newPage();
     await page.goto(process.env.Testurl!);
      return page;
    });
  },

  closeApp: async ({}, use) => {
    await use(async () => {
      await context?.close();
      await browser?.close();
    });
  },

  OpenApp: async ({ launchApp }, use,testInfo) => {
    const page = await launchApp('admin');
    const factory = PageObjectFactory.getInstance(page);
    await use(factory);
    await context?.close();
      await browser?.close();
  },
  testData :async({},use)=>{
        await use(TesData);
    }
});

export const expect = test.expect;

// NEW: merged test = existing fixtures + HRM fixtures
export const hrmTest = mergeTests(test, hrmFixtureTest);