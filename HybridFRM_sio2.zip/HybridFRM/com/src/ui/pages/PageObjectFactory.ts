// src/factories/PageObjectFactory.ts
import { Page } from "@playwright/test";
//import DelegationPage from "./DelegationPage";
import AccessRightsManagementPage from "./AccessRightsmanagment";
//import MasterDataManagementPage from "./MasterDatamanagementPage";
import ApplicationUtility from "../../utils/ApplicationUtility";
import { CommanUtility } from "../../utils/CommanUtility";
import WorkflowPage from "./WorkflowPage";
import EntityHierarchy from "./EntityHierarchy";
import RAUploadPage from "./RAUploadPage";
import BIAUploadPage from "./BIAUploadPage";
import RolesAndUsersPage from "./RolesAndUsersPage";
import AssignDashboardAndHeatMapsPage from "./AssignDashboardAndHeatMapsPage";
import LicencesPage from "./LicencesPage";

import UserPage from "./Users";
import TaskReassignmentPage from "./TaskReassignment";

export class PageObjectFactory {
   
  private static instance: PageObjectFactory;
  //private delegationPage!: DelegationPage;
  private applicationUtility!: ApplicationUtility;
  private workflowPage!: WorkflowPage;
  private commanUtility!: CommanUtility;
  private accessRightsManagementPage!: AccessRightsManagementPage;
  //private masterDataManagementPage!:MasterDataManagementPage;
  private entityHierarchyPage!: EntityHierarchy;
  private RAUploadPage!: RAUploadPage;
  private BIAUploadPage!: BIAUploadPage;
  private rolesAndUsersPage !: RolesAndUsersPage;
  private AssignDashboardAndHeatMapsPage!:AssignDashboardAndHeatMapsPage;
  private LicencesPage!:LicencesPage;

  private userPage !: UserPage;
  private taskReassignmentPage !: TaskReassignmentPage;
  constructor(public  page: Page) {}

  static getInstance(page: Page): PageObjectFactory {
    // if (!PageObjectFactory.instance) {
    //   PageObjectFactory.instance = new PageObjectFactory(page);
    // }
    // return PageObjectFactory.instance;
    return new PageObjectFactory(page);
  }
  public getAccessRightsManagementPage(): AccessRightsManagementPage {
    if (!this.accessRightsManagementPage) {
      this.accessRightsManagementPage = new AccessRightsManagementPage(this.page);
    }
    return this.accessRightsManagementPage;
  }
  public getMasterDataManagementPage():MasterDataManagementPage{
    if(!this.masterDataManagementPage){
      this.masterDataManagementPage= new MasterDataManagementPage(this.page);
    }
    return this.masterDataManagementPage;
  }
  //Roles and Users
  public getRolesAndUsersPage(): RolesAndUsersPage
  {
    if(!this.rolesAndUsersPage)
    {
      this.rolesAndUsersPage = new RolesAndUsersPage(this.page);
    }
    return this.rolesAndUsersPage;
  }
 public getBIAUploadPage(): BIAUploadPage {
    if (!this.BIAUploadPage) {
      this.BIAUploadPage = new BIAUploadPage(this.page);
    }
    return this.BIAUploadPage;
  }

  public getEntityHierarchyPage(): EntityHierarchy {
    if (!this.entityHierarchyPage) {
      this.entityHierarchyPage = new EntityHierarchy(this.page);
    }
    return this.entityHierarchyPage;
  }
  //public getDelegationPage():DelegationPage {
  //  if (!this.delegationPage) {
  //    this.delegationPage = new DelegationPage(this.page);
  //  }
  //  return this.delegationPage;
  //}
   public getWorkflowPage():WorkflowPage {
    if (!this.workflowPage) {
      this.workflowPage = new WorkflowPage(this.page);
    }
    return this.workflowPage;
  }

  public getApplicationUtility(): ApplicationUtility {
    if (!this.applicationUtility) {
      this.applicationUtility = new ApplicationUtility(this.page);
    }
    return this.applicationUtility;
  }
   public getCommanUtility(): CommanUtility {
    if (!this.commanUtility) {
      this.commanUtility = new CommanUtility(this.page);
    }
    return this.commanUtility;
  }

   public getRAUploadPage(): RAUploadPage {
    if (!this.RAUploadPage) {
      this.RAUploadPage = new RAUploadPage(this.page);
    }
    return this.RAUploadPage;
  }







  public getUsersPage(): UserPage {
    if (!this.userPage) {
      this.userPage = new UserPage(this.page);
    }
    return this.userPage;
  }

  public getTaskReassignmentPage(): TaskReassignmentPage{
    if (!this.taskReassignmentPage){
      this.taskReassignmentPage = new TaskReassignmentPage(this.page);
    }
    return this.taskReassignmentPage;
  }








  // You can dynamically map if needed

public getAssignDashboardAndHeatMapsPage():AssignDashboardAndHeatMapsPage{
  if (!this.AssignDashboardAndHeatMapsPage) {
      this.AssignDashboardAndHeatMapsPage = new AssignDashboardAndHeatMapsPage(this.page);
    }
    return this.AssignDashboardAndHeatMapsPage;
}
//Licences

public getLicencesPage():LicencesPage{
  if (!this.LicencesPage) {
      this.LicencesPage = new LicencesPage(this.page);
    }
    return this.LicencesPage;
}
  





















}
