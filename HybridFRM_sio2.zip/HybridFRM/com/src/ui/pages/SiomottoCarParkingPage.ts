// SiomottoCarParkingPage.ts
import { Page } from "@playwright/test";
import SiomottoListingPage from "./SiomottoListingPage";

export default class SiomottoCarParkingPage extends SiomottoListingPage {
  constructor(page: Page) {
    super(page);
  }
}