import { Page } from "@playwright/test";
import { CommanUtility } from "../../utils/CommanUtility";
import { Locators } from "./Locators";

export type Role = "admin" | "manager" | "User";

export class LoginPage extends CommanUtility {
  constructor(protected page: Page) {
    super(page);
  }

  async open() {
    await this.stepWithScreenshot(`Opened the HRM application`, async () => {
      await this.page.goto(process.env.Testurl!);
      console.log(`Opened the HRM application`);
    });
  }

  async loginAs(role: Role) {
    const credentials = {
      admin: { username: process.env.HRM_USERNAME!, password: process.env.HRM_PASSWORD! },
      manager: { username: "manager1", password: "Password@123" },
      User: { username: "user1", password: "Password@123" },
    };

    const { username, password } = credentials[role];

    await this.stepWithScreenshot(`Entered the username as ${username}`, async () => {
      await this.page.fill(Locators.UsernameInput, username);
      console.log(`Entered the username as ${username}`);
    });

    // password is masked so it does not show in the Allure report or screenshot file name
    await this.stepWithScreenshot(`Entered the Password`, async () => {
      await this.page.fill(Locators.PasswordInput, password);
      console.log(`Entered the Password as ********`);
    });

    await this.stepWithScreenshot(`Clicked on Login button`, async () => {
      await this.page.click(Locators.LoginButton);
      console.log(`Clicked on Login button`);
    });
  }

  async loginAsAdmin() {
    await this.open();
    await this.loginAs("admin");
  }

  async verifyPageTitle(expected: string) {
    const actual = await this.getText("locator", Locators.PageTitle, "Page Title");
    await this.AssertEquals(actual, expected);
  }

  async verifyErrorMessage(expected: string) {
    const actual = await this.getText("locator", Locators.ErrorMessage, "Error Message");
    await this.AssertEquals(actual, expected);
  }
}