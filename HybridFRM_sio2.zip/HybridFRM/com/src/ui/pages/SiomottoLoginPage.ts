import { Page } from "@playwright/test";
import { CommanUtility } from "../../utils/CommanUtility";
import { SiomottoLocators as L } from "./SiomottoLocators";

export default class SiomottoLoginPage {
  private common: CommanUtility;

  constructor(private page: Page) {
    this.common = new CommanUtility(page);
  }

  async loginAsUser() {
    await this.common.Click("locator", L.LoginButton, "Login at top right");
    await this.common.Enter("locator", L.MobileInput, "Mobile number", process.env.STAGE_MOBILE!);
    await this.common.Click("locator", L.GetOtpButton, "Get OTP");
    const otp = process.env.STAGE_OTP!;
    await this.common.stepWithScreenshot("Entered OTP", async () => {
      for (let i = 0; i < otp.length; i++) {
        await this.page.locator(L.OtpBox(i)).fill(otp[i]);
      }
    });
    await this.page.locator(L.IndividualButton).click({ timeout: 5000 }).catch(() => {});
  }
}