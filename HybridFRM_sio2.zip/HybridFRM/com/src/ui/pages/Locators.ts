export class Locators {
  
  static UsernameInput = "input[name='username']";
  static PasswordInput = "input[name='password']";
  static LoginButton = "button[type='submit']";
  static ErrorMessage = ".oxd-alert-content-text";

 
  static PageTitle = ".oxd-topbar-header-breadcrumb h6";
  static PimMenu = "a.oxd-main-menu-item:has-text('PIM')";
  static AddEmployeeTab = "a:has-text('Add Employee')";

  
  static FirstName = "input[name='firstName']";
  static LastName = "input[name='lastName']";
  static SaveButton = "button[type='submit']";
  static SuccessToast = ".oxd-toast";
}