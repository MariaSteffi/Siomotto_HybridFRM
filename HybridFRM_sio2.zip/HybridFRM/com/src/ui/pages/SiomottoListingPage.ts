import { Page, expect } from "@playwright/test";
import { CommanUtility } from "../../utils/CommanUtility";
import { SiomottoLocators as L } from "./SiomottoLocators";

export default class SiomottoListingPage {
  protected common: CommanUtility;

  constructor(protected page: Page) {
    this.common = new CommanUtility(page);
  }

  async verifyPageLoaded() {
    await this.common.ElementDisplayed(L.SearchBox, "Search box");
    await this.common.ElementDisplayed(L.MinPrice, "Min Price box");
    await this.common.ElementDisplayed(L.MaxPrice, "Max Price box");
    await this.common.ElementDisplayed(L.ApplyButton, "Apply button");
  }

  
  async searchLocation(text: string, suggestion: string) {
  await this.common.pressBySequence("locator", L.SearchBox, "Search box", text);
  await this.common.Click("locator", L.Suggestion(suggestion), `Suggestion ${suggestion}`, { timeout: 20000 });
}

  async verifyLocationSelected(keyword: string) {
    await expect(this.page.locator(L.SearchBox)).toHaveValue(new RegExp(keyword, "i"));
  }

  async applyPrice(min: string, max: string) {
    await this.common.Enter("locator", L.MinPrice, "Min Price", min);
    await this.common.Enter("locator", L.MaxPrice, "Max Price", max);
    await this.common.Click("locator", L.ApplyButton, "Apply");
  }

  async verifyPriceValues(min: string, max: string) {
    await expect(this.page.locator(L.MinPrice)).toHaveValue(min);
    await expect(this.page.locator(L.MaxPrice)).toHaveValue(max);
  }

  async verifyResultsShown() {
    await this.common.ElementDisplayed(L.ViewOwnerContact, "View Owner Contact button");
  }

  async verifyNoResults() {
    await expect(this.page.locator(L.ViewOwnerContactAll)).toHaveCount(0);
  }

  async clickViewContact() {
    await this.common.Click("locator", L.ViewOwnerContact, "View Owner Contact");
    await this.page.locator(L.ProceedButton).click({ timeout: 5000 }).catch(() => {});
  }

  async verifyLoginRequired() {
    await this.common.ElementDisplayed(L.LoginRequiredMessage, "Login required message");
  }

  async verifyContactDetailsShown() {
    await this.common.ElementDisplayed(L.ContactDetails, "Contact details");
  }
}