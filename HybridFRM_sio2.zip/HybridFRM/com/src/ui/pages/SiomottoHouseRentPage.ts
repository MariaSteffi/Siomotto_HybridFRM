import { Page } from "@playwright/test";
import SiomottoListingPage from "./SiomottoListingPage";

export default class SiomottoHouseRentPage extends SiomottoListingPage {
  constructor(page: Page) {
    super(page);
  }
}