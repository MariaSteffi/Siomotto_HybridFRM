import { CommanUtility } from "../../utils/CommanUtility";
import { Locators } from "./Locators";
import { UserData } from "../TestData/UserData";
import { PageObjectFactory } from "./PageObjectFactory";
import ApplicationUtility from "../../utils/ApplicationUtility";
import constUtils from "../../utils/constutils";
import { Locator, Page } from "@playwright/test";
import { LoginPage,Role } from "./LoginPage";
import { ExcelUtility } from "../../utils/ExcelUtils";
import { Cards, Entity, StageActions } from "../../constants/enum";
import TesData  from "../../../src/Resources/TestData.json";
import { StaticFields } from "../../constants/StaticFields";
import { StageCreation, StageCreationBuilder } from "../../Builders/StageCreation";
import { fakerCS_CZ } from "@faker-js/faker";
import { RAFormSubmit, RAFormSubmition } from "../../Builders/RAFormSubmition";
import { FakeData } from "../TestData/FakeData";

//import constUtils from "../../utils/constUtils";

export default class AccessRightsManagementPage extends  ApplicationUtility {
  
  public utility: ApplicationUtility;
  public  ActionName !:string;
  public Log:LoginPage;

  constructor(protected page: Page) {
    super(page);
    //this.utility =new ApplicationUtility(page);
    this.utility =  PageObjectFactory.getInstance(page).getApplicationUtility();
    this.Log= new LoginPage(page);
  }

  public async loginAsAdmin() {
    await this.Log.loginAs('admin');


  }
  public async loginAsPoweruser(PowerUserName:Role) {
    await this.Log.loginAs(PowerUserName);


  }
  public async NavigateSystemPreferences() :Promise<AccessRightsManagementPage> {
    await this.utility.clickSystemPreferences();
    return new AccessRightsManagementPage(this.page);
  }
  public async NavigateToAccessRights() {
    await this.utility.clickAccessRights();
   // return new AccessRightsManagementPage(this.page);     
  }

  public async SelectAccessModule(ModuleName:string) {
    await this.utility.clickOnSpecificIndex(Locators.AccessModules,ModuleName);
   //await this.utility.clickOnSpecificIndex(Locators.AccessModules,ModuleName);
  }

  public async clickAddNewStage(){
    await this.utility.clickUtils(StaticFields.AddNewStageButton,UserData.AddNewStageButton);

  }
  public async checkforRole():Promise<boolean>{
     // const isRolePresent = await this.utility.checkFromListOfElement(Locators.MenuAcess,TesData.TC_AM_001.RoleName);
       const isRolePresent = await this.utility.checkFromListOfElement(Locators.MenuAcess,FakeData.FullName());
      return isRolePresent;
  }
   public async checkForRoleNotExists():Promise<boolean> {
     const isRolePresent = await this.checkforRole();
   if (!isRolePresent) {
    await this.clickAddNewRole();
    await this.clickBusinessEntity();
    await this.roleSearch();
    await this.sleep(4000);
    await this.clickRole();
    await this.sleep(4000);
    await this.SaveButton();
    await this.sleep(4000);
    
   }else{
     //this.AssertTrue(isRolePresent,`Role ${TesData.TC_AM_001.RoleName} is  present even before Adding.`);
    await this.utility.stepWithScreenshot(`Role ${TesData.TC_AM_001.RoleName} is already present.`,async ()=>{
      console.log(`Role ${TesData.TC_AM_001.RoleName} is already present.`);
    });
   }
   return isRolePresent;
  }
  public async clickAddNewRole(){
    await this.utility.clickUtils(StaticFields.AddNewRoleButton,UserData.AddNewRoleButton);

  }
  public async clickBusinessEntity(){
    await this.utility.clickUtils(Entity.Business,UserData.BusinessEntity);

  }
    public async clickEnterpriseEntity(){
    await this.utility.clickUtils(Entity.Enterprise.toString(),UserData.EnterpriseEntity);

  }
    public async clickExecutionEntity(){
    await this.utility.clickUtils(Entity.Execution.toString(),UserData.ExecutionEntity);

  }

 
  
  public async roleSearch(){
    await this.utility.RoleSearch(TesData.TC_AM_001.RoleName,UserData.RoleSearch);
  }
  public async clickRole(){
    await this.utility.clickUtils(TesData.TC_AM_001.RoleName,TesData.TC_AM_001.RoleName);
  }
 public async checkForRoleExists(){
   const isRolePresent = await this.checkforRole();
   if (isRolePresent) {
    
    await this.utility.clickOnSpecificIndex(Locators.MenuAcess,TesData.TC_AM_001.RoleName);
    await this.utility.deleteIcon();
   }else{
    this.AssertTrue(isRolePresent,`Role ${TesData.TC_AM_001.RoleName} is not present even before deleting.`);
    // await this.utility.stepWithScreenshot(`Role ${TesData.TC_01.RoleName} is not present.`,async ()=>{
    //   console.log(`Role ${TesData.TC_01.RoleName} is Not Present.`);
    // });
   }
  }
  public async isModuleDisplayed(moduleName:string):Promise<void>{
    await this.utility.isElementDisplayed(moduleName,moduleName);
  }

  public async noOFStage(stageNumber:string):Promise<void>{
    await this.utility.Enter("locator",Locators.NoOFStage,UserData.NoOFStage,stageNumber);
  }

  public async StageCreation(stageData:StageCreation):Promise<String>{
   const stageName= await this.utility.Enter("locator",Locators.StageName,UserData.StageName,stageData.stageName,);
    await this.utility.StageRadioButton(StageActions.Approval,UserData.ApprovalStage,stageData.Approve);
    await this.utility.StageRadioButton(StageActions.NeedCorrection,UserData.NeedCorrectionStage,stageData.NeedCorrection);
    await this.utility.StageRadioButton(StageActions.Abort,UserData.AbortStage,stageData.Abort);
    await this.sleep(2000);
    await this.PlusIconImage();
    await this.sleep(2000);
    await this.TypeHeadDropdown(Locators.ARMAssignUser,Locators.AssignUserDD,stageData.AssignTo,UserData.AssignTo);
    await this.utility.enterValue(StaticFields.ReviewWithIn,UserData.ReviewWithIn,stageData.ReviewWithIn.toString());
    await this.StageRadioButton(StaticFields.isUnanimous,UserData.isUnanimous,stageData.isUnanimous);
  return stageName;
}
public async AccordionExpending(index:number,StageCreation:()=>Promise<void>):Promise<void>{
  for (let i=1;i<=index;i++){ 
  await this.page.locator("(//div[normalize-space(@class)='ant-collapse-header'])["+i+"]").getAttribute("aria-expanded").then(async (value)=>{
    await this.sleep(4000);
    if(value ==="false"){
      await this.commanUtility.Click("locator","(//div[normalize-space(@class)='ant-collapse-header'])["+i+"]","Accordion");
      await this.sleep(4000);
      await StageCreation(); 
    }else{
      await StageCreation();
    }
  });
}
await this.sleep(3500);
}

public async StageCreationWithOnlyStageName():Promise<String>{

   
   
    const stategeCretio = new StageCreationBuilder().setStageName("Stage1")
   .setReviewWithIn(5)
   .build();
    const stageName = await this.StageCreation(stategeCretio);
    return stageName;
  
}

public async clickOnBIAFirstRecord():Promise<void>{ 
  await this.clickOnFirstIndex("(//tbody//tr/td)",UserData.BIAMasterFirstRecord,{timeout:5000});
}

public async AssertStageDetails(stageName: string,value: string,assignedUser: string)
{
   try {
    // Assert Stage Name
    const stageSelector = `//label[text()='Stage Name']//parent::div//input`;
    await this.ElementDisplayed(stageSelector, `Stage Name: ${stageName}`);
    const actualStageName = await this.getAttribute( stageSelector, `value`);
    await this.AssertEquals(actualStageName!, stageName);

    // Assert Review Within Value
    const valueSelector = `//div/label[normalize-space()='Review within']/parent::div//input[@role='spinbutton' and @value='${value}']`;
    await this.ElementDisplayed(valueSelector, `Review Within Value: ${value}`);
    const actualValue = await this.getAttribute(valueSelector, "value");
    await this.AssertEquals(actualValue ?? "", value);

    // Assert Assigned User
    const userSelector = `//div//span/span/span[normalize-space()='${assignedUser}']`;
    await this.ElementDisplayed(userSelector, `Assigned User: ${assignedUser}`);
    const actualUser = await this.getText("locator", userSelector, `Assigned User: ${assignedUser}`);
    await this.AssertEquals(actualUser, assignedUser);

    console.log(`Stage Details verified — Stage: ${stageName} | Value: ${value} | Assigned User: ${assignedUser}`);

  } catch (error) {
    console.error(`Failed to assert stage details`, error);
    throw error;
  }
  //span[@role = 'img' and @aria-label='right']/following-sibling::div/div[contains(normalize-space(.), 'Stages') and contains(normalize-space(.), '${stageName}')]
  //div/label[normalize-space() = 'Review within']/parent::div//input[@role='spinbutton' and @value = '${value}']
  //div//span/span/span[normalize-space()='${assignedUser}']
}

public async EditStageDetails(stageName: string,value: string,assignedUser: string)
{

  try {

    await this.Enter(
      "locator",
      Locators.StageName,
      "Stage Name",
      stageName
    );

    await this.Enter(
      "locator",
      `//div/label[normalize-space()='Review within']/parent::div//input[@role='spinbutton']`,
      "Review Days",
      value
    );

    // Step 3: Select Assigned User from TypeHead Dropdown
    await this.TypeHeadDropdown(
      `//div//input[@role = 'combobox']`,
      `//div/div/span[normalize-space()='${assignedUser}']`,
      "seema",
      "Assigned User Dropdown"
    );

    console.log(`Stage Details edited — Stage: ${stageName} | Value: ${value} | Assigned User: ${assignedUser}`);

  } catch (error) {
    console.error(`Failed to edit stage details`, error);
    throw new Error(
      `Runtime exception //div[@aria-selected=\'false\']/div/span[normalize-space()=\'Risk/Senior Manager 1/Rene Descartes : ReneDes\']'while editing stage details: ${String(error)}`
    );
  }
//   Locators.StageName
//   await this.Enter('locator',`//div/label[normalize-space()='Review within']/parent::div//input[@role='spinbutton' and @value]`,'Review Days',value)
//   await this.TypeHeadDropdown(`//span[normalize-space()='Please select']`,`//div[@aria-selected='false']/div/span[normalize-space()='4{assignedUser}']`,assignedUser,'Assigned User drop down')
// }
}

public async DeleteStage()
{
  
  await this.clickOnFirstIndex(`//div/label/following-sibling::img[@src = '/images/svg/delete-black.svg']`, UserData.DeleteIcon) 
}
public async DeleteNoOfStages(stage:string)
{
  let n = parseInt(stage);
  for(let i = 1; i <= n; i++)
  {
    await this.LoopClick(`//div/label/following-sibling::img[@src = '/images/svg/delete-black.svg']`, UserData.DeleteIcon) 
    await this.watforNetwork();
  }
  
}

public async AssertNoOfStage(stageNumber: string): Promise<void> {
  try {
    // Step 1: Verify field is visible
    await this.ElementDisplayed(Locators.NoOFStage, UserData.NoOFStage);

    // Step 2: Get current value of the input field
    const actualValue = await this.getAttribute(Locators.NoOFStage, "value");

    // Step 3: Assert actual value matches expected stage number
    await this.AssertEquals(actualValue ?? "", stageNumber);

    

  } catch (error) {
    
    throw error;
  }
}

public async NoOfReviewDays(days: string)
{
   await this.Enter(
      "locator",
      Locators.ReviewWithin,
      UserData.ReviewWithIn,
      days
    );
}


public async AssertReviewDays(days: string): Promise<void> {
  try {
    // Step 1: Verify field is visible
    await this.ElementDisplayed(Locators.ReviewWithin, UserData.ReviewWithIn);

    // Step 2: Get current value of the input field
    const actualValue = await this.getAttribute(Locators.ReviewWithin, "value");

    // Step 3: Assert actual value matches expected stage number
    await this.AssertEquals(actualValue ?? "", days);

    

  } catch (error) {
    
    throw error;
  }
}

public async EnterStageName(stageName: string)
{
  await this.Enter('locator', Locators.StageName, UserData.StageName, stageName);

  await this.ElementDisplayed(Locators.StageName, UserData.StageName);
  const actualValue = await this.getAttribute(Locators.StageName, "value");
  await this.AssertEquals(actualValue ?? "", stageName);
}

public async CheckBox(locator: string,labelName:string)
{
  await this.ElementDisplayed(locator, labelName);
    const checkedAttr = await this.getAttribute(locator, "class");
   // const isChecked: boolean = checkedAttr !== null;

    if (checkedAttr == 'ant-checkbox ant-checkbox-checked') {
      
      await this.Click("locator", locator, labelName);
      console.log(`${labelName} checkbox clicked to UNCHECK`);
      // await this.watforNetwork();

      const afterUncheckAttr = await this.getAttribute(locator, "class");
      await this.AssertTrue(afterUncheckAttr == 'ant-checkbox', `${labelName} is unchecked`)

      
      await this.Click("locator", locator, labelName);
      console.log(`${labelName} checkbox clicked to CHECK again`);
      // await this.watforNetwork();

    } else {
      
      await this.Click("locator", locator, labelName);
      console.log(`${labelName} checkbox clicked to CHECK`);
      await this.watforNetwork();
    }

    
    const finalAttr = await this.getAttribute(locator, "class");
    if(checkedAttr == 'ant-checkbox ant-checkbox-checked' && finalAttr == 'ant-checkbox')
    {
        await this.AssertTrue(finalAttr == 'ant-checkbox', `${labelName} is checked`);
    }
    else{
      await this.AssertTrue(finalAttr == 'ant-checkbox ant-checkbox-checked', `${labelName} is checked`);
    }
   // await this.AssertTrue(finalAttr == 'ant-checkbox ant-checkbox-checked', `${labelName} is checked`);

}
//div[@aria-live='polite' and @role='alert']/div/div
public async NegativeValidation()
{
  //div[@aria-live='polite' and @role='alert']/div/div
  await this.ElementDisplayed(
      `//div[@aria-live='polite' and @role='alert']/div/div`,
      "Validation Error Messages"
    );
    const stageNameError = await this.getText(
      "locator",
      `(//div[@aria-live='polite' and @role='alert']/div/div)[1]`,
      "Stage Name Error Message"
    );

    
    const stageUserError = await this.getText(
      "locator",
      `//div[@aria-live='polite' and @role='alert']/div/div`,
      "Stage User Error Message"
    );

    console.log(`Error 1: ${stageNameError}`);
    console.log(`Error 2: ${stageUserError}`);

    
    await this.Equals(stageNameError, "Please enter Stage Name");
    await this.Equals(stageUserError, "Please Select Stage User");
}

public async VerifyAlphanumericWithSpecialChars(testValue: string): Promise<void> {
  
  
  await this.Enter("locator",Locators.StageName, "Stage Name", testValue);
  

 
  const actualValue = await this.getAttribute(Locators.StageName, "value");

  
  await this.AssertEquals(actualValue!, testValue);
}

public async VerifyApproveActionDefaultAndDisabled(): Promise<void> {

  const isChecked = await this.getAttribute(Locators.ApproveCheckBox, "checked");
  await this.AssertTrue(isChecked !== null, `${UserData.Approval} is selected by default`);

  const disabledAttribute = await this.getAttribute(Locators.ApproveCheckBox, "disabled");
  const isDisabled = disabledAttribute !== null;
  await this.AssertTrue(isDisabled, `${UserData.Approval} is disabled from being unchecked`);
}

public async VerifyStageNumber()
{
   await this.verifyUserCanIncreaseNumber(2,Locators.NoOfApprovalStagesIncrease,UserData.NoApprovalRequired,Locators.NoOFStage)
      await this.verifyUserCanDecreaseNumber(Locators.NoOfApprovalStagesIncrease,UserData.NoApprovalRequired,Locators.NoOFStage)
}

public async VerifyUserIncreaseSyageNumber()
{
  await this.verifyUserCanIncreaseNumber(2,Locators.NoOfApprovalStagesIncrease,UserData.NoApprovalRequired,Locators.NoOFStage)

}

public async VerifyIncreasedNumber()
{
    await this.verifyUserCanIncreaseNumber(2,Locators.ReviewDaysIncrease,UserData.ReviewDaysUp,Locators.ReviewWithin)
}

public async verifyUserCanIncreaseNumber(n: number,locators:string, label:string, valueLocator:string)
{
   let i;
   for(i = 0; i < n; i++)
   {
     await this.Click('locator', locators, label);
   }

   let str: string = n.toString();
   const reviewDays = await this.getAttribute(valueLocator,'value');
   await this.AssertEquals(reviewDays!,str);
}

public async verifyUserCanDecreaseNumber(locators:string, label:string, valueLocator:string)
{
  const reviewDays = await this.getAttribute(valueLocator,'value');

  let num: number = Number(reviewDays);
   let i: number;
   for(i = num; i > 0; i--)
   {
     await this.Click('locator', locators, label);
   }

   const afterValue = await this.getText('locator',locators,label);
   const days:boolean = num > Number(afterValue);
  //  const reviewDays:boolean = i < n;
    await this.AssertTrue(days!,`Review within days value decreased from ${num} to ${Number(afterValue)}`);
}

public async VerifyDecreasedNumber()
{
  await this.verifyUserCanDecreaseNumber(Locators.ReviewDaysDecrease,UserData.ReviewWithin,Locators.ReviewWithin);
}

public async ClickAnyPartOfScreen()
{
  await this.Click('locator', `//label[normalize-space()='Number of Approval Stages']`, 'Label');
}

public async VerifyPleaseSelectDropdownList(pleaseSelectLocator: string,dropdownListLocator: string,labelName: string): Promise<void> {

  
  await this.Click("locator", pleaseSelectLocator, labelName);
  await this.sleep(1000);

  
  await this.ElementDisplayed(dropdownListLocator, `${labelName} dropdown list`);
}

public async ClickPleaseSelect(assignedUser: string)
{

  await this.Click('locator', `//div/span[normalize-space()='Please select']`, 'Typeahead dropdown');
  // await this.TypeHeadDropdown(
  //     `//div//input[@role = 'combobox']`,
  //     `//div/div/span[normalize-space()='${assignedUser}']`,
  //     "ReneDes",
  //     "Assigned User Dropdown"
  //   );
}

public async ClickAssignPlusIcon()
{
  await this.Click('locator', Locators.AssignUserPlusIcon, 'Assign Button');
}

public async VerifyPleaseSelectDropdownList1(assignedUser: string,labelName: string): Promise<void> {

 
  await this.Click("locator", `//div/span[normalize-space()='Please select']`, 'Combo box');
  await this.sleep(1000);

  // Step 2: Assert the dropdown list is displayed using first item text
  // const isDisplayed = await this.checkFromListOfElement(
  //   `//div/div/span`,
  //   assignedUser
  // );

  await this.TypeHeadDropdown(
      `//div//input[@role = 'combobox']`,
      `//div/div/span[normalize-space()='${assignedUser}']`,
      'seema',
      "Assigned User Dropdown"
    );
  await this.sleep(1000);
   const count = await this.getCount(
    `//div/div/span[normalize-space()='${assignedUser}']`,
    labelName
  );
 const isDisplayed = count > 0;
  await this.AssertTrue(isDisplayed, `${labelName} dropdown list is displayed with available users/roles`);
}

public async EnterValueInDropDown(assignedUser:string, UserName:string)
{
   await this.TypeHeadDropdown(
      `//div//input[@role = 'combobox']`,
      `//div/div/span[normalize-space()='${assignedUser}']`,
      UserName,
      "Assigned User Dropdown"
    );
}

public async AssertValueInDropDown(userValue: string)
{
  const value = await this.getText('locator',`(//td//div/div/span/span/span)[1]`, 'Dropdown');
 //const value = await this.getAttribute(`//div//input[@role='combobox']`, "value"); 
 await this.AssertEquals(value!,userValue);
}

public async CheckIsThisStageMandatory(){
  await this.Click('locator', Locators.IsThisStageMandatory, UserData.IsThisStageMandatoryCheckBox);
}

public async AssertNonVisiblityOfDeleteButton()
{
  const count = await this.getCount(Locators.DeleteStage, UserData.DeleteStageButton);

  const isDisplayed = count > 0;
  await this.AssertFalse(isDisplayed, `${ UserData.DeleteStageButton} delete icon`);
}

public async VerifyStageFeaturesDisplayed()
{
  await this.ElementDisplayed(Locators.StageName, UserData.StageName);
  await this.ElementDisplayed(Locators.IsThisStageMandatory,UserData.IsThisStageMandatoryCheckBox);
  await this.ElementDisplayed(Locators.CheckAbort, `Abort ${UserData.CheckBox}`);
  await this.ElementDisplayed(Locators.ApproveCheckBox, UserData.Approval);
  await this.ElementDisplayed(Locators.CheckNeedsCorrection, UserData.NeedCorrectionStage);
  await this.ElementDisplayed(Locators.ReviewWithin, UserData.ReviewWithIn);
  await this.ElementDisplayed(Locators.Unanimousapproval, UserData.UnanimousApproval);
  await this.ElementDisplayed(Locators.AssignUserPlusIcon, 'Assign Button');
}

public async VerifyAddNewStageFieldsDisplayed()
{
  await this.ElementDisplayed(Locators.NoOFStage, UserData.NoOFStage);
  await this.ElementDisplayed(Locators.NoApprovalCheckBox, UserData.NoApprovalRequired);
  await this.ElementDisplayed(Locators.StagesSave,UserData.SaveStages);
  await this.ElementDisplayed(Locators.CloseStages,UserData.CloseStages);

}

public async RemoveUsersOneByOne(labelName: string): Promise<void> {

  let count = await this.getCount(`//div/span/span[@aria-hidden='true']/span[@role='img' and @aria-label='close']`,labelName);
  console.log(`Total users to remove: ${count}`);

  for (let i = 0; i < count; i++) {
    await this.Click("locator",`(${Locators.AssignedUserCloseIcon})[1]`,
      `${labelName} user ${i + 1}`
    );
    await this.sleep(1000);
  }

  const remainingCount = await this.getCount(Locators.AssignedUserCloseIcon,labelName);
  const isAllRemoved = remainingCount === 0;
  await this.AssertTrue(isAllRemoved, `All ${labelName} users are removed`);
}

public async RemoveAllAssignedUsers(
  labelName: string
): Promise<void> {

  // Step 1: Click the close-circle button to remove all users at once
  await this.Click(
    "locator",
    `//div/span/span[@role='img' and @aria-label='close-circle']`,
    labelName
  );
  await this.sleep(1000);

  
  const remainingCount = await this.getCount(
    `//div/span/span[@role='img' and @aria-label='close-circle']`,
    labelName
  );
  const isAllRemoved = remainingCount === 0;
  await this.AssertTrue(isAllRemoved, `All ${labelName} users are removed`);
}

public async IsAddRoleFeaturesVisible()
{
  await this.ElementDisplayed(Locators.EnterpriseLeve,UserData.EnterpriseEntity);
  await this.ElementDisplayed(Locators.BusinessLevelRole,UserData.BusinessEntity);
  await this.ElementDisplayed(Locators.Execution,UserData.ExecutionEntity);
  await this.ElementDisplayed(Locators.SortOptions,UserData.SortOption);
  await this.ElementDisplayed(Locators.UpArrowButton,UserData.UpArrow);
  await this.ElementDisplayed(Locators.Filterdropdown, UserData.Filterdropdown);
  await this.ElementDisplayed(Locators.SearchField,UserData.SearchBar);
}

public async clickAplhaSortButton()
{
    await this.utility.Click("Locator",Locators.AlphabeticallySortButton,UserData.SortAplhabutton);
}

public async clickSortButton()
{
    await this.utility.Click("Locator",Locators.SortOptions,UserData.SortModbutton);
}

public async VerifySortingAscending(labelName: string): Promise<void> {

  await this.Click("locator", Locators.UpArrowButton, UserData.UpArrow);
  await this.sleep(2000);

  const firstRecord = await this.getText("locator", `(${Locators.Entityname})[1]`, labelName);
  const secondRecord = await this.getText("locator",`(${Locators.Entityname})[2]`, labelName);
  console.log(`First Record: ${firstRecord} Second Record: ${secondRecord}`);

  const isAscending = firstRecord.toLowerCase() <= secondRecord.toLowerCase();
  await this.AssertTrue(isAscending, `${labelName} records are sorted in ascending order from A to Z`);
}

public async VerifySortingDescending(labelName: string): Promise<void> {

  // await this.Click("locator", Locators.UpArrowButton, UserData.UpArrow);
  // await this.sleep(2000);

  const firstRecord = await this.getText("locator", `(${Locators.Entityname})[1]`, labelName);
  const secondRecord = await this.getText("locator",`(${Locators.Entityname})[2]`, labelName);
  console.log(`First Record: ${firstRecord} Second Record: ${secondRecord}`);

  const isDescending = firstRecord.toLowerCase() >= secondRecord.toLowerCase();
  await this.AssertTrue(isDescending, `${labelName} records are sorted in descending order from Z to A`);
}

public async checkModifiedDateSortButton()
{
  await this.ElementDisplayed(Locators.ModifiedDateSortButton, `${TesData.TC_RAU_006.ModifiedDate}`)
}

public async checkAlphabeticallySortButton()
{
  await this.ElementDisplayed(Locators.AlphabeticallySortButton, `${TesData.TC_RAU_006.Alphabetically}`)
}

public async roleSearch1(){
    await this.utility.RoleSearch(TesData.TC_AM_043.RoleName,UserData.RoleSearch);
}

public async AssertSearchedRoleIsPresent(roleName: string): Promise<void> {

  const count = await this.getCount(`//span[normalize-space()='Role']/parent::p/parent::div/following-sibling::div/span[normalize-space()='${roleName}']`,UserData.RoleName);

  const isPresent = count > 0;
  await this.AssertTrue(isPresent, `${UserData.RoleName} - ${roleName} is present in search results`);
}

public async AssertNegativeValidation()
{
  await this.ElementDisplayed(`//div[@aria-live='polite' and @role='alert']/div/div[normalize-space()='Please select one Role']`, 'Please select one Role')
}

public async clickRole1(){
    await this.utility.clickUtils(TesData.TC_AM_043.RoleName,TesData.TC_AM_043.RoleName);
}

public async clickRole2()
{
  await this.Click('locator',`(//div/span[normalize-space()='Assistant Manager'])[2]`,'Role Name')
}

public async VerifyNewlyAddedRoleUnderMenuAccess(roleName: string, labelName: string): Promise<void> {

  
  const count = await this.getCount(
    `//span[normalize-space()='Role']/parent::div/following-sibling::div/span[normalize-space()='${roleName}']`,
    labelName
  );

  const isDisplayed = count > 0;
  await this.AssertTrue(isDisplayed, `${labelName} role is displayed under Menu Access`);
}

public async ClickDeleteButton()
{
  await this.utility.clickOnSpecificIndex(Locators.MenuAcess,TesData.TC_AM_035.RoleName);
  await this.doubleClick("locator","//img[contains(@src,'Delete')]","Delete button",{timeout:30000});
}

public async VerifyConfirmationPopUp()
{
  await this.ElementDisplayed( `//p[normalize-space()='Are you sure you want to delete?']`,
    `Delete confirmation message`)
  await this.ElementDisplayed(Locators.Yes, UserData.YesDeleteButton);
  await this.ElementDisplayed(Locators.No,UserData.NoDeleteButton);
}

public async AccordiandownArrow(locatorValue: string)
  {
    await this.utility.LocatorEntityType(locatorValue);
  }

public async SelectMultipleRolesFromDifferentEntities(entities: { entityName: string; roleName: string }[]): Promise<void> {

  for (const entity of entities) {

    
    await this.AccordiandownArrow(entity.entityName);
    await this.sleep(4000);

    
    await this.Click(
      "locator",
      `//span[text()='${entity.entityName}']//parent::div//following::span[text()='${entity.roleName}']`,
      `${entity.roleName} under ${entity.entityName}`
    );
    await this.sleep(1000);


    const count = await this.getCount(`//span[normalize-space()='${entity.roleName}']`,`${entity.roleName}`);
    const isSelected = count > 0;
    await this.AssertTrue(isSelected, `${entity.roleName} is selected under ${entity.entityName}`);
  }
}

public async VerifyNewlyAddedRoleUnderMenuAccess1(roleNames: string[], labelName: string): Promise<void> {

  for (const roleName of roleNames) {
  const count = await this.getCount(
    `//span[normalize-space()='Role']/parent::div/following-sibling::div/span[normalize-space()='${roleName}']`,
    labelName
  );

  const isDisplayed = count > 0;
  await this.AssertTrue(isDisplayed, `${labelName} role is displayed under Menu Access`);
}
}

public async HoverAmberIcon(labelName: string)
{
   await this.Hover(`//div/span[normalize-space()='${labelName}']/parent::div/parent::div/following-sibling::div/img[@src='/images/svg/Structure_Icon_White.svg']`, labelName)
    
}

public async clickrole()
{
  await this.utility.clickOnSpecificIndex(Locators.MenuAcess,TesData.TC_AM_035.RoleName);
}

public async HoverValueVerification(labelName:string, expectedText: string)
{
  await this.HoverAmberIcon(labelName)
  const actualText = await this.getText("locator", `//span[normalize-space()='${expectedText}']`, 'Entity Name');
  console.log(`Hovered text: ${actualText}`);

  // Step 3: Assert hovered text matches expected text
  await this.AssertEquals(actualText, expectedText);
}

public async ClickOnApplication()
{
    await this.Click('locator', Locators.Application, 'Application');
}

public async ClickRACard()
{
    await this.Click('locator', `//a/div/div/p[normalize-space()='RA']`, 'RA Card');
}

public async ClickRANew()
{
  await this.Click('locator', Locators.RANew, 'RA New');
}

 public async ClickNoDeletionButton()
{
  await this.Click('locator', Locators.NoDelete, UserData.NoDeleteButton);
}

public async ClickRecordsInRA()
{
  await this.doubleClick('locator', `(//tr/td)[1]`, 'RA Record')
}

public async ClickRiskReview()
{
  await this.Click('locator', `//li/a[@role='tab' and @title='Risk Review']`, 'Risk Review');
}

public async VerifyStageDetails()
{
    
}

public async VerifyRAFields()
{
    await this.ElementDisplayed( Locators.RANew, 'RA New');
    await this.ElementDisplayed(Locators.RAFilter,UserData.RAFilter);
    await this.ElementDisplayed(Locators.RiskId, UserData.RiskID);
    await this.ElementDisplayed(Locators.RADepartment, UserData.RADepartment);
    await this.ElementDisplayed(Locators.RiskEventDescription, UserData.RiskEventDescritption);
    await this.ElementDisplayed(Locators.RAModifiedBy, UserData.RAModifiedBy);
    await this.ElementDisplayed(Locators.RAModifiedDate, UserData.RAModifiedBy);
    await this.ElementDisplayed(Locators.ResidualRisk, UserData.ResidualRisk);
    await this.ElementDisplayed(Locators.RAStatus, UserData.RAStatusColumn);
    await this.ElementDisplayed(Locators.RAVersion,UserData.RAVersion);
}

public async VerifyChekBoxState()
{
  await this.CheckBox(Locators.NoApprovalCheckBoxChecked, UserData.NoApprovalRequired);
}

public async VerifyAbortChekBoxState()
{
  await this.CheckBox(Locators.CheckAbort, UserData.AbortStage);
}

public async VerifyUncheckAbortCheckBoxState()
{
  await this.UnCheckBox(Locators.CheckAbort, UserData.AbortStage);
}

public async VerifyNeddCorrectionChekBoxState()
{
  await this.CheckBox(Locators.CheckNeedsCorrection, UserData.NeedsCorrectin);
}

public async VerifyNeddCorrectionUnChekBoxState()
{
  await this.UnCheckBox(Locators.CheckNeedsCorrection, UserData.NeedsCorrectin);
}

public async VerifyUnanimousapprovalChekBoxState()
{
  await this.CheckBox(Locators.Unanimousapproval, UserData.UnanimousApproval);
}

public async VerifyUnanimousapprovalUnChekBoxState()
{
  await this.UnCheckBox(Locators.Unanimousapproval, UserData.UnanimousApproval);
}

public async UnCheckBox(spanLocator: string, labelName: string) {
  
  const currentAttr = await this.getAttribute(spanLocator, "class");  

  if (currentAttr?.includes('ant-checkbox-checked')) {
    
    await this.Click("locator", spanLocator, labelName);               
    console.log(`${labelName} checkbox clicked to UNCHECK`);
    await this.watforNetwork();

    const afterAttr = await this.getAttribute(spanLocator, "class");  
    await this.AssertTrue(
      afterAttr === 'ant-checkbox', 
      `${labelName} is unchecked`
    );

  } else {
    console.log(`${labelName} is already unchecked`);
    await this.AssertTrue(true, `${labelName} is already unchecked`);
  }
}

public async AssertNoOfApprovalStages(days: string): Promise<void> {
  try {
    // Step 1: Verify field is visible
    await this.ElementDisplayed(Locators.NoOFStage, UserData.NoOFStage);

    // Step 2: Get current value of the input field
    const actualValue = await this.getAttribute(Locators.NoOFStage, "value");

    // Step 3: Assert actual value matches expected stage number
    await this.AssertEquals(actualValue ?? "", days);

    

  } catch (error) {
    
    throw error;
  }
}

public async CloseAddNewStage()
{
  await this.Click('locator', Locators.CloseStages, UserData.CloseButton);

  const isVisible = await this.checkFromListOfElement(
    Locators.CloseStages, 
    UserData.CloseButton
  );
  
  await this.AssertFalse(isVisible, `${UserData.CloseButton} is not visible after closing`);
}

public async CloseRole()
{
  await this.Click('locator', Locators.CloseRole, UserData.CloseButton);

  const isVisible = await this.checkFromListOfElement(
    Locators.CloseRole, 
    UserData.CloseButton
  );
  
  await this.AssertFalse(isVisible, `${UserData.CloseButton} is not visible after closing`);
}

public async AssertNoDataIsDisplayed() {
  const isVisible = await this.checkFromListOfElement(
    `//div/p[normalize-space()='No Data']`,
    'No Data'
  );
  await this.AssertTrue(isVisible, 'No Data Message');
}

public async GetAssignedUserCount() {
  const selector = `(//td//div/div/span/span/span)[1]`;
  
  const text = await this.getText('locator',selector,'Assigned User')
  const count = await this.getCount(selector, text);
  
  await this.AssertEquals(count.toString(), '1');
  return text;
}
public async PreviousUser()
{
  const selector = `(//td//div/div/span/span/span)[1]`;
  
  const text = await this.getText('locator',selector,'Assigned User')
  return text;
}

public async AssertNotEqual(value: string, notExpectedValue: string): Promise<void> 
{
  const isEqual = value === notExpectedValue;
  await this.AssertFalse(isEqual, `${value} is not equal to ${notExpectedValue}`);
}

public async EnterHalfValueInDropDown(assignedUser:string, UserName:string)
{
   await this.TypeHeadDropdown(
      `//div//input[@role = 'combobox']`,
      `//div/div/span[normalize-space()='${assignedUser}']`,
      UserName,
      "Assigned User Dropdown"
    );
}

public async VerifyCaseInsensitiveSearch(userName: string): Promise<void> {
  
  
  const displayedText = await this.getText('locator', `(//td//div/div/span/span/span)[1]`, userName);
  
  
  const isMatch = displayedText.toLowerCase().includes(userName.toLowerCase());
  
  await this.AssertTrue(isMatch, `Verified case-insensitive match: expected '${userName}', actual '${displayedText}'`);
}

public async AssertStageNotDisplayed(stageName: string): Promise<void> {
  const stageSelector = `//span[@role='img' and @aria-label='right']/following-sibling::div/div[contains(normalize-space(.), 'Stages') and contains(normalize-space(.), '${stageName}')]`;
  
  const isVisible = await this.checkFromListOfElement(stageSelector, `Stage Name: ${stageName}`);
  
  await this.AssertFalse(isVisible, `Stage '${stageName}' is not displayed after deletion`);
}

public async IsElementDisplayed()
{
  await this.ElementDisplayed(`//div/span[normalize-space()='Please select']`, 'Place Holder value "Please Select"')
}

public async VerifyDescendingSort(
  newlyCreatedRecordName: string,
): Promise<void> {

  // Default descending - newly created record should be FIRST
  const firstRecord = await this.getText(
    'locator',
    `(//div/img[@src='/images/svg/Entity_Dpt.svg']/parent::div/following-sibling::div[2])[1]`,
    `First Record`
  );
  console.log(`First record in descending sort: ${firstRecord}`);
  await this.AssertTrue(
    firstRecord.includes(newlyCreatedRecordName),
    `Newly created '${newlyCreatedRecordName}' appears FIRST in descending sort`
  );
}

public async VerifyAscendingSort(
  
  newlyCreatedRecordName: string,
 
): Promise<void> {

  // Toggle to ascending
  await this.Click('locator', Locators.UpArrow, 'Sort Toggle Button');
  await this.watforNetwork();

  // Newly created record should be LAST
//  const totalCount = await this.getCount(recordsLocator, labelName);
  const lastRecord = await this.getText(
    'locator',
    `//div/img[@src='/images/svg/Entity_Dpt.svg']/parent::div/following-sibling::div[normalize-space()='${newlyCreatedRecordName}']`,
    `Last Record`
  );
  console.log(`Last record in ascending sort: ${lastRecord}`);
  await this.AssertTrue(
    lastRecord.includes(newlyCreatedRecordName),
    `Newly created '${newlyCreatedRecordName}' appears LAST in ascending sort`
  );
}

public async VerifyInitiatorChekBoxState()
{
  await this.CheckBox(Locators.CheckDisableReferBackToInitiator, UserData.DisableReferBackToInitiator);
}

public async VerifyUncheckInitiatorCheckBoxState()
{
  await this.UnCheckBox(Locators.CheckDisableReferBackToInitiator, UserData.DisableReferBackToInitiator);
}

public async VerifyReferBackChekBoxState()
{
  await this.CheckBox(Locators.checkDisableReferBack, UserData.DisableReferBack);
}

public async VerifyUncheckReferBackCheckBoxState()
{
  await this.UnCheckBox(Locators.checkDisableReferBack, UserData.DisableReferBack);
}

public async VerifyFormEditChekBoxState()
{
  await this.CheckBox(Locators.CheckDisableFormEdit, UserData.DisableFormEdit);
}

public async VerifyUncheckFormEditCheckBoxState()
{
  await this.UnCheckBox(Locators.CheckDisableFormEdit, UserData.DisableFormEdit);
}

public async VerifyFormEditCheckDelegate()
{
  await this.CheckBox(Locators.CheckDelegate, UserData.Delegate);
}

public async VerifyUncheckFormEditCheckDelegate()
{
  await this.UnCheckBox(Locators.CheckDelegate, UserData.Delegate);
}

public async IsDelegateCheckBoxDisabled()
{
    await this.ElementDisplayed(Locators.CheckDelegate, UserData.Delegate);
    const checkedAttr = await this.getAttribute(Locators.CheckDelegate, "class");
    await this.AssertTrue(checkedAttr == 'ant-checkbox ant-checkbox-disabled', `${UserData.Delegate} is Disabled and cannot be checked or unchecked`);
}

public async IsDelegateCheckBoxEnabled()
{
    await this.ElementDisplayed(Locators.CheckDelegate, UserData.Delegate);
    const checkedAttr = await this.getAttribute(Locators.CheckDelegate, "class");
    await this.AssertTrue(checkedAttr == 'ant-checkbox', `${UserData.Delegate} is Enabled to checked or unchecked`);
}

public async ActiveToggleButton(): Promise<void> {
  try {
    await this.checkAndToggle(
      Locators.EnableDelegateToggle,  
      Locators.EnableDelegateToggle,  
      "aria-checked",         
      UserData.EnableDelegate   
    );
    await this.sleep(2000);
    await this.checkAndToggle(
      Locators.EnableDelegateToggleOFF,  
      Locators.EnableDelegateToggleOFF,  
      "aria-checked",         
      UserData.EnableDelegate   
    );
  } catch (error) {
    console.error("Failed to toggle Active button", error);
    throw new Error(
      `Runtime exception while toggling Active button: ${String(error)}`
    );
  }
}

 public async InActiveToggleButton()
  : Promise<void> {
  try {
    await this.checkAndToggle(
      Locators.EnableDelegateToggle,  
      Locators.EnableDelegateToggle,  
      "aria-checked",         
      UserData.EnableDelegate   
    );
    
  } catch (error) {
    console.error("Failed to toggle Active button", error);
    throw new Error(
      `Runtime exception while toggling Active button: ${String(error)}`
    );
  }
}

public async NoApprovalStageRequireCheckBox()
{
  await this.CheckBox(Locators.NoApprovalCheckBox, UserData.NoApprovalRequired);
}

public async AssertToggleState(): Promise<void> {
  const ariaChecked = await this.getAttribute(`//div/label[normalize-space()='Enable delegate for initiator']/parent::div/button`, 'aria-checked');
  console.log(`Toggle state of ${UserData.EnableDelegate}: ${ariaChecked}`);
  if(ariaChecked === 'true')
  {
      await this.AssertTrue(ariaChecked === 'true',`${UserData.EnableDelegate} toggle is ON`);
  }
  else
  {
    await this.AssertTrue(ariaChecked === 'false',`${UserData.EnableDelegate} toggle is OFF`);
  }
  
}

// public async AssertToggleIsOFF(): Promise<void> {
//   const ariaChecked = await this.getAttribute(`//div/label[normalize-space()='Enable delegate for initiator']/parent::div/button`, 'aria-checked');
//   console.log(`Toggle state of ${UserData.EnableDelegate}: ${ariaChecked}`);
//   await this.AssertTrue(
//     ariaChecked === 'false',
//     `${UserData.EnableDelegate} toggle is OFF`
//   );
// }

public async ClickBIACard()
{
    await this.Click('locator', `//a/div/div/p[normalize-space()='BIA Master']`, 'BIA Master Card');
}

public async VerifyBIAFields()
{
    await this.ElementDisplayed(Locators.BIANew, 'BIA New');
    await this.ElementDisplayed(Locators.RAFilter,UserData.RAFilter);
    await this.ElementDisplayed(Locators.RADepartment, UserData.RADepartment);
    await this.ElementDisplayed(Locators.CreatedBy, UserData.CreatedBY);
    await this.ElementDisplayed(Locators.CreatedDate, UserData.CreatedDate);
    await this.ElementDisplayed(Locators.RAStatus, UserData.RAStatusColumn);
    await this.ElementDisplayed(Locators.RAVersion,UserData.RAVersion);
}

public async IsFinishAndDelegateVisible()
{
  await this.ElementDisplayed(Locators.FinishAndDelegate,UserData.FinishAndDelegate);
}

public async ClickRARecord()
{
  await this.doubleClick('locator', `(//tbody/tr/td[normalize-space()='SuryaPWD'])[1]`, 'RA Record');
}

public async ClickRiskDetails()
{
  await this.Click('locator', `//li/a[@title='Risk Details']`, 'Risk Details');
}

public async ClickEdit()
{
  await this.Click('locator', `//tr/td/span[normalize-space()='Edit']`, 'Edit Button');
}

public async IsFinishAndDelegateNotVisible() {
  const isVisible = await this.checkFromListOfElement(
    Locators.FinishAndDelegate, 
    UserData.FinishAndDelegate
  );
  await this.AssertFalse(isVisible, `${UserData.FinishAndDelegate} is not visible`);
}

public async ClickActionCentre()
{
  await this.Click('locator', Locators.ActionCenter, UserData.actionCenter );
}

public async basicDetails(RAForm:RAFormSubmit){
        
        //Excel 
         //await this.TypeHeadDropdown(Locators.Department,Locators.DepartmentOption,ExcelUtility.getRAValue("Action Owner",TestcaseID,),UserData.DepartmentLabel);
          // await this.utility.TypeHeadDropdown(Locators.PrimarySPOC,Locators.PrimarySPOCDD,ExcelUtility.getRAValue("Primary SPOC",TestcaseID,),UserData.PrimarySPOCLabel);
           // await this.utility.selectDDValue(StaticFields.Status,ExcelUtility.getRAValue("Status",TestcaseID,),UserData.StatusLabel);


        //Test 
       // await this.Department(1); 
        await this.sleep(10000);
        await this.TypeHeadDropdown(Locators.Department,Locators.DepartmentOption,RAForm.Department,UserData.DepartmentLabel,{timeout:60000});
         await this.utility.TypeHeadDropdown(Locators.PrimarySPOC,Locators.PrimarySPOCDD,RAForm.PrimarySPOC,UserData.PrimarySPOCLabel);
         await this.utility.selectBasicDDValue(StaticFields.Status,RAForm.Status,UserData.StatusLabel);
         await this.utility.ModuleRightArrow();
            //await this.utility.Enter(Locators.DocumentName,ExcelUtility.getRAValue("Document Name",1,));
    }


public async BasicDetailsTab(){
        let basicDetailsTab = new RAFormSubmition()
        .setDepartment("Business::Risk Central::SDET")
        .setPrimarySPOC("SuryaPWD")
        .setStatus("Active")
        .build();
        const basicDetailsForm = await this.basicDetails(basicDetailsTab);

        //return basicDetailsForm;
    }

public async ClickUpComing()
{
  await this.Click('locator', `//li/a[@href = '#Upcoming']`, 'Upcoming Task');
}

public async ClickRiskRecord(title:string)
{
  await this.doubleClick('locator', `//tr/td/span[normalize-space()='${title}']`, 'Tasks');
}

public async ClickReviewerAction()
{
  await this.Click('locator', `//li/a[@role = 'tab' and @title = "Reviewer's Action"]`, "Reviewer's Action");
}

// public async ClickNeedForCorrection()
// {
//   await this.Click('locator', `//label[normalize-space()='Needs Correction']/input[@type='radio']`, 'Needs Correction')
//   await this.ElementDisplayed(`(//label[normalize-space()='Initiator']/input[@type='radio'])[1] `, 'Intiator');
// }

// Click the LABEL (visible) instead of the hidden input
public async ClickNeedForCorrection(): Promise<void> {
  // Use LoopClick - it checks isVisible() and clicks the first visible match
  await this.LoopClick(
    "//label[normalize-space()='Needs Correction']",
    "Needs Correction"
  );
}

// Assert the radio is selected after clicking
public async AssertNeedsCorrectionSelected(): Promise<void> {
  // Use radioButton - checks 'checked' class attribute before clicking
  await this.radioButton(
    "//label[normalize-space()='Needs Correction']",
    "//label[normalize-space()='Needs Correction']/input[@type='radio']",
    "Needs Correction"
  );
}

public async IsInitiatorButtonDisplayed()
{
 const isDisplayed = await this.checkFromListOfElement(
    "//div[@id='divReject']//div[contains(@class,'radioInitiatorDiv')]",
    "Initiator"
  );
  await this.AssertTrue(isDisplayed, "Initiator Radio Button");
}

public async IsDelegateToVisible()
{
  await this.ElementDisplayed(`(//span/span[normalize-space()='Please Select Delegate User'])[1]`, 'Delegate To');
}

public async ClickDelegate(): Promise<void> {
  // Use LoopClick - it checks isVisible() and clicks the first visible match
  await this.LoopClick(
    "//label[normalize-space()='Delegate']",
    "Needs Correction"
  );
}

public async IsNeedsCorrectionNotDisplayed(): Promise<void> {
  
  const styleValue = await this.getAttribute("//label[normalize-space()='Needs Correction'][@style]","style");

  console.log(`Needs Correction label style: ${styleValue}`);

  const isNotVisible = styleValue?.includes("display:none") ?? true;
  await this.AssertTrue(isNotVisible, "Needs Correction Radio Button is Not Visible");
}

}