import { Page } from "@playwright/test";
import { CommanUtility } from "../../utils/CommanUtility";
import { SiomottoLocators as L } from "./SiomottoLocators";

export default class SiomottoHomePage extends CommanUtility {
  constructor(protected page: Page) {
    super(page);
  }

  async open() {
    await this.stepWithScreenshot("Opened Siomotto home page", async () => {
      await this.page.goto(process.env.STAGE_URL!);
    });
  }

  
 async selectLocation(city: string, resultText: string) {
  await this.Click("locator", L.ChooseLocationButton, "Choose location");
  await this.Enter("locator", L.LocationSearchInput, "Location search", city);
  await this.Click("locator", L.LocationResult(resultText), resultText);
  await this.page
    .locator(L.LocationSearchInput)
    .waitFor({ state: "hidden", timeout: 15000 })
    .catch(() => {});
}

  
  async openCategory(name: string) {
  await this.Click("locator", L.CategoryCard(name), `${name} card`, { timeout: 20000 });
}
}