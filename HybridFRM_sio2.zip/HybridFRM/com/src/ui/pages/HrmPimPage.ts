import { Page } from "@playwright/test";
import { CommanUtility } from "../../utils/CommanUtility";
import { Locators } from "./Locators";

export class HrmPimPage extends CommanUtility {
  constructor(protected page: Page) {
    super(page);
  }

  async openMenu() {
    await this.Click("locator", Locators.PimMenu, "PIM Menu");
  }

  async openAddEmployee() {
    await this.Click("locator", Locators.AddEmployeeTab, "Add Employee Tab");
  }

  async addEmployee(firstName: string, lastName: string) {
    await this.Enter("locator", Locators.FirstName, "First Name", firstName);
    await this.Enter("locator", Locators.LastName, "Last Name", lastName);
    await this.Click("locator", Locators.SaveButton, "Save Button");
  }

  async verifySuccessToast(expected: string) {
    const actual = await this.getText("locator", Locators.SuccessToast, "Success Toast");
    await this.Equals(actual, expected); // "contains" check
  }
}