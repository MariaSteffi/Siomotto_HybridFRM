export class SiomottoLocators {
  static ChooseLocationButton = 'role=button[name="Choose location"s]';
  static LocationSearchInput = 'role=textbox[name="Search for your location..."]';
  static LocationResult = (t: string) => `text="${t}"`;
  static CategoryCard = (name: string) => `a:has-text("${name}") >> nth=0`;
  static SearchBox = 'role=textbox[name="Search by city or area"]';
  static Suggestion = (t: string) => `:is(button, li, div[role="option"]):has-text("${t}") >> nth=0`;
  static MinPrice = "input[placeholder='Min Price']";
  static MaxPrice = "input[placeholder='Max Price']";
  static ApplyButton = 'role=button[name="Apply"]';
  static ViewOwnerContact = 'role=button[name="View Owner Contact"] >> nth=0';
  static ViewOwnerContactAll = 'role=button[name="View Owner Contact"]';
  static ProceedButton = 'role=button[name="Proceed"]';
  static CancelButton = 'role=button[name="Cancel"]';
  static LoginRequiredMessage = "text=/Please login to view owner/i";
  static ContactDetails = 'a[href^="tel:"] >> nth=0';
  static LoginButton = 'role=button[name="Login"] >> nth=0';
  static MobileInput = 'role=textbox[name="Enter Your Number"]';
  static GetOtpButton = 'role=button[name="Get OTP"]';
  static OtpBox = (i: number) => `#otp-${i}`;
  static IndividualButton = 'role=button[name="Individual Personal use"]';
}