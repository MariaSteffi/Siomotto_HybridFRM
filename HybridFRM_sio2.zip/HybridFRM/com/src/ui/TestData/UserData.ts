export class UserData {
  
  public static PasswordLabel: string = "Password  field";
  public static LoginLabel: string = "Login button";
  public static LoginValidation = "power_settings_ne";
  public static Application = "Application Module";
  public static SystemPreferences = "System Preferences Module";
  public static AccessRights = "Access Rights Management Module";
  public static TemplateHub = "Template Hub Module";
  public static actionPlan = "Action Plan Module";
  public static actionCenter = "Action center Module";
  public static WorkFlowDesigner = "WorkFlow Designer Module";
  public static VendorMaster: string = "VendorMaster subModule";
  public static VendorNew: string = "Vendor New button";
  public static Department: string = "Business::Test Z::Test Dept";
  public static SaveButton: string = "Save Button";
  public static CloseButton: string = "Close Button";
  public static RightArrow: string = "> Arrow";
  public static EditButton: string = "Edit button";
  public static AddNewStageButton: string = "Add New Stage button";
  public static AddNewRoleButton: string = "Add New Role button";
  public static BusinessEntity: string = "Business Entity";
  public static EnterpriseEntity: string = "Enterprise Entity";
  public static ExecutionEntity: string = "Execution Entity";
  public static RoleSearch: string="Search field";
  static BIAmaster: string= "BIA Master Card";
  static NoOFStage: string = "Number of Approval Stages field";
  static StageName: string = "Stage Name field";
  static ApprovalStage: string = "Approval Radio Button";
  static NeedCorrectionStage: string = "Needs Correction Radio Button"; 
  static AbortStage: string = "Abort Radio Button";
  static AssignTo: string = "Assign User/Role field";
  public static MasterDataModule :string="Master Data Management card";
  public static MasterDataManagement:string="Master Data Drop down";
  public static DropDownValueMaterData:string ="Master Data";
  public static MasterDataDropdown :string = "Master Data Dropdown";
  public static NameColumn :string = "Name Column";
  public static CreateButton :string ="Create Button is displayed";
  public static NameInputField:string ="Name Input Field";
  public static AddButton:string ="Add Button";
  public static CancelButton:string ="Cancel Button";
  public static SuccessMessage :string= " 'Success' , Message";
  public static SelectMasterData: string="Selected master data  drop down value";
  public static MasterDataPage:string="Select master data field is visible";
  public static ErrorMessage:string="'Name cannot be empty', Error message";
  public static EnterdName:string="Enterd Name value";
  public static AddedDataValue:string="Added Value ";
  
  

  static ReviewWithIn: string = "Review Within field";
  static isUnanimous: string ="Is Unanimous Approval Radio Button";
  static BIAMasterFirstRecord: string= "First record in BIA Master Card";
  static EntityHierarchy: string = "Entity Hierarchy Module";
  static AddNewEntityButton: string = "Add New Entity Button";
  static SelectEntity: string = "Select Entity field";
  static EntityName: string = "Entity Name field";
  static tickIcon: string = "Tick icon";
  static DepartmentLabel: string = "Department field";
  static PrimarySPOCLabel: string = "Primary SPOC field";
  static StatusLabel: string = "Status field";
  static DocumentNameLabel: string = "Document Name field";
  public static DocumentNumberLabel: string = "Document Number field";
  public static DocumentOwnerLabel: string = "Document Owner field";
  public static DistributionListLabel: string = "Distribution List field";
  public static ChangeHistoryLabel: string = "Change History field";
  public static RiskDriverLabel: string = "Risk Driver field";
  public static RiskEventDescriptionLabel: string = "Risk Event Description field";
  public static RiskImpactLabel: string = "Risk Impact field";
  public static RiskCategoryLabel: string = "Risk Category field";
  public static RiskImpactRatingLabel: string = "Risk Impact Rating field";
  public static RiskLikelihoodRatingLabel: string = "Risk Likelihood Rating field";
  public static ExistingControlLabel: string = "Existing Control field";
  public static ControlEffectivenessLabel: string = "Control Effectiveness field";
  public static RiskTreatmentStrategyLabel: string = "Risk Treatment Strategy field";
  public static RiskResponseStrategyLabel: string = "Risk Response Strategy field";

   //Roles and users
  public static RolesUsers = "Roles &  Users Module";
  public static Importbutton  = "Import button";
  public static DownloadExcelbutton = "Download Excel Template button";
  public static ChooseFile : string = "";
  public static SortModbutton : string = "Sort Option Dropdown";
  public static SortAplhabutton : string = "Alphabetically button";
  public static UpArrow : string = "Up Arrow button";
  public static DownArrow : string = "Down Arrow button";
  public static SearchBar : string = "Search Bar Field";
  public static AddNewRole : string = "Add Role button";
  public static AddRoleName : string = "Role Name Field";
  public static Description : string = " Description Field";
  public static ActiveToggle : string = "Active Toggle button";
  public static Close : string = "Close Button";
  public static SaveTick : string = "Save Button";
  public static AccordianDown : string = "Accordian Down Arrow button";
  public static BreifCaseIcon : string = "Breifcase Icon ";
  public static RoleName : string = "Role Name";
  public static EditPenIcon : string = "Edit Pen Icon";
  public static DeleteIcon : string = " Delete Icon Button";
  public static InputField : string = "Input Field for Role Name";
  public static Descriptionfield : string = "Description Field ";
  public static DescriptionfieldText : string = "Text in Description Field ";
  public static NegativeValidation : string = "Please Enter Role Name Message";
  public static DeleteConfirmation : string = "Delete Confirmation";
  public static ConfirmationText : string = "Are you sure you want to delete? ";
  public static YesDeleteButton : string = "Yes Button";
  public static NoDeleteButton : string = "No Button";
  public static RUAccordianButton : string = "Accordian Button"; 
  public static AssignUser : string = "Assign User Button";
  public static UserRole : string = "Users";
  public static CloseUser : string = "Close Button";
  public static CreateNewuser : string = "Create New User Button";
  public static SaveAssigneduser : string = "Save Button";
  public static SearchIcon : string = "Search Icon Button";
  public static RoleNameVisiblity : string = "Role Name with Mandatory symbol is visible";
  public static DescriptionVisiblity : string = "Description Field";
  public static ActiveToggleInactive : string = "Active toggle button is inactive";
  public static ActiveToggleActive : string = "Active toggle button is active";
 // public static ActiveToggle : string = "Activated Acvtive Toggle button";

  public static Firstname : string = "FIRST NAME Column";
  public static Lastname : string = "LAST NAME Column";
  public static UserName : string = "USERNAME Column";
  public static DesignationField : string = "DESIGNATION Column";
  public static LocationField : string = "LOCATION Column";
  public static Emailfield : string = "EMAIL Column";
  public static Phone : string = "PHONE Column";
  public static SuperVisor : string = "SUPERVISOR Column";
  public static paginationNumber : string = "1 Page "
  public static LeftArrow: string = "< Arrow";
  public static FirstNameInp : string = "First Name Input field";
  public static LastNameInp : string = "Last Name Input field";
  public static UsernameInp : string = "User Name Name Input field";
  public static DesignationInp : string = "Designation Input field";
  public static LocationInp : string = "Location Input field";
  public static EmailInp : string = "Email Input field";
  public static PhoneInp : string = "Phone Input field";
  public static SupervisorInp : string = "Supervisor Input field";
  public static PasswordInp : string = "Password Input field";
  public static ConfirmPasswordInp : string = "Confirm Password Input field";
  public static CreateNew : string = "Create Button";
  public static Pagination : string = "Pagination button";
  public static PasswordEye : string = "Visibility toggle icon" ;
 // public static RightArrow: string = "> Arrow";

  public static ValidationFirstNameMessage : string = "Please enter First name";
  public static ValidationSuccessMessage : string = "Success";
  public static ValidationMessage : string = "Please enter Role Name";
  public static Deletetitle : string = "Delete title";
  public static DeleteConfiemationmessage : "Delete Confiemation message";

  public static MenuButton : string = "Kebab Menu";
  public static EditUser : string = "Edit User Details";
  public static UpdateButton : string = "Update Button";

  public static SelectUser : string = "Selected the User";
  public static Unassignuser : string = "Unassign User Button";
  
  public static UsersCard : string = "Users Module";
  public static UserSearchFields : string = "Input Search Field";

  public static MakeEntityowner : string = "Make Entity Owner Button";
  //public static
 // public static UserFormInp : string = "UserForm Input field";
  static WorkshopDateLabel: string = "Workshop Date field";
  static WorkshopParticipantsNameLabel: string = "Workshop Participants Name field";
  static WorkshopParticipantsTitleLabel: string = "Workshop Participants Title field";
  static SubDepartmentLabel: string = "Sub-Department Name field";
  static SupportingServiceName: string = "Supporting Service Name field";
  static ActivityName: string = "Activity Name field";
  static ActivityDescription: string = "Activity Description field" 
  static ActivityLocation: string = "Activity Location field";
  static LocationLatAndLong: string = "Location Lat & Long field"
  static ActivityPeakTime: string = "Activity Peak Time field";
  static ActivityOwner: string = "Activity Owner field"
  static Criticality: string = "Criticality field";
  static DepartmentCode: string= "Department Code field";
  static fourhoursFI: string = "4 hours (FI) field";
  static eightHoursFI: string = "8 Hours (FI) field";
  static twentyFourHoursFI: string = "24 Hours (FI) field";
  static seventyTwoHoursFI: string = "72 Hours (FI) field";
  static oneWeekFI: string = "1 Week (FI) field";
  static twoWeekFI: string = "2 Weeks (FI) field";
  static oneMonthFI: string = "1 Month (FI) field";
  static fourHoursRI: string = "4 Hours (RI) field";
  static eightHoursRI: string = "8 Hours (RI) field";
  static twentyFourHoursRI: string = "24 Hours (RI) field";
  static seventyTwoHoursRI: string = "72 Hours (RI) field";
  static oneWeekRI: string = "1 Week (RI) field";
  static twoWeekRI: string = "2 Weeks (RI) field";
  static oneMonthRI: string = "1 Month (RI) field"; 
  static fourhoursREI: string = "4 Hours (REI) field";
  static eightHoursREI: string = "8 Hours (REI) field";
  static twentyFourHoursREI: string = "24 Hours (REI) field"; 
  static seventyTwoHoursREI: string = "72 Hours (REI) field";
  static oneWeekREI: string = "1 Week (REI) field";
  static twoWeekREI: string = "2 Weeks (REI) field";
  static oneMonthREI: string = "1 Month (REI) field"; 
  static fourHoursOI: string = "4 Hours (OI) field";
  static eightHoursOI: string = "8 Hours (OI) field";
  static twentyFourHoursOI: string = "24 Hours (OI) field";
  static seventyTwoHoursOI: string = "72 Hours (OI) field";
  static oneWeekOI: string = "1 Week (OI) field"  ;
  static twoWeekOI: string = "2 Weeks (OI) field";
  static oneMonthOI: string = "1 Month (OI) field"; 
  static fourHoursCI: string = "4 Hours (CI) field";
  static eightHoursCI: string = "8 Hours (CI) field";
  static twentyFourHoursCI: string = "24 Hours (CI) field";
  static seventyTwoHoursCI: string = "72 Hours (CI) field"; 
  static oneWeekCI: string = "1 Week (CI) field";
  static twoWeekCI: string = "2 Weeks (CI) field";
  static oneMonthCI: string = "1 Month (CI) field"; 

  static ImportButton: string = "Import button"; 
  static DownloadExcelButton:string="Download Excel Button";
  static ExportButton:string="Export Button";
  static EnterpriseFormsLabel:string="EnterpriseEntity form";
  static ExecutionFormLabel:string="ExecutionEntity form";
  static AddEntityButton:string=" Add Entity Button ";
  static EntityTypeField:string="Entity Type field";
  static NameField:string=" Name field ";
  static PraentEntityField:string="Parent Entity Field ";
  static EntityTypeClick:string="Clicked on Entity type field";
  static Alphabetically:string=" Sorted alphabetically";
  static ErrorMsgEntityType:string=" 'Please enter Entity Type' error message";
  static ErrorMsgName:string=" 'Please enter Entity Name' error message ";
  static UpdatedName:string="Updated  field";
  static Disabled:string="Disabled ";
  static ReadOnly:string="ReadOnly mode";
  static EnteredYes:string="Enterd 'Yes ' to delete the form ";
 static ClickedNo:string="Entity should NOT be deleted after clicking No";
  static ClickedDeleteIcon:string= "Delete confirmation popup should be displayed";
  static popUpClosed:string="Popup should be closed after clicking No";
  static PopUpYes:string="Entity should be deleted after clicking Yes";
  static ToggleEnabled:string="Active toggle should be enabled by default";
  static ToggleInactive:string="Toggle should be Inactive after clicking";
  static CloseIcon:string="Add Entity form should be closed after clicking X icon";
  static SavedSuccess:string="Entity should be saved successfully";
  static PanelList:string="Newly created entity should be displayed in panel list";
  static EntityType:string="Entity Type field";
  static SortValue:string="Sort DropDown";
  static ModifiedDD:string="Modified Date Sort Dropdown";
  static SelectPEntity:string="Select Parent entity";
  static AddChild:string="Add Child Entity Button";
  static ArrowDown:string="Arrow down";

 //DashBoard
  static DashBorad:string="DashBoard";
  static AssignDashBoardModule:string="Assign DashBoard And HeatMaps Module";
  static ModifiedCol:string="Modified Column ";
  static ActionCol:string="Action Column "; 
  static Scheduler:string="Scheduler Icon";
  static AssignIcon:string="Assign Icon";
  static SelectedDB:string="Selected DashBoard label";
  static ClearAllAssignment:string="Clear all assignmet button";
  static EntityRole:string="Entity and Role Label";
  static SelectAddRole:string="Select Add role Heading";
  static Nodata:string="No Results Found Message";
  static SortAlpha:string= "Records are sorted in alphabetical order";
  static SortAsc:string="Records are sorted in ascending order";
  static MatchRes:string="Matching search results should be displayed";
  static SIconTrigger:string="Search should be triggered after clicking Search icon";
  static userUnderRole:string="User under Role";
  static UserGrid:string="Users Grid";
  static UserRightsideGrid:string="Right Side User List";
  static Deselect:string="Deselecting the user";
  static userButton:string="All User Button";
  static hierarchyIcon:string="Hierarchy Icon";
  static SelectUserAdd:string="Select User to Add  Heading";
  static popUp:string="PopUp box";
  static frequencyPatern:string="Frequency pattern label";
  static BIAdashboard:string="BIA Dashboard";
  static ClearAssignment:string="Clear All Assignments";
  static selectdefault:string="User should be selected by default";
   static deselectAfterClick:string= "User should be deselected after clicking";
   static CloseAfterSave:string="Popup should be closed after clicking Save";
  static VisibleUnderRandEntities:string="Selected user should be visible under Entities & Roles";
  static DeselectUserNotVisible:string="Deselected user should NOT be visible in Update page";
  static PopUpCloseCross:string="Select User popup should be closed after clicking cross icon";
  static BackToPreviousState:string="User should return to Update Dashboard Assignment page";
  static DltPopup:string="Delete confirmation popup should be displayed";


//licence
  static LicencesModule:string="Licences Module";
  static LicenceNavBar:string="Licence In Navigation Bar";
  static Revokebtn:string="Revoke Button";
  static userMaping:string="User Mapping";
  static KeyCol:string="Key Column";
  static ProductFeature:string="Product Feature Column";
  static NoControlAvl:string="No Control Available";
  static AssinLicensUser:string="Assign Licence to More user";
  static Form1:string="List of licensed users";
  static form2:string="License Details";
  static LicenceAssign:string="Licence:Assign page";
  static userDetails:string="User :Details page";
  static ResetPass:string="Reset Password button";
  static NewPass:string="New paasword field";
  static ConfirmPass:string="Confirm new password";
  static Savechnges:string="Save changes button";
  static CharacterList:string="5 more characters, At least 1 more symbol, 1 Upper case characters, 1 lower case character";
  static HardPassMsg:string="Choose a password that's harder for people to guess";
  static Passrqrd:string="Password field is required";











  public static UserMapping: string = 'User Mapping Button';
  public static UserMappingtitle : string = '"Import License to User Mapping" title'
  public static SelectFileField : string = "Select File Field"
  public static BrowseField : string = "Browse Field";



























  public static NoApprovalRequired: string = "No Approval Stages Required"
  public static Approval: string = "Approve";
  public static CheckBox: string = "Check Box";
  public static ReviewDaysUp: string = "Up Arrow";
  public static ReviewDaysDown : string = "Down Arrow";
  public static ReviewWithin: string = "Review within";
  public static IsThisStageMandatoryCheckBox: string = "Is This Stage Mandatory";
  public static DeleteStageButton: string = "Delete Stage Button";
  public static UnanimousApproval : string = 'Unanimous approval is mandatory';
  public static SaveStages: string = "Save button";
  public static CloseStages: string = "Close Button";
  public static CircleCrossIcon: string = "Circle Cross Icon";
  public static SortOption: string = "Sort Option";
  public static Filterdropdown: string = "Filter Dropdown";
  public static NeedsCorrectin: string = 'Needs Correction';

  public static RAFilter: string = 'Filter Button'
  public static RiskID: string = 'Risk ID Column';
  public static RADepartment: string = 'Department Column';
  public static RiskEventDescritption: string = 'Risk Event Description Coloumn';
  public static RAModifiedBy : string = 'Modified By Column';
  public static RAModifiedDate : string = 'Modified Date Column';
  public static ResidualRisk : string = 'Residual Risk Rating Column';
  public static RAStatusColumn : string = 'Status Column';
  public static RAVersion : string = 'Version Column';
  public static DisableReferBackToInitiator : string = 'Disable Refer Back To Initiator';
  public static DisableReferBack : string = 'Disable Refer Back';
  public static DisableFormEdit :  string = 'Disable Form Edits';
  public static Delegate : string = 'Delegate';
  public static EnableDelegate : string = 'Enable delegate for initiator'
  public static CreatedBY : string = 'Created By Column';
  public static CreatedDate : string = 'Created Date Column';
  public static FinishAndDelegate : string = 'Finish and Delegate Button';
  public static ReferBackToInitiator : string = 'Refer Back To Initiator';
  public static HeaderCheckBox : string = 'Header Check Box';
  public static InProgress : string = 'InProgress';










  public static ExportUsers : string = 'Export Users';
  public static ImportUsers : string = 'Import Users';
  public static ShowEntries : string = 'Show Entries';
  public static Search :  string = 'Search Field';
  public static ImportButon : string = 'Import Button';
  public static CloseImport : string = 'Close Button';
  public static NextArrow : string = 'Next Arrow';


  public static TaskReassignment : string = 'Task Reassignment';
  public static ReassignTask  : string = 'Reassign Task';
  public static Show : string = 'Show Filter';
  public static All : string = 'All Option';
  public static KPI : string = 'KPI Option';
  public static Action : string = 'Action Option';
  public static VendorReKyc : string =  'Vendor ReKyc Option';
  public static Compliance : string = 'Compliance Option';
  public static Event : string = 'Event Option';
  public static CallTreeMatrixReview : string = 'Call Tree Matrix Review Option';
  public static VendorRatingReview : string = 'Vendor Rating Review Option';
  public static DueDiligence : string = 'Due Diligence Option';
  public static RiskResponce : string = 'Risk Responce Option';
  public static BIAReview : string = 'BIA Review';
  public static Incident : string = 'Incident Option';
  public static BCPReview : string = 'BCP Review Option';
  public static BusinessImpact : string = 'Business Impact Analysis Option';
  public static ActionPlan : string = "Action Plan Option";
  public static RAReview : string = 'RAReview Option';
  public static KRI : string = 'KRI Option';
  public static VendorReview : string = 'Vendor Review Option';
  public static ITBIAReview : string = 'IT BIA Review Option';
  public static SearchTask : string = 'Search Bar';
  public static DeleteTask : string = 'Delete Task Button';

}
