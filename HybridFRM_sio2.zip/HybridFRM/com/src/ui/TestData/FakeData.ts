import { faker } from "@faker-js/faker";

export class FakeData {

  //  PERSON
  static FirstName(): string {
    return faker.person.firstName();
  }

  static LastName(): string {
    return faker.person.lastName();
  }

  static FullName(): string {
    return faker.person.fullName();
  }

  static Gender(): string {
    return faker.person.sex();
  }

  static JobTitle(): string {
    return faker.person.jobTitle();
  }

  //  INTERNET
  static Email(): string {
    return faker.internet.email();
  }

  static Username(): string {
    return faker.internet.username();
  }

  static Password(length: number = 10): string {
    return faker.internet.password({ length });
  }

  static Url(): string {
    return faker.internet.url();
  }

  static Ip(): string {
    return faker.internet.ip();
  }

  //  PHONE
  static PhoneNumber(): string {
    return faker.phone.number();
  }

  //  ADDRESS
  static Street(): string {
    return faker.location.street();
  }

  static City(): string {
    return faker.location.city();
  }

  static State(): string {
    return faker.location.state();
  }

  static Country(): string {
    return faker.location.country();
  }

  static ZipCode(): string {
    return faker.location.zipCode();
  }

  static FullAddress(): string {
    return faker.location.streetAddress();
  }

  //  FINANCE
  static Amount(min: number = 1, max: number = 10000): string {
    return faker.finance.amount({ min, max });
  }

  static AccountNumber(): string {
    return faker.finance.accountNumber();
  }

  static Currency(): string {
    return faker.finance.currencyCode();
  }

  //  DATE
  static PastDate(): string {
    return faker.date.past().toISOString();
  }

  static FutureDate(): string {
    return faker.date.future().toISOString();
  }

  static RecentDate(): string {
    return faker.date.recent().toISOString();
  }

  //  NUMBER
  static RandomNumber(min: number = 1, max: number = 1000): string {
    return String(faker.number.int({ min, max }));
  }

  static Float(min: number = 1, max: number = 100): number {
    return faker.number.float({ min, max });
  }

  //  TEXT
  static Word(): string {
    return faker.word.sample();
  }

  static Sentence(): string {
    return faker.lorem.sentence();
  }

  static Paragraph(): string {
    return faker.lorem.paragraph();
  }

  static UUID(): string {
    return faker.string.uuid();
  }

  static Alphanumeric(length: number = 10): string {
    return faker.string.alphanumeric(length);
  }

  
}

