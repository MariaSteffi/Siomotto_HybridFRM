export class StaticFields {
    public static AddNewStageButton: string = "Add New Stage";
  
}