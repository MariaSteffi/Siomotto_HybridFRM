export enum Cards {
  Enterprise = "Enterprise",



} 

export enum Entity{
  Enterprise = "Enterprise",
  Business = "Business",
  Execution = "Execution"

} 
export enum StageActions{
  Approval = "Approve",
  NeedCorrection = "Needs Correction",
  Abort = "Abort",
  Delegate = "Delegate",
  Extend = "Extend"
}
