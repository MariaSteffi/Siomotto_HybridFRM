export interface BIAFormSubmit{
    //Basic details
    Department: string;
    PrimarySPOC: string;
    DepartmentCode: string;
    Status: string;
    //Risk details
    DocumentName: string;
    DocumentNumber: string;
    DocumentOwner: string;
    DistributionList: string;
    ChangeHistory: string;
    WorkshopDate: string;
    WorkshopParticipantsName: string;
    WorkshopParticipantsTitle: string;
    SubDepartmentName: string;
    SupportingServiceName: string;
    ActivityName: string;
    ActivityDescription: string;
    ActivityLocation: string;
    LocationLatAndLong: string;
    ActivityPeakTime: string;
    ActivityOwner: string;
    Criticality: string;
    //BIA Assessment details
    //Financial Impact
    fourhoursFI: string;
    eightHoursFI: string;
    twentyFourHoursFI: string;
    seventyTwoHoursFI: string;
    OneWeekFI: string;
    twoWeeksFI: string;
    OneMonthFI: string;
    //Operational Impact
    fourhoursOI: string;
    eightHoursOI: string;
    twentyFourHoursOI: string;
    seventyTwoHoursOI: string;
    OneWeekOI: string;
    twoWeeksOI: string;
    OneMonthOI: string;
    //Regulatory Impact
    fourhoursRI: string;
    eightHoursRI: string;
    twentyFourHoursRI: string;
    seventyTwoHoursRI: string;
    OneWeekRI: string;
    twoWeeksRI: string;
    OneMonthRI: string;
    //Reputational Impact
    fourhoursREI: string;
    eightHoursREI: string;
    twentyFourHoursREI: string;
    seventyTwoHoursREI: string;
    OneWeekREI: string;
    twoWeeksREI: string;
    OneMonthREI: string;
    //Customer Impact
    fourhoursCI: string;
    eightHoursCI: string;
    twentyFourHoursCI: string;
    seventyTwoHoursCI: string;
    OneWeekCI: string;
    twoWeeksCI: string;
    OneMonthCI: string;

    Remarks: string;

}

export class BIAFormSubmission {
   
    private BIAForm:Partial<BIAFormSubmit> = {};  

    setDepartment(department: string){
        this.BIAForm.Department = department;
        return this;

    }
    
    setPrimarySPOC(primarySPOC: string){
        this.BIAForm.PrimarySPOC = primarySPOC;
        return this;
    }
    setDepartmentCode(departmentCode: string){
        this.BIAForm.DepartmentCode = departmentCode;
        return this;
    }   
    setStatus(status: string){  
    this.BIAForm.Status = status;
    return this;
    }

    setDocumentName(documentName: string){
        this.BIAForm.DocumentName = documentName;
        return this;
    }
        setDocumentNumber(documentNumber: string){  
        this.BIAForm.DocumentNumber = documentNumber;
        return this;
    }
        setDocumentOwner(documentOwner: string){
        this.BIAForm.DocumentOwner = documentOwner;    
        return this;
    }
    setDistributionList(distributionList: string){
        this.BIAForm.DistributionList = distributionList;
        return this;
    }   
    setChangeHistory(changeHistory: string){
        this.BIAForm.ChangeHistory = changeHistory;
        return this;
     }  
    setWorkshopDate(workshopDate: string){

        this.BIAForm.WorkshopDate = workshopDate;
        return this;
    }   
    setWorkshopParticipantsName(workshopParticipantsName: string){
        this.BIAForm.WorkshopParticipantsName = workshopParticipantsName;
        return this;
    }   
    setWorkshopParticipantsTitle(workshopParticipantsTitle: string){
        this.BIAForm.WorkshopParticipantsTitle = workshopParticipantsTitle;
        return this;
    }

    setSubDepartmentName(subDepartmentName: string){
        this.BIAForm.SubDepartmentName = subDepartmentName;
        return this;
    }   
    setSupportingServiceName(supportingServiceName: string){
        this.BIAForm.SupportingServiceName = supportingServiceName;
        return this;
    }
    setActivityName(activityName: string){
        this.BIAForm.ActivityName = activityName;
        return this;
    }
    setActivityDescription(activityDescription: string){    
        this.BIAForm.ActivityDescription = activityDescription; 
        return this;
    }
    setActivityLocation(activityLocation: string){
        this.BIAForm.ActivityLocation = activityLocation;
        return this;
    }  
    setLocationLatAndLong(locationLatAndLong: string){
        this.BIAForm.LocationLatAndLong = locationLatAndLong;
        return this;
    }
    setActivityPeakTime(activityPeakTime: string){
        this.BIAForm.ActivityPeakTime = activityPeakTime;
        return this;
    }
    setActivityOwner(activityOwner: string){
        this.BIAForm.ActivityOwner = activityOwner;
        return this;
    }
    setCriticality(criticality: string){
        this.BIAForm.Criticality = criticality;
        return this;
    }
    setFourHoursFI(fourHoursFI: string){
        this.BIAForm.fourhoursFI = fourHoursFI;
        return this;
    }   
    setEightHoursFI(eightHoursFI: string){
        this.BIAForm.eightHoursFI = eightHoursFI;
        return this;
    }
    setTwentyFourHoursFI(twentyFourHoursFI: string){
        this.BIAForm.twentyFourHoursFI = twentyFourHoursFI;
        return this;
    }   
    setSeventyTwoHoursFI(seventyTwoHoursFI: string){
        this.BIAForm.seventyTwoHoursFI = seventyTwoHoursFI;
        return this;
    }
    setOneWeekFI(oneWeekFI: string){
        this.BIAForm.OneWeekFI = oneWeekFI;
        return this;
    }
    setTwoWeeksFI(twoWeeksFI: string){
        this.BIAForm.twoWeeksFI = twoWeeksFI;
        return this;
    }
    setOneMonthFI(oneMonthFI: string){
        this.BIAForm.OneMonthFI = oneMonthFI;
        return this;
    }
    setFourHoursOI(fourHoursOI: string){
        this.BIAForm.fourhoursOI = fourHoursOI;
        return this;
    }
    setEightHoursOI(eightHoursOI: string){
        this.BIAForm.eightHoursOI = eightHoursOI;
        return this;
    }
    setTwentyFourHoursOI(twentyFourHoursOI: string){
        this.BIAForm.twentyFourHoursOI = twentyFourHoursOI;
        return this;
    }
    setSeventyTwoHoursOI(seventyTwoHoursOI: string){
        this.BIAForm.seventyTwoHoursOI = seventyTwoHoursOI;
        return this;
    }
    setOneWeekOI(oneWeekOI: string){
        this.BIAForm.OneWeekOI = oneWeekOI;
        return this;
    }
    setTwoWeeksOI(twoWeeksOI: string){
        this.BIAForm.twoWeeksOI = twoWeeksOI;
        return this;
    }
    setOneMonthOI(oneMonthOI: string){
        this.BIAForm.OneMonthOI = oneMonthOI;
        return this;
    }
    setFourHoursRI(fourHoursRI: string){
        this.BIAForm.fourhoursRI = fourHoursRI;
        return this;
    }
    setEightHoursRI(eightHoursRI: string){
        this.BIAForm.eightHoursRI = eightHoursRI;
        return this;
    }
    setTwentyFourHoursRI(twentyFourHoursRI: string){
        this.BIAForm.twentyFourHoursRI = twentyFourHoursRI;
        return this;
    }
    setSeventyTwoHoursRI(seventyTwoHoursRI: string){
        this.BIAForm.seventyTwoHoursRI = seventyTwoHoursRI;
        return this;
    }
    setOneWeekRI(oneWeekRI: string){
        this.BIAForm.OneWeekRI = oneWeekRI;
        return this;
    }
    setTwoWeeksRI(twoWeeksRI: string){
        this.BIAForm.twoWeeksRI = twoWeeksRI;
        return this;
    }
    setOneMonthRI(oneMonthRI: string){
        this.BIAForm.OneMonthRI = oneMonthRI;
        return this;
    }
    setFourHoursREI(fourHoursREI: string){
        this.BIAForm.fourhoursREI = fourHoursREI;
        return this;
    }
    setEightHoursREI(eightHoursREI: string){
        this.BIAForm.eightHoursREI = eightHoursREI;
        return this;
    }
    setTwentyFourHoursREI(twentyFourHoursREI: string){
        this.BIAForm.twentyFourHoursREI = twentyFourHoursREI;
        return this;
    }
    setSeventyTwoHoursREI(seventyTwoHoursREI: string){
        this.BIAForm.seventyTwoHoursREI = seventyTwoHoursREI;
        return this;
    }
    setOneWeekREI(oneWeekREI: string){
        this.BIAForm.OneWeekREI = oneWeekREI;
        return this;
    }
    setTwoWeeksREI(twoWeeksREI: string){
        this.BIAForm.twoWeeksREI = twoWeeksREI;
        return this;
    }
    setOneMonthREI(oneMonthREI: string){
        this.BIAForm.OneMonthREI = oneMonthREI;
        return this;
    }
    setFourHoursCI(fourHoursCI: string){
        this.BIAForm.fourhoursCI = fourHoursCI;
        return this;
    }
    setEightHoursCI(eightHoursCI: string){
        this.BIAForm.eightHoursCI = eightHoursCI;
        return this;
    }
    setTwentyFourHoursCI(twentyFourHoursCI: string){
        this.BIAForm.twentyFourHoursCI = twentyFourHoursCI;
        return this;
    }
    setSeventyTwoHoursCI(seventyTwoHoursCI: string){
        this.BIAForm.seventyTwoHoursCI = seventyTwoHoursCI;
        return this;
    }
    setOneWeekCI(oneWeekCI: string){
        this.BIAForm.OneWeekCI = oneWeekCI;
        return this;
    }   
    setTwoWeeksCI(twoWeeksCI: string){
        this.BIAForm.twoWeeksCI = twoWeeksCI;
        return this;
    }
    setOneMonthCI(oneMonthCI: string){
        this.BIAForm.OneMonthCI = oneMonthCI;
        return this;
    }
    setRemarks(remarks: string){
        this.BIAForm.Remarks = remarks;
        return this;
    }

    build(){
        return {
            Department: this.BIAForm.Department || 'SDET',
            PrimarySPOC: this.BIAForm.PrimarySPOC || 'suryaPWD',
            DepartmentCode: this.BIAForm.DepartmentCode || 'RAD',  
            Status: this.BIAForm.Status || 'Active',  
            DocumentName: this.BIAForm.DocumentName || 'Document Name test data',
            DocumentNumber: this.BIAForm.DocumentNumber || '2021-1234',
            DocumentOwner: this.BIAForm.DocumentOwner || 'surya',
            DistributionList: this.BIAForm.DistributionList || 'Distribution List test data',  
            ChangeHistory: this.BIAForm.ChangeHistory || 'Change History test data',
            WorkshopDate: this.BIAForm.WorkshopDate || '12-12-2026',
            WorkshopParticipantsName: this.BIAForm.WorkshopParticipantsName || 'Workshop Participants Name test data',
            WorkshopParticipantsTitle: this.BIAForm.WorkshopParticipantsTitle || 'Workshop Participants Title test data',
            SubDepartmentName: this.BIAForm.SubDepartmentName || 'Sub Department Name test data',
            SupportingServiceName: this.BIAForm.SupportingServiceName || 'Account Opening',
            ActivityName: this.BIAForm.ActivityName || 'Activity Name test data',
            ActivityDescription: this.BIAForm.ActivityDescription || 'Activity Description test data',
            ActivityLocation: this.BIAForm.ActivityLocation || 'Central Mumbai',  
            LocationLatAndLong: this.BIAForm.LocationLatAndLong || '19.0760° N, 72.8777° E',
            ActivityPeakTime: this.BIAForm.ActivityPeakTime || 'Activity Peak Time test data',
            ActivityOwner: this.BIAForm.ActivityOwner || 'Activity Owner test data',
            Criticality: this.BIAForm.Criticality || 'Critical',
            fourhoursFI: this.BIAForm.fourhoursFI || '',
            eightHoursFI: this.BIAForm.eightHoursFI || '',
            twentyFourHoursFI: this.BIAForm.twentyFourHoursFI || '',
            seventyTwoHoursFI: this.BIAForm.seventyTwoHoursFI || '',
            OneWeekFI: this.BIAForm.OneWeekFI || '',
            twoWeeksFI: this.BIAForm.twoWeeksFI || '',
            OneMonthFI: this.BIAForm.OneMonthFI || '',
            fourhoursOI: this.BIAForm.fourhoursOI || '',
            eightHoursOI: this.BIAForm.eightHoursOI || '',
            twentyFourHoursOI: this.BIAForm.twentyFourHoursOI || '',
            seventyTwoHoursOI: this.BIAForm.seventyTwoHoursOI || '',
            OneWeekOI: this.BIAForm.OneWeekOI || '',
            twoWeeksOI: this.BIAForm.twoWeeksOI || '',  
            OneMonthOI: this.BIAForm.OneMonthOI || '',
            fourhoursRI: this.BIAForm.fourhoursRI || '',
            eightHoursRI: this.BIAForm.eightHoursRI || '',
            twentyFourHoursRI: this.BIAForm.twentyFourHoursRI || '',
            seventyTwoHoursRI: this.BIAForm.seventyTwoHoursRI || '',
            OneWeekRI: this.BIAForm.OneWeekRI || '',
            twoWeeksRI: this.BIAForm.twoWeeksRI || '',
            OneMonthRI: this.BIAForm.OneMonthRI || '',
            fourhoursREI: this.BIAForm.fourhoursREI || '',
            eightHoursREI: this.BIAForm.eightHoursREI || '',
            twentyFourHoursREI: this.BIAForm.twentyFourHoursREI || '',
            seventyTwoHoursREI: this.BIAForm.seventyTwoHoursREI || '',
            OneWeekREI: this.BIAForm.OneWeekREI || '',
            twoWeeksREI: this.BIAForm.twoWeeksREI || '',
            OneMonthREI: this.BIAForm.OneMonthREI || '',
            fourhoursCI: this.BIAForm.fourhoursCI || '',
            eightHoursCI: this.BIAForm.eightHoursCI || '',
            twentyFourHoursCI: this.BIAForm.twentyFourHoursCI || '',
            seventyTwoHoursCI: this.BIAForm.seventyTwoHoursCI || '',
            OneWeekCI: this.BIAForm.OneWeekCI || '',
            twoWeeksCI: this.BIAForm.twoWeeksCI || '',
            OneMonthCI: this.BIAForm.OneMonthCI || '',
            Remarks: this.BIAForm.Remarks || ''
        }
    }   

}