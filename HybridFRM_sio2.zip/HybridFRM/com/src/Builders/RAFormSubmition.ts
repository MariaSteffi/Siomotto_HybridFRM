export interface RAFormSubmit{
    //Basic details
    Department: string;
    PrimarySPOC: string;
    Status: string;
    //Risk details
    DocumentName: string;
    DocumentNumber: string;
    DocumentOwner: string;
    DistributionList: string;
    ChangeHistory: string;
    RiskDriver: string;
    RiskEventDescription: string;
    RiskImpact: string;
    RiskCategory: string;
    //Risk Assessment details
    RiskImpactRating: string;
    RiskLikelihoodRating: string;
    ExistingControl: string;
    ControlEffectiveness: string;
    RiskTreatmentStrategy: string;
    RiskResponseStrategy: string;

}

export class RAFormSubmition {
   
    private RAForm:Partial<RAFormSubmit> = {};  

    setDepartment(department: string){
        this.RAForm.Department = department;
        return this;

    }
     setRiskCategory(riskCategory: string) {
         this.RAForm.RiskCategory = riskCategory;
        return this;
    }
    setPrimarySPOC(primarySPOC: string){
        this.RAForm.PrimarySPOC = primarySPOC;
        return this;
    }
    setStatus(status: string){  
    this.RAForm.Status = status;
    return this;
    }

    setDocumentName(documentName: string){
        this.RAForm.DocumentName = documentName;
        return this;
    }   
    setDocumentNumber(documentNumber: string){
        this.RAForm.DocumentNumber = documentNumber;
        return this;
    }       
    setDocumentOwner(documentOwner: string){        
        this.RAForm.DocumentOwner = documentOwner;
        return this;    
    }
    setDistributionList(distributionList: string){
        this.RAForm.DistributionList = distributionList;
        return this;    
    }       
    setChangeHistory(changeHistory: string){
        this.RAForm.ChangeHistory = changeHistory;
        return this;    
    }   
    setRiskDriver(riskDriver: string){
        this.RAForm.RiskDriver = riskDriver;
        return this;    
    }
    setRiskEventDescription(riskEventDescription: string){
        this.RAForm.RiskEventDescription = riskEventDescription;
        return this;    
    }
    setRiskImpact(riskImpact: string){
        this.RAForm.RiskImpact = riskImpact;
        return this;    
    }
    setRiskImpactRating(riskImpactRating: string){
        this.RAForm.RiskImpactRating = riskImpactRating;
        return this;    
    }
    setRiskLikelihoodRating(riskLikelihoodRating: string){
        this.RAForm.RiskLikelihoodRating = riskLikelihoodRating;
        return this;    
    }   
    setExistingControl(existingControl: string){
        this.RAForm.ExistingControl = existingControl;
        return this;    
    }   
    setControlEffectiveness(controlEffectiveness: string){
        this.RAForm.ControlEffectiveness = controlEffectiveness;
        return this;    
    }
    setRiskTreatmentStrategy(riskTreatmentStrategy: string){
        this.RAForm.RiskTreatmentStrategy = riskTreatmentStrategy;     
        return this;
    }
    setRiskResponseStrategy(riskResponseStrategy: string){
        this.RAForm.RiskResponseStrategy = riskResponseStrategy;     
        return this;
    }   

    build(): RAFormSubmit{   
        return {    
            Department: this.RAForm.Department ?? "SDET",
            PrimarySPOC: this.RAForm.PrimarySPOC ?? "surya",
            Status: this.RAForm.Status ?? "Active",
            DocumentName: this.RAForm.DocumentName ?? "Test Document",  
            DocumentNumber: this.RAForm.DocumentNumber ?? "Doc-001",
            DocumentOwner: this.RAForm.DocumentOwner ?? "Derek",
            DistributionList: this.RAForm.DistributionList ?? "Surya,Andy",
            ChangeHistory: this.RAForm.ChangeHistory ?? "Initial Creation",
            RiskDriver: this.RAForm.RiskDriver ?? "Inadequate controls",
            RiskCategory: this.RAForm.RiskCategory ?? "Operational",
            RiskEventDescription: this.RAForm.RiskEventDescription ?? "Description of the risk event",
            RiskImpact: this.RAForm.RiskImpact ?? "Financial Loss",
            RiskImpactRating: this.RAForm.RiskImpactRating ?? "High",
            RiskLikelihoodRating: this.RAForm.RiskLikelihoodRating ?? "Medium",
            ExistingControl: this.RAForm.ExistingControl ?? "Control description",
            ControlEffectiveness: this.RAForm.ControlEffectiveness ?? "Ineffective",
            RiskTreatmentStrategy: this.RAForm.RiskTreatmentStrategy ?? "Mitigate",
            RiskResponseStrategy: this.RAForm.RiskResponseStrategy ?? "Implement additional controls"

        }
    }

}

