export interface StageCreation{
    stageName: string;
    Abort: boolean;
    NeedCorrection: boolean;
    Approve: boolean;
    AssignTo: string;
    ReviewWithIn: number;
    isUnanimous: boolean;
}

export class StageCreationBuilder {
    private Stage:Partial<StageCreation> = {};  

    setStageName(stageName: string){
        this.Stage.stageName = stageName;
        return this;

    }
    setAbort(abort: boolean){
        this.Stage.Abort = abort;
        return this;
    }
    setNeedCorrection(needCorrection: boolean){
        this.Stage.NeedCorrection = needCorrection;
        return this;
    }           
    setApprove(approve: boolean){
        this.Stage.Approve = approve;
        return this;
    }           
    setAssignTo(assignTo: string){
        this.Stage.AssignTo = assignTo;
        return this;
    }   
    setReviewWithIn(reviewWithIn: number){      
        this.Stage.ReviewWithIn = reviewWithIn;
        return this;
    }

    setIsUnanimous(isUnanimous: boolean){
        this.Stage.isUnanimous = isUnanimous;
        return this;
    }   

    build(): StageCreation{
        return {
            stageName: this.Stage.stageName ?? "Stage1",
            Abort: this.Stage.Abort ?? false,
            NeedCorrection: this.Stage.NeedCorrection ?? true,
            Approve: this.Stage.Approve ?? true,
            AssignTo: this.Stage.AssignTo ?? "Surya",
            ReviewWithIn: this.Stage.ReviewWithIn ?? 5,
            isUnanimous: this.Stage.isUnanimous ?? false
        }
    }

    buildCustom(): StageCreation {
    return {
        stageName: this.Stage.stageName ?? "CustomStage",
        Abort: this.Stage.Abort ?? true,
        NeedCorrection: this.Stage.NeedCorrection ?? false,
        Approve: this.Stage.Approve ?? false,
        AssignTo: this.Stage.AssignTo ?? "ReneDes",
        ReviewWithIn: this.Stage.ReviewWithIn ?? 2,
        isUnanimous: this.Stage.isUnanimous ?? false
    }
}


}