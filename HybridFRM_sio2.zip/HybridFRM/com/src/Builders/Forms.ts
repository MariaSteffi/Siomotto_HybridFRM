interface UserData {
  username: string;
  password: string;
  email: string;
  role: string;
}

class UserBuilder {
  private user: Partial<UserData> = {};

  setUsername(username: string) {
    this.user.username = username;
    return this; // important
  }

  setPassword(password: string) {
    this.user.password = password;
    return this;
  }

  setEmail(email: string) {
    this.user.email = email;
    return this;
  }

  setRole(role: string) {
    this.user.role = role;
    return this;
  }

  build(): UserData {
    return {
      username: this.user.username ?? "defaultUser",
      password: this.user.password ?? "1234",
      email: this.user.email ?? "default@gmail.com",
      role: this.user.role ?? "user"
    };
  }
}

//use in Tests cases
// const user = new UserBuilder()
//   .setUsername("surya")
//   .setRole("admin")
//   .build();

// await userPage.createUser(user);



