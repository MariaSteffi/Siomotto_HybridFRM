import * as dotenv from 'dotenv';
import * as path from 'path';

export  function loadEnvironment(envFile: string = '.env') {
    const fullPath = path.resolve(process.cwd(), "./com/src/Resources/"+envFile);
    dotenv.config({ path: fullPath });
    console.log(`Environment loaded from: ${fullPath}`);
}

export default async function global() {
    loadEnvironment('localConfig.env');
    loadEnvironment('EmailConfig.env');
}