import { test, expect } from "@playwright/test";
import { LoginPage } from "../../src/ui/pages/LoginPage";
import { HrmPimPage } from "../../src/ui/pages/HrmPimPage";

test("HRM Login and Add Employee", async ({ page }) => {
  const loginPage = new LoginPage(page);
  const pimPage = new HrmPimPage(page);

  await loginPage.loginAsAdmin();

  await expect(page).toHaveURL(/dashboard/);

  await pimPage.openMenu();
  await pimPage.openAddEmployee();
  await pimPage.addEmployee("Steffi", "Joseph");

  await pimPage.verifySuccessToast("Successfully Saved");
});