import { test } from "@playwright/test";
import SiomottoHomePage from "../../src/ui/pages/SiomottoHomePage";
import SiomottoHouseRentPage from "../../src/ui/pages/SiomottoHouseRentPage";
import SiomottoLoginPage from "../../src/ui/pages/SiomottoLoginPage";
import data from "../../src/Resources/SiomottoTestData.json";

const d = data.houseRent;
test.setTimeout(240000);

test.describe("House Rent - without login", () => {
  // common steps 1-3: location, House Rent, location inside House Rent
  test.beforeEach(async ({ page }) => {
    const home = new SiomottoHomePage(page);
    await home.open();
    await home.selectLocation(data.city, data.cityResult);
    await home.openCategory(d.category);
    await new SiomottoHouseRentPage(page).searchLocation(d.location, d.suggestion);
  });

  test("HR_001 Common steps work: location, House Rent, search location", async ({ page }) => {
    const house = new SiomottoHouseRentPage(page);
    await house.verifyPageLoaded();
    await house.verifyLocationSelected(d.location);
  });

  test("HR_002 Min and Max price with Apply shows results", async ({ page }) => {
    const house = new SiomottoHouseRentPage(page);
    await house.applyPrice(d.min, d.max);
    await house.verifyPriceValues(d.min, d.max);
    await house.verifyResultsShown();
  });

  test("HR_003 Min price greater than Max price gives no results", async ({ page }) => {
    const house = new SiomottoHouseRentPage(page);
    await house.applyPrice(d.badMin, d.badMax);
    await house.verifyNoResults();
  });

  test("HR_004 View Owner Contact asks for login", async ({ page }) => {
    const house = new SiomottoHouseRentPage(page);
    await house.applyPrice(d.min, d.max);
    await house.clickViewContact();
    await house.verifyLoginRequired();
  });
});

test("HR_005 View Owner Contact shows details after login", async ({ page }) => {
  const home = new SiomottoHomePage(page);
  await home.open();
  await new SiomottoLoginPage(page).loginAsUser(); // login comes first on the home page
  await home.selectLocation(data.city, data.cityResult);
  await home.openCategory(d.category);
  const house = new SiomottoHouseRentPage(page);
  await house.searchLocation(d.location, d.suggestion);
  await house.applyPrice(d.min, d.max);
  await house.clickViewContact();
  await house.verifyContactDetailsShown();
});