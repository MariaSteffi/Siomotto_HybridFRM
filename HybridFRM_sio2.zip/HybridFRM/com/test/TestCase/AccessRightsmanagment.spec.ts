import { fa } from "@faker-js/faker";
import { test } from "../../src/Base/CustomeFixture";
import { ExcelUtility } from "../../src/utils/ExcelUtils";
import AccessRightsManagementPage from "../../src/ui/pages/AccessRightsmanagment";
import { expect } from "@playwright/test";
import * as allure from "allure-js-commons";
import { Cards } from "../../src/constants/enum";
import { StaticFields } from "../../src/constants/StaticFields";
import { Locators } from "../../src/ui/Locators";
import { UserData } from "../../src/ui/TestData/UserData";
import { access } from "fs";
import { addAbortListener } from "events";
test.describe("Access Rights Management Module", () => {
   
    test.beforeEach("Login",async ({OpenApp}) => {
            // const factory = OpenApp.getAccessRightsManagementPage();
    });

  test("@Smoke TC_AM_001 Verify user can add New Role for card access", async ({OpenApp,testData}) => {
     await allure.displayName("TC_AM_001 Verify user can add New Role for card access");
     await allure.owner("Surya");
     await allure.tags( "Access Rights Management","Smoke");
     await allure.severity("critical");

    const factory = OpenApp.getAccessRightsManagementPage();
    await factory.loginAsAdmin();
    await factory.NavigateSystemPreferences();
    await factory.NavigateToAccessRights();
    await factory.SelectAccessModule(Cards.BIA);
     await factory.checkForRoleNotExists();
    const isRolePresent = await factory.checkforRole();
    await factory.sleep(4000);
    await factory.AssertTrue(isRolePresent,`Role ${testData.TC_AM_001.RoleName}`);
  });
  test("@Smoke TC_AM_002 Verify whether user who are added in new Role for card access can view the cards", async ({OpenApp,testData}) => {
     await allure.displayName("Verify whether user who are added in new Role for card access can view the cards");
     await allure.owner("Surya");
     await allure.tags( "Access Rights Management");
     await allure.severity("critical");

    const factory = OpenApp.getAccessRightsManagementPage();
    await factory.loginAsAdmin();
    await factory.NavigateSystemPreferences();
    await factory.NavigateToAccessRights();
    await factory.SelectAccessModule(Cards.BIA);
    await factory.checkForRoleNotExists();
    const isRolePresent = await factory.checkforRole();
    await factory.Log.logout();
    await factory.loginAsPoweruser('ReneDes');
    await factory.clickApplication();
    await factory.isModuleDisplayed(StaticFields.BIAmaster);
    await factory.Log.logout();
  });



  test("@Smoke TC_AM_003 Verify user can delete the Role", async ({OpenApp,testData}) => {
     await allure.displayName("Verify user can delete the Role");
     await allure.owner("Surya");
     await allure.tags( "Access Rights Management", "Smoke");
     await allure.severity("critical");

    const factory = OpenApp.getAccessRightsManagementPage();
    await factory.loginAsAdmin();
    await factory.NavigateSystemPreferences();
    await factory.NavigateToAccessRights();
    await factory.SelectAccessModule(Cards.BIA);
    await factory.checkForRoleExists();
    await factory.sleep(4000);
     const isRolePresent = await factory.checkforRole();
    
    await factory.AssertFalse(isRolePresent,`Role ${testData.TC_AM_001.RoleName}`);
    await factory.Log.logout();
   
  });
test("@Smoke TC_AM_004 Verify user can add new Stage for card", async ({OpenApp,testData}) => {
     await allure.displayName("Verify user can add new Stage for card");
     await allure.owner("Surya");
     await allure.tags( "Access Rights Management");
     await allure.severity("critical");

    const factory = OpenApp.getAccessRightsManagementPage();
    await factory.loginAsAdmin();
    await factory.NavigateSystemPreferences();
    await factory.NavigateToAccessRights();
    await factory.SelectAccessModule(Cards.EntityHierarchy);
     await factory.clickAddNewStage();
     await factory.noOFStage(testData.TC_AM_004.NoOFStage);
    // await factory.pause();
     await factory.AccordionExpending(2,async()=>{
     await factory.StageCreationWithOnlyStageName();
     });

     await factory.sleep(4000);
    // await factory.pause();
     await factory.SaveButton();
     
    // await factory.clickApplication();
    // await factory.BIACard();
    // await factory.clickOnBIAFirstRecord();
  });

  test("@Smoke TC_AM_005 Verify Whether the Modules are Displayed in Access Right Management", async({OpenApp,testData}) => {
    await allure.displayName('Verify Whether the Modules are Displayed in Access Right Management');
    await allure.owner('Shri Ram');
    await allure.tags('Access Rights Management', 'Smoke');
    await allure.severity('Critical');

    const factory = OpenApp.getAccessRightsManagementPage();
    await factory.loginAsAdmin();
    await factory.NavigateSystemPreferences();
    await factory.NavigateToAccessRights();

    await factory.AssertModules();

  });

  test("@Smoke TC_AM_006 Verify whether the stages created by the user are displayed when the user clicks on 'Add New Stages'.", async({OpenApp, testData}) => {
    await allure.displayName("Verify whether the stages created by the user are displayed when the user clicks on 'Add New Stages'");
    await allure.owner('Shri Ram');
    await allure.tags('Access Rights Management', 'Smoke');
    await allure.severity('Critical');

    const factory = OpenApp.getAccessRightsManagementPage();
    await factory.loginAsAdmin();
    await factory.NavigateSystemPreferences();
    await factory.NavigateToAccessRights();

    await factory.SelectAccessModule(Cards.RolesUsers);
    await factory.clickAddNewStage();
   
    await factory.AssertStageDetails(testData.TC_AM_006.stageName,testData.TC_AM_006.reviewdays,testData.TC_AM_006.assignedUser);

  });

  test("@Smoke TC_AM_007 Verify whether the user can edit the stages", async({OpenApp,testData}) => {
    await allure.displayName("Verify whether the user can edit the stages");
    await allure.owner('Shri Ram');
    await allure.tags('Access Rights Management', 'Smoke');
    await allure.severity('Critical');

    const factory = OpenApp.getAccessRightsManagementPage();
    await factory.loginAsAdmin();
    await factory.NavigateSystemPreferences();
    await factory.NavigateToAccessRights();

    await factory.SelectAccessModule(Cards.RolesUsers);
    await factory.sleep(4000)
    await factory.clickAddNewStage();
    await factory.sleep(4000);
    await factory.noOFStage(testData.TC_AM_004.NoOFStage);
    await factory.ClickAssignPlusIcon();
    await factory.EditStageDetails(testData.TC_AM_007.stageName,testData.TC_AM_007.reviewdays,testData.TC_AM_007.assignedUser);
    await factory.SaveButton();
    await factory.sleep(4000);
    await factory.AssertStageDetails(testData.TC_AM_007.stageName2,testData.TC_AM_007.reviewdays,testData.TC_AM_007.assignedUser);
  });

  test("@Smoke TC_AM_008 Verify whether user can delete the Stages", async({OpenApp, testData}) => {
    await allure.displayName("Verify whether user can delete the Stages");
    await allure.owner('Shri Ram');
    await allure.tags('Access Rights Management','Smoke');
    await allure.severity('Critical');

    const factory = OpenApp.getAccessRightsManagementPage();
    await factory.loginAsAdmin();
    await factory.NavigateSystemPreferences();
    await factory.NavigateToAccessRights();

    await factory.SelectAccessModule(Cards.EntityHierarchy);
    await factory.sleep(4000)
    await factory.clickAddNewStage();
     await factory.noOFStage(testData.TC_AM_008.NoOFStage);
    await factory.DeleteStage();
    await factory.SaveButton();
  });

  test("@Non-Smoke TC_AM_009 Verify whether the user can enter the numeric value in the Number of Approval Stages field.", async({OpenApp,testData}) => {
    await allure.displayName('Verify whether the user can enter the numeric value in the Number of Approval Stages field.');
    await allure.owner('Shri Ram');
    await allure.tags('Access Rights Management');
    await allure.severity('High');

    const factory = OpenApp.getAccessRightsManagementPage();
    await factory.loginAsAdmin();
    await factory.NavigateSystemPreferences();
    await factory.NavigateToAccessRights();

    await factory.SelectAccessModule(Cards.EntityHierarchy);
    await factory.sleep(4000)
    await factory.clickAddNewStage();

    await factory.noOFStage(testData.TC_AM_004.NoOFStage);
    await factory.sleep(4000);

    await factory.AssertNoOfStage(testData.TC_AM_004.NoOFStage)

  });

  test('@Non-Smoke TC_AM_010 Verify whether the user can input numeric values in the "Review within Days" field.', async({OpenApp,testData}) => {
    await allure.displayName('Verify whether the user can input numeric values in the "Review within Days" field');
    await allure.owner('Shri Ram');
    await allure.tags('Roles And Users');
    await allure.severity('High');

    const factory = OpenApp.getAccessRightsManagementPage();
    await factory.loginAsAdmin();
    await factory.NavigateSystemPreferences();
    await factory.NavigateToAccessRights();

    await factory.SelectAccessModule(Cards.EntityHierarchy);
    await factory.sleep(4000)
    await factory.clickAddNewStage();

    await factory.noOFStage(testData.TC_AM_010.NoOfStages);
    await factory.sleep(4000);
    await factory.NoOfReviewDays(testData.TC_AM_010.ReviewWithin);
    await factory.AssertReviewDays(testData.TC_AM_010.ReviewWithin);
  });

  test('@Non-Smoke TC_AM_011  Verify whether user can Enter Stage Name in stage field ', async({OpenApp,testData}) => {
    await allure.displayName('Verify whether user can Enter Stage Name in stage field');
    await allure.owner('Shri Ram');
    await allure.tags('Access Rights Management');
    await allure.severity('High');

    const factory = OpenApp.getAccessRightsManagementPage();
    await factory.loginAsAdmin();
    await factory.NavigateSystemPreferences();
    await factory.NavigateToAccessRights();

    await factory.SelectAccessModule(Cards.EntityHierarchy);
    await factory.sleep(4000)
    await factory.clickAddNewStage();

    await factory.noOFStage(testData.TC_AM_010.NoOfStages);
    await factory.sleep(4000);

    await factory.EnterStageName(testData.TC_AM_007.stageName);

  });

 test("@Non-Smoke TC_AM_012 Verify whether user can check the No Approval Stages is required ", async({OpenApp,testData}) => {
    await allure.displayName('Verify whether user can check the No Approval Stages is required');
    await allure.owner('Shri Ram');
    await allure.tags('Access Rights Management');
    await allure.severity('High');

    
    const factory = OpenApp.getAccessRightsManagementPage();
    await factory.loginAsAdmin();
    await factory.NavigateSystemPreferences();
    await factory.NavigateToAccessRights();

    await factory.SelectAccessModule(Cards.EntityHierarchy);
    await factory.sleep(4000)
    await factory.clickAddNewStage();
    await factory.VerifyChekBoxState();

  });

  test("@Non-Smoke TC_AM_013 Verify whether the user can't create a stage when the stage name is missing", async({OpenApp,testData}) => {
    await allure.displayName("Verify whether the user can't create a stage when the stage name is missing");
    await allure.owner('Shri Ram');
    await allure.tags('Access Rights Management');
    await allure.severity('Medium');

    const factory = OpenApp.getAccessRightsManagementPage();
    await factory.loginAsAdmin();
    await factory.NavigateSystemPreferences();
    await factory.NavigateToAccessRights();

    await factory.SelectAccessModule(Cards.EntityHierarchy);
    await factory.clickAddNewStage();
    await factory.noOFStage(testData.TC_AM_010.NoOfStages);
    await factory.sleep(4000);

   
    await factory.SaveButton();
    await factory.NegativeValidation();
  });

  test("@Non-Smoke TC_AM_014 Verify whether user can't save when Assigned Users are not filled", async({OpenApp,testData}) => {
    await allure.displayName("Verify whether user can't save when Assigned Users are not filled");
    await allure.owner('Shri Ram');
    await allure.tags('Access Rights Management');
    await allure.severity('Medium');

    const factory = OpenApp.getAccessRightsManagementPage();
    await factory.loginAsAdmin();
    await factory.NavigateSystemPreferences();
    await factory.NavigateToAccessRights();
    await factory.SelectAccessModule(Cards.EntityHierarchy);
    await factory.clickAddNewStage();
    await factory.noOFStage(testData.TC_AM_010.NoOfStages);
    await factory.EnterStageName(testData.TC_AM_007.stageName);
    await factory.sleep(4000);
    await factory.SaveButton();
    await factory.NegativeValidation();
  });

  test("@Non-Smoke TC_AM_015 Verify whether the user can enter alphanumeric characters along with special characters in the Stage Name field", async({OpenApp,testData}) => {
    await allure.displayName("Verify whether the user can enter alphanumeric characters along with special characters in the Stage Name field");
    await allure.owner('Shri Ram');
    await allure.tags('Access Rights Management');
    await allure.severity('High');

    const factory = OpenApp.getAccessRightsManagementPage();
    await factory.loginAsAdmin();
    await factory.NavigateSystemPreferences();
    await factory.NavigateToAccessRights();

    await factory.SelectAccessModule(Cards.EntityHierarchy);
  
    await factory.clickAddNewStage();
    await factory.noOFStage(testData.TC_AM_010.NoOfStages);
    await factory.VerifyAlphanumericWithSpecialChars(testData.TC_AM_015.StageName);
  });

  test("@Non-Smoke TC_AM-016 Verify whether the Approve action is selected by default and is disabled from being unchecked.", async({OpenApp,testData}) => {
    await allure.displayName("Verify whether the Approve action is selected by default and is disabled from being unchecked.");
    await allure.owner('Shri Ram');
    await allure.tags('Access Rights Management');
    await allure.severity('Medium');

    const factory = OpenApp.getAccessRightsManagementPage();
    await factory.loginAsAdmin();
    await factory.NavigateSystemPreferences();
    await factory.NavigateToAccessRights();

    await factory.SelectAccessModule(Cards.EntityHierarchy);
  
    await factory.clickAddNewStage();
    await factory.noOFStage(testData.TC_AM_010.NoOfStages);

    await factory.VerifyApproveActionDefaultAndDisabled();
  });
  
  test("@Non-Smoke TC_AM_017 Verify whether User can check the Abort", async({OpenApp, testData}) => {
    await allure.displayName("Verify whether User can check the Abort");
    await allure.owner('Shri Ram');
    await allure.tags('Access Rights Management');
    await allure.severity('High');

    const factory = OpenApp.getAccessRightsManagementPage();
    await factory.loginAsAdmin();
    await factory.NavigateSystemPreferences();
    await factory.NavigateToAccessRights();

    await factory.SelectAccessModule(Cards.EntityHierarchy);
  
    await factory.clickAddNewStage();
    await factory.noOFStage(testData.TC_AM_010.NoOfStages);
    await factory.VerifyAbortChekBoxState();
    //pending
  });

  test("@Non-Smoke TC_AM_018 Verify whether User can Uncheck the Abort", async({OpenApp, testData}) => {
    await allure.displayName("Verify whether User can Uncheck the Abort");
    await allure.owner('Shri Ram');
    await allure.tags('Access Rights Management');
    await allure.severity('High');

    const factory = OpenApp.getAccessRightsManagementPage();
    await factory.loginAsAdmin();
    await factory.NavigateSystemPreferences();
    await factory.NavigateToAccessRights();

    await factory.SelectAccessModule(Cards.EntityHierarchy);
  
    await factory.clickAddNewStage();
    await factory.noOFStage(testData.TC_AM_010.NoOfStages);
    await factory.VerifyAbortChekBoxState();
    await factory.VerifyUncheckAbortCheckBoxState();
    
  });

  test("@Non-Smoke TC_AM_019 Verify whether User can check the Needs Correction", async({OpenApp, testData}) => {
    await allure.displayName("Verify whether User can check the Needs Correction");
    await allure.owner('Shri Ram');
    await allure.tags('Access Rights Management');
    await allure.severity('High');

    const factory = OpenApp.getAccessRightsManagementPage();
    await factory.loginAsAdmin();
    await factory.NavigateSystemPreferences();
    await factory.NavigateToAccessRights();

    await factory.SelectAccessModule(Cards.EntityHierarchy);
  
    await factory.clickAddNewStage();
    await factory.noOFStage(testData.TC_AM_010.NoOfStages);
    await factory.VerifyNeddCorrectionChekBoxState();
    
  });


  test("@Non-Smoke TC_AM_020 Verify whether User can Uncheck the Needs Correction", async({OpenApp, testData}) => {
    await allure.displayName("Verify whether User can Uncheck the Needs Correction");
    await allure.owner('Shri Ram');
    await allure.tags('Access Rights Management');
    await allure.severity('High');

    const factory = OpenApp.getAccessRightsManagementPage();
    await factory.loginAsAdmin();
    await factory.NavigateSystemPreferences();
    await factory.NavigateToAccessRights();

    await factory.SelectAccessModule(Cards.EntityHierarchy);
  
    await factory.clickAddNewStage();
    await factory.noOFStage(testData.TC_AM_010.NoOfStages);
    await factory.VerifyNeddCorrectionChekBoxState();
    await factory.VerifyNeddCorrectionUnChekBoxState();
    
  });

  test("@Non-Smoke TC_AM_021 Verify whether User can check the Unanimous approval is mandatory", async({OpenApp, testData}) => {
    await allure.displayName("Verify whether User can check the Unanimous approval is mandatory");
    await allure.owner('Shri Ram');
    await allure.tags('Access Rights Management');
    await allure.severity('High');

    const factory = OpenApp.getAccessRightsManagementPage();
    await factory.loginAsAdmin();
    await factory.NavigateSystemPreferences();
    await factory.NavigateToAccessRights();

    await factory.SelectAccessModule(Cards.EntityHierarchy);
  
    await factory.clickAddNewStage();
    await factory.noOFStage(testData.TC_AM_010.NoOfStages);
    await factory.VerifyUnanimousapprovalChekBoxState();
    
  });

  test("@Non-Smoke TC_AM_022 Verify whether User can Uncheck the Unanimous approval is mandatory", async({OpenApp, testData}) => {
    await allure.displayName("Verify whether User can Uncheck the Unanimous approval is mandatory");
    await allure.owner('Shri Ram');
    await allure.tags('Access Rights Management');
    await allure.severity('High');

    const factory = OpenApp.getAccessRightsManagementPage();
    await factory.loginAsAdmin();
    await factory.NavigateSystemPreferences();
    await factory.NavigateToAccessRights();

    await factory.SelectAccessModule(Cards.EntityHierarchy);
  
    await factory.clickAddNewStage();
    await factory.noOFStage(testData.TC_AM_010.NoOfStages);
    await factory.VerifyUnanimousapprovalChekBoxState();
    await factory.VerifyUnanimousapprovalUnChekBoxState();
    //pending
  });

  test("@Non-Smoke TC_AM_023 Verify whether the user can add/increase the review days using the up arrow control.", async({OpenApp, testData}) => {
    await allure.displayName("Verify whether the user can add/increase the review days using the up arrow control.");
    await allure.owner('Shri Ram');
    await allure.tags('Access Rights Management');
    await allure.severity('High');

    const factory = OpenApp.getAccessRightsManagementPage();
    await factory.loginAsAdmin();
    await factory.NavigateSystemPreferences();
    await factory.NavigateToAccessRights();

    await factory.SelectAccessModule(Cards.EntityHierarchy);
  
    await factory.clickAddNewStage();
    await factory.noOFStage(testData.TC_AM_010.NoOfStages);
    await factory.VerifyIncreasedNumber();
  });

  test("@Non-Smoke TC_AM_023 Verify whether the user can decrease the review days using the down arrow control.", async({OpenApp,testData}) => {
    await allure.displayName("Verify whether the user can decrease the review days using the down arrow control.");
    await allure.owner('Shri Ram');
    await allure.tags('Roles And Users');
    await allure.severity('High');

    const factory = OpenApp.getAccessRightsManagementPage();
    await factory.loginAsAdmin();
    await factory.NavigateSystemPreferences();
    await factory.NavigateToAccessRights();

    await factory.SelectAccessModule(Cards.EntityHierarchy);
  
    await factory.clickAddNewStage();
    await factory.noOFStage(testData.TC_AM_010.NoOfStages);
    await factory.VerifyIncreasedNumber();
    await factory.VerifyDecreasedNumber();
  });

  test("@Non-Smoke TC_AM_024 Verify whether invalid review days reset to zero when the user clicks anywhere on the screen.", async({OpenApp,testData}) => {
    await allure.displayName("Verify whether invalid review days reset to zero when the user clicks anywhere on the screen.");
    await allure.owner('Shri Ram');
    await allure.tags('Access Rights Management');
    await allure.severity('High');

    const factory = OpenApp.getAccessRightsManagementPage();
    await factory.loginAsAdmin();
    await factory.NavigateSystemPreferences();
    await factory.NavigateToAccessRights();

    await factory.SelectAccessModule(Cards.EntityHierarchy);
  
    await factory.clickAddNewStage();
    await factory.noOFStage(testData.TC_AM_010.NoOfStages);
    await factory.NoOfReviewDays(testData.TC_AM_020.NegValue);
    await factory.ClickAnyPartOfScreen();
    await factory.AssertReviewDays(testData.TC_AM_020.Zero)
  });

  test("@Non-Smoke TC_AM_025 Verify whether the user can click the 'Please select' field and view the list of available users/roles", async({OpenApp,testData}) => {
    await allure.displayName("Verify whether the user can click the 'Please select' field and view the list of available users/roles");
    await allure.owner('Shri Ram');
    await allure.tags('Access Rights Management');
    await allure.severity('High');

    const factory = OpenApp.getAccessRightsManagementPage();
    await factory.loginAsAdmin();
    await factory.NavigateSystemPreferences();
    await factory.NavigateToAccessRights();

    await factory.SelectAccessModule(Cards.EntityHierarchy);
  
    await factory.clickAddNewStage();
    await factory.noOFStage(testData.TC_AM_010.NoOfStages);
    await factory.ClickAssignPlusIcon();
    await factory.ClickPleaseSelect(testData.TC_AM_007.assignedUser);
    await factory.VerifyPleaseSelectDropdownList1(testData.TC_AM_007.assignedUser,testData.TC_AM_007.User);
    //Error fixes
  });

  test("@Non-Smoke TC_AM_026 Verify whether the selected user is displayed correctly in the Assigned User/Role field after selection.", async({OpenApp,testData}) => {
    await allure.displayName("Verify whether the selected user is displayed correctly in the Assigned User/Role field after selection.");
    await allure.owner('Shri Ram');
    await allure.tags('Access Rights Management');

     const factory = OpenApp.getAccessRightsManagementPage();
    await factory.loginAsAdmin();
    await factory.NavigateSystemPreferences();
    await factory.NavigateToAccessRights();

    await factory.SelectAccessModule(Cards.EntityHierarchy);
  
    await factory.clickAddNewStage();
    await factory.noOFStage(testData.TC_AM_010.NoOfStages);
    await factory.ClickAssignPlusIcon();
    await factory.sleep(4000);
    await factory.EnterValueInDropDown(testData.TC_AM_007.assignedUser,testData.TC_AM_007.inputValue);
    await factory.AssertValueInDropDown(testData.TC_AM_007.assignedUser);
  });

  test("@Non-Smoke TC_AM_027 Verify whether user can't delete stages when Is This Stage Mandatory check box is checked", async({OpenApp,testData}) => {
    await allure.displayName("Verify whether user can't delete stages when Is This Stage Mandatory check box is checked");
    await allure.owner('Shri Ram');
    await allure.tags('Access Rights Management');

    const factory = OpenApp.getAccessRightsManagementPage();
    await factory.loginAsAdmin();
    await factory.NavigateSystemPreferences();
    await factory.NavigateToAccessRights();

    await factory.SelectAccessModule(Cards.RolesUsers);
  
    await factory.clickAddNewStage();
   // await factory.noOFStage(testData.TC_AM_010.NoOfStages);
    await factory.CheckIsThisStageMandatory();
    await factory.AssertNonVisiblityOfDeleteButton()
  });

  test("@Non-Smoke TC_AM_028 Verify whether the user can save when the Number of Approval Stages is set to 0 and the No Approval Stages Required option is selected.", async({OpenApp,testData}) => {
    await allure.displayName('Verify whether the user can save when the Number of Approval Stages is set to 0 and the "No Approval Stages Required" option is selected.');
    await allure.owner('Shri Ram');
    await allure.tags('Access Rights Management');
    await allure.severity('low');

    const factory = OpenApp.getAccessRightsManagementPage();
    await factory.loginAsAdmin();
    await factory.NavigateSystemPreferences();
    await factory.NavigateToAccessRights();

    await factory.SelectAccessModule(Cards.EntityHierarchy);
    await factory.clickAddNewStage();
   
   // await factory.CheckNoApprovalStagesChecked();
  })



  test("@Non-Smoke TC_AM_029  Verify whether user can increase No of Approval stages by using Up Arrow", async({OpenApp,testData}) => {
    await allure.displayName('Verify whether user can increase No of Approval stages by using Up Arrow');
    await allure.owner('Shri Ram');
    await allure.tags('Access Rights Management');
    await allure.severity('High');

    const factory = OpenApp.getAccessRightsManagementPage();
    await factory.loginAsAdmin();
    await factory.NavigateSystemPreferences();
    await factory.NavigateToAccessRights();

    await factory.SelectAccessModule(Cards.EntityHierarchy);
  
    await factory.clickAddNewStage();
    await factory.VerifyUserIncreaseSyageNumber()
  });

  test("@Non-Smoke TC_AM_030  Verify whether user can decrease No of Approval stages by using Up Arrow", async({OpenApp,testData}) => {
    await allure.displayName('Verify whether user can decrease No of Approval stages by using Up Arrow');
    await allure.owner('Shri Ram');
    await allure.tags('Access Rights Management');
    await allure.severity('High');

    const factory = OpenApp.getAccessRightsManagementPage();
    await factory.loginAsAdmin();
    await factory.NavigateSystemPreferences();
    await factory.NavigateToAccessRights();

    await factory.SelectAccessModule(Cards.EntityHierarchy);
  
    await factory.clickAddNewStage();
    await factory.VerifyStageNumber();
  });

  test("@Smoke TC_AM_031 Verify whether the following field are displayed when Number of Approval Stages set to 1", async({OpenApp,testData}) => {
    await allure.displayName('Verify whether the following field are displayed when Number of Approval Stages set to 1');
    await allure.owner('Shri Ram');
    await allure.tags('Access Rights Management','Smoke');
    await allure.severity('Critical');

    const factory = OpenApp.getAccessRightsManagementPage();
    await factory.loginAsAdmin();
    await factory.NavigateSystemPreferences();
    await factory.NavigateToAccessRights();

    await factory.SelectAccessModule(Cards.EntityHierarchy);
  
    await factory.clickAddNewStage();
    await factory.noOFStage(testData.TC_AM_010.NoOfStages);

    await factory.VerifyStageFeaturesDisplayed()
  });

  test("@Smoke TC_AM_032 Verify whether following fields are displayed when user selects Add New Stages", async({OpenApp,testData}) => {
    await allure.displayName('Verify whether following fields are displayed when user selects Add New Stages');
    await allure.owner('Shri Ram');
    await allure.tags('Access Rights Management','Smoke');
    await allure.severity('critical');

    const factory = OpenApp.getAccessRightsManagementPage();
    await factory.loginAsAdmin();
    await factory.NavigateSystemPreferences();
    await factory.NavigateToAccessRights();

    await factory.SelectAccessModule(Cards.EntityHierarchy);
  
    await factory.clickAddNewStage();
    await factory.VerifyAddNewStageFieldsDisplayed()
  });

  test("@Non-Smoke TC_AM_033 Verify whether user can remove the assigned Users/Roles by clicking the cross icon on the user name.", async({OpenApp,testData}) => {
    await allure.displayName('Verify whether user can remove the assigned Users/Roles by clicking the cross icon on the user name.');
    await allure.owner('Shri Ram');
    await allure.tags('Access Rights Management');
    await allure.severity('High');

    const factory = OpenApp.getAccessRightsManagementPage();
    await factory.loginAsAdmin();
    await factory.NavigateSystemPreferences();
    await factory.NavigateToAccessRights();

    await factory.SelectAccessModule(Cards.EntityHierarchy);
  
    await factory.clickAddNewStage();
    await factory.noOFStage(testData.TC_AM_010.NoOfStages);
    await factory.ClickAssignPlusIcon();
    //await factory.ClickPleaseSelect(testData.TC_AM_007.assignedUser);
    //await factory.VerifyPleaseSelectDropdownList1(testData.TC_AM_007.assignedUser,'User');
    await factory.EnterValueInDropDown(testData.TC_AM_007.assignedUser,testData.TC_AM_007.inputValue);
    await factory.RemoveUsersOneByOne(testData.TC_AM_029.AssignUser);

  });

  test("@Non-Smoke TC_AM_034 Verify whether user can clear all selected values by clicking the Clear icon.", async({OpenApp,testData}) => {
    await allure.displayName("Verify whether user can remove the assigned Users/Roles by clicking the cross icon on the user name.");
    await allure.owner('Shri Ram');
    await allure.tags('Access Rights Management');
    await allure.severity('High');

     const factory = OpenApp.getAccessRightsManagementPage();
    await factory.loginAsAdmin();
    await factory.NavigateSystemPreferences();
    await factory.NavigateToAccessRights();

    await factory.SelectAccessModule(Cards.EntityHierarchy);
  
    await factory.clickAddNewStage();
    await factory.noOFStage(testData.TC_AM_010.NoOfStages);
    await factory.ClickAssignPlusIcon();
    await factory.EnterValueInDropDown(testData.TC_AM_007.assignedUser,testData.TC_AM_007.inputValue);
    await factory.RemoveAllAssignedUsers(UserData.CircleCrossIcon);
  });

  test("@Smoke TC_AM_035 Verify whether the stages created in Access Rights Management are displayed correctly under Risk Review in the RA card.", async({OpenApp,testData}) => {
    await allure.displayName("Verify whether the stages created in Access Rights Management are displayed correctly under Risk Review in the RA card.");
    await allure.owner('Shri Ram');
    await allure.tags('Access Rights Management');
    await allure.severity('Critical');

    const factory = OpenApp.getAccessRightsManagementPage();
    await factory.loginAsAdmin();

  });

  test("@Non-Smoke TC_AM_036 Verify the following Features are visible Select Role to Add, Save button, Enterprise entity, Business entity,Execution entity " +
        " Sort Feature-Modified Date, Search bar, .Entity Module", async({OpenApp,testData}) => {
      await allure.displayName("Verify the following Features are visible Select Role to Add, Save button, Enterprise entity, Business entity,Execution entity " +
        " Sort Feature-Modified Date, Search bar, .Entity Module");
      await allure.owner('Shri Ram');
      await allure.tags('Access Rights Management');
      await allure.severity('critical');

    const factory = OpenApp.getAccessRightsManagementPage();
    await factory.loginAsAdmin();
    await factory.NavigateSystemPreferences();
    await factory.NavigateToAccessRights();

    await factory.SelectAccessModule(Cards.EntityHierarchy);
    await factory.clickAddNewRole();
    await factory.IsAddRoleFeaturesVisible();

      });

    test("@Non-Smoke TC_AM_037 Verify whether the following are displayed in sort button dropdown "+
            " Modified Date " + 
            "Alphabetically", async({OpenApp,testData}) => {
      await allure.displayName("Verify whether the following are displayed in sort button dropdown "+
            " Modified Date " + 
            "Alphabetically");
      await allure.owner('Shri Ram');
      await allure.tags('Access Rights Management');
      await allure.severity('Medium');

      const factory = OpenApp.getAccessRightsManagementPage();
      await factory.loginAsAdmin();
      await factory.NavigateSystemPreferences();
      await factory.NavigateToAccessRights();

      await factory.SelectAccessModule(Cards.EntityHierarchy);
      await factory.clickAddNewRole();
      
        await factory.clickSortButton();

        await factory.checkModifiedDateSortButton();
        await factory.checkAlphabeticallySortButton();
    });

    test("@Non-Smoke TC_AM_038 Verify whether records are sorted in ascending alphabetical order, with names arranged from A to Z, using the up arrow", async({OpenApp,testData}) => {
      await allure.displayName("Verify whether records are sorted in ascending alphabetical order, with names arranged from A to Z, using the up arrow");
      await allure.owner('Shri Ram');
      await allure.tags('Access Rights Management');
      await allure.severity('Medium');

      const factory = OpenApp.getAccessRightsManagementPage();
      await factory.loginAsAdmin();
      await factory.NavigateSystemPreferences();
      await factory.NavigateToAccessRights();

      await factory.SelectAccessModule(Cards.EntityHierarchy);
      await factory.clickAddNewRole();

      await factory.clickSortButton();
      await factory.clickAplhaSortButton();
      await factory.VerifySortingAscending(testData.TC_RAU_08.EntityName);
    });

    test("@Non-Smoke TC_AM_039 Verify whether records are sorted in descending alphabetical order, with names arranged from Z to A, using the down arrow", async({OpenApp,testData}) => {
      await allure.displayName("Verify whether records are sorted in descending alphabetical order, with names arranged from Z to A, using the down arrow");
      await allure.owner('Shri Ram');
      await allure.tags('Access Rights Management');
      await allure.severity('Medium');

      const factory = OpenApp.getAccessRightsManagementPage();
      await factory.loginAsAdmin();
      await factory.NavigateSystemPreferences();
      await factory.NavigateToAccessRights();

      await factory.SelectAccessModule(Cards.EntityHierarchy);
      await factory.clickAddNewRole();

      await factory.clickSortButton();
      await factory.clickAplhaSortButton();
      await factory.VerifySortingDescending(testData.TC_RAU_08.EntityName);
    });

    test("@Non-Smoke TC_AM_040 Verify whether the Search bar works when a role name is typed in the input field.", async({OpenApp,testData}) => {
      await allure.displayName("Verify whether the Search bar works when a role name is typed in the input field.");
      await allure.owner('Shri Ram');
      await allure.tags('Access Rights Management');
      await allure.severity('Medium');

      const factory = OpenApp.getAccessRightsManagementPage();
      await factory.loginAsAdmin();
      await factory.NavigateSystemPreferences();
      await factory.NavigateToAccessRights();

      await factory.SelectAccessModule(Cards.EntityHierarchy);
      await factory.clickAddNewRole();
      await factory.roleSearch1();
      await factory.sleep(2000);
      await factory.AssertSearchedRoleIsPresent(testData.TC_AM_035.RoleName);
    });

    test("@Non-Smoke TC_AM_041 Verify whether user can't save the role when the role is not selected", async({OpenApp,testData}) => {
      await allure.displayName("Verify whether user can't save the role when the role is not selected");
      await allure.owner('Shri Ram');
      await allure.tags('Access Rights Management');
      await allure.severity('High');

      const factory = OpenApp.getAccessRightsManagementPage();
      await factory.loginAsAdmin();
      await factory.NavigateSystemPreferences();
      await factory.NavigateToAccessRights();

      await factory.SelectAccessModule(Cards.EntityHierarchy);
      await factory.clickAddNewRole();
      await factory.SaveButton();
      await factory.AssertNegativeValidation();
    });

    test("@Smoke TC_AM_042 Verify whether the user can view the newly added role for a particular module under Menu Access", async({OpenApp,testData}) => {
      await allure.displayName("Verify whether the user can view the newly added role for a particular module under Menu Access");
      await allure.owner('Shri Ram');
      await allure.tags('Access Rights Management');
      await allure.severity('Critical');

      const factory = OpenApp.getAccessRightsManagementPage();
      await factory.loginAsAdmin();
      await factory.NavigateSystemPreferences();
      await factory.NavigateToAccessRights();

      await factory.SelectAccessModule(Cards.Templates);
      await factory.clickAddNewRole();
      await factory.roleSearch1();
      await factory.clickRole2();
      await factory.sleep(4000);
      await factory.SaveButton();
      await factory.sleep(4000);
      await factory.VerifyNewlyAddedRoleUnderMenuAccess(testData.TC_AM_043.RoleName,testData.TC_AM_043.RoleName);
    });

    test("@Non-Smoke TC_AM_043 Verify whether a delete confirmation pop-up is displayed when the delete icon is clicked for a role.", async({OpenApp,testData}) => {
      await allure.displayName("Verify whether a delete confirmation pop-up is displayed when the delete icon is clicked for a role.");
      await allure.owner('Shri Ram');
      await allure.tags('Access Rights Management');
      await allure.severity('Medium');

      const factory = OpenApp.getAccessRightsManagementPage();
      await factory.loginAsAdmin();
      await factory.NavigateSystemPreferences();
      await factory.NavigateToAccessRights();

      await factory.SelectAccessModule(Cards.EntityHierarchy);
      await factory.sleep(4000);
      await factory.ClickDeleteButton();
      await factory.VerifyConfirmationPopUp();
    });

    test("@Non-Smoke TC_AM_044 Verify whether user can click on No and Changes are reverted", async({OpenApp,testData}) => {
      await allure.displayName('Verify whether user can click on No and Changes are reverted');
      await allure.owner('Shri Ram');
      await allure.tags('Access Rights Management');
      await allure.severity('High');

      const factory = OpenApp.getAccessRightsManagementPage();
      await factory.loginAsAdmin();
      await factory.NavigateSystemPreferences();
      await factory.NavigateToAccessRights();

      await factory.SelectAccessModule(Cards.EntityHierarchy);
      await factory.sleep(4000);
      await factory.ClickDeleteButton();
      await factory.ClickNoDeletionButton();
    })

    test("@Non-Smoke TC_AM_045 Verify whether the user can select multiple roles for a particular module and save them.", async({OpenApp,testData}) => {
      await allure.displayName("Verify whether the user can select multiple roles for a particular module and save them.");
      await allure.owner('Shri Ram');
      await allure.tags('Access Rights Management');
      await allure.severity('High');

      const factory = OpenApp.getAccessRightsManagementPage();
      await factory.loginAsAdmin();
      await factory.NavigateSystemPreferences();
      await factory.NavigateToAccessRights();

      await factory.SelectAccessModule(Cards.EntityHierarchy);
      await factory.clickAddNewRole();
      await factory.sleep(4000);
      await factory.SelectMultipleRolesFromDifferentEntities(testData.TC_AM_040.Roles);
      await factory.SaveButton();
      await factory.sleep(4000);
      for (let role of testData.TC_AM_040.Roles) {
        await factory.VerifyNewlyAddedRoleUnderMenuAccess1([role.roleName], role.roleName);
      }
     
    });

    test("@non-Smoke TC_AM_046 Verify whether the user can view the entity name of the role when hovering over the amber icon.", async({OpenApp,testData}) => {
      await allure.displayName("Verify whether the user can view the entity name of the role when hovering over the amber icon.");
      await allure.owner('Shri Ram');
      await allure.tags('Access Rights Management');
      await allure.severity('Low');

      const factory = OpenApp.getAccessRightsManagementPage();
      await factory.loginAsAdmin();
      await factory.NavigateSystemPreferences();
      await factory.NavigateToAccessRights();
      await factory.SelectAccessModule(Cards.EntityHierarchy);
      await factory.clickrole();
    //  await factory.HoverAmberIcon(testData.TC_AM_035.RoleName);
      await factory.sleep(4000);
      await factory.HoverValueVerification(testData.TC_AM_035.RoleName,testData.TC_AM_041.EntityName)


    });

    test("@Smoke TC_AM_047 Verify whether the Following features are displayed in the RA card.", async({OpenApp,testData}) => {
      await allure.displayName("Verify whether the Following features are displayed in the RA card.");
      await allure.owner('Shri Ram');
      await allure.tags('Access Rights Management');
      await allure.severity('High');

      const factory = OpenApp.getAccessRightsManagementPage();
      await factory.loginAsPoweruser('ReneDes');
      await factory.ClickOnApplication();
      await factory.ClickRACard();
     // await factory.pause();
     //  await factory.ClickNew();
      // await factory.ClickRecordsInRA();
      // await factory.sleep(4000);
      // await factory.ClickRiskReview();
      await factory.VerifyRAFields();
    });

    test("@Smoke TC_AM_047 Verify whether the user can view the created stages in the RA card.", async({OpenApp,testData}) => {
      await allure.displayName("Verify whether the user can view the created stages in the RA card.");
      await allure.owner('Shri Ram');
      await allure.tags('Access Rights Management');
      await allure.severity('High');

      const factory = OpenApp.getAccessRightsManagementPage();
      await factory.loginAsPoweruser('ReneDes');
      await factory.ClickOnApplication();
      await factory.ClickRACard();
     // await factory.pause();
      // await factory.ClickNew();
       await factory.ClickRecordsInRA();
      await factory.sleep(4000);
      await factory.ClickRiskReview();
      //await factory.VerifyStageDetails();

      await factory.AssertStageDetails(testData.TC_AM_047.stageName,testData.TC_AM_047.reviewdays,testData.TC_AM_047.assignedUser)
    });


     test("@non-Smoke TC_AM_048 Verify whether user can close the Add New Role Pop up", async({OpenApp,testData}) => {
      await allure.displayName("Verify whether user can close the Add New Role Pop up");
      await allure.owner('Shri Ram');
      await allure.tags('Access Rights Management');
      await allure.severity('High');

      const factory = OpenApp.getAccessRightsManagementPage();
      await factory.loginAsAdmin();
      await factory.NavigateSystemPreferences();
      await factory.NavigateToAccessRights();
      await factory.SelectAccessModule(Cards.EntityHierarchy);
      await factory.clickAddNewRole();
      await factory.CloseRole();
    });

    //  test("@Non-Smoke TC_AM_050 Verify whether the Stages are removed under risk review in RA when user deleted stages in Access Rights Management", async({OpenApp,testData}) => {
    //   await allure.displayName("Verify whether the Stages are removed under risk review in RA when user deleted stages in Access Rights Management");
    //   await allure.owner('Shri Ram');
    //   await allure.tags('Access Rights Management');
    //   await allure.severity('High');

    //   const factory = OpenApp.getAccessRightsManagementPage();
    //   await factory.loginAsPoweruser('ReneDes');
    //   await factory.ClickOnApplication();
    //   await factory.ClickRACard();
    //  // await factory.VerifyStageIsRemoved();
    // });

    test("@Non-Smoke TC_AM_051 Verify whether a negative number entered in the 'Number of Approval Stages' field resets to zero when the user clicks anywhere on the screen.", async({OpenApp,testData}) => {
      await allure.displayName("Verify whether a negative number entered in the 'Number of Approval Stages' field resets to zero when the user clicks anywhere on the screen.");
      await allure.owner('Shri Ram');
      await allure.tags('Access Rights Management');
      await allure.severity('Medium');

      const factory = OpenApp.getAccessRightsManagementPage();
      await factory.loginAsAdmin();
      await factory.NavigateSystemPreferences();
      await factory.NavigateToAccessRights();
      await factory.SelectAccessModule(Cards.EntityHierarchy);

      await factory.clickAddNewStage();
      await factory.noOFStage(testData.TC_AM_020.NegValue);
      await factory.ClickAnyPartOfScreen();
      await factory.AssertNoOfApprovalStages(testData.TC_AM_020.Zero)

    });

    test("@Non-Smoke TC_AM_052 Verify whether User can't enter alphabetic characters in the 'Number of Approval Stages' field ", async({OpenApp,testData}) => {
      await allure.displayName("Verify whether User can't enter alphabetic characters in the 'Number of Approval Stages' field");
      await allure.owner('Shri Ram');
      await allure.tags('Access Rights Management');
      await allure.severity('Medium');

      const factory = OpenApp.getAccessRightsManagementPage();
      await factory.loginAsAdmin();
      await factory.NavigateSystemPreferences();
      await factory.NavigateToAccessRights();
      await factory.SelectAccessModule(Cards.EntityHierarchy);
      await factory.clickAddNewStage();
      await factory.noOFStage(testData.TC_AM_052.AlphaValue);
      await factory.SaveButton();
      await factory.AssertNoOfApprovalStages("");
    });

    test("@Non-Smoke TC_AM_053 Verify whether User can't enter special characters in the 'Number of Approval Stages' field", async({OpenApp, testData}) => {
      await allure.displayName("Verify whether User can't enter special characters in the 'Number of Approval Stages' field");
      await allure.owner('Shri Ram');
      await allure.tags('Access Rights Management');
      await allure.severity('Medium');

      const factory = OpenApp.getAccessRightsManagementPage();
      await factory.loginAsAdmin();
      await factory.NavigateSystemPreferences();
      await factory.NavigateToAccessRights();
      await factory.SelectAccessModule(Cards.EntityHierarchy);
      await factory.clickAddNewStage();
      await factory.noOFStage(testData.TC_AM_052.SpecialCharacter);
      await factory.SaveButton();
      await factory.NegativeValidation();
      await factory.AssertNoOfApprovalStages("");
    });

    test("@Non-Smoke TC_AM_054 Verify whether user can't enter Alphabetic characters in the review days field", async({OpenApp,testData}) => {
      await allure.displayName("Verify whether user can't enter Alphabetic characters in the review days field");
      await allure.owner('Shri Ram');
      await allure.tags('Access Rights Management');
      await allure.severity('Medium');

      const factory = OpenApp.getAccessRightsManagementPage();
      await factory.loginAsAdmin();
      await factory.NavigateSystemPreferences();
      await factory.NavigateToAccessRights();

      await factory.SelectAccessModule(Cards.EntityHierarchy);
      await factory.clickAddNewStage();
      await factory.noOFStage(testData.TC_AM_010.NoOfStages);
      await factory.NoOfReviewDays(testData.TC_AM_054.AlphaValue);
      await factory.ClickAnyPartOfScreen();
      await factory.AssertReviewDays(testData.TC_AM_020.Zero)
    });

    test("@Non-Smoke TC_AM_055 Verify whether user can't enter Special characters in the review days field ", async({OpenApp,testData}) => {
      await allure.displayName("Verify whether user can't enter Special characters in the review days field");
      await allure.owner('Shri Ram');
      await allure.tags('Access Rights Management');
      await allure.severity('Medium');

      
      const factory = OpenApp.getAccessRightsManagementPage();
      await factory.loginAsAdmin();
      await factory.NavigateSystemPreferences();
      await factory.NavigateToAccessRights();

      await factory.SelectAccessModule(Cards.EntityHierarchy);
      await factory.clickAddNewStage();
      await factory.noOFStage(testData.TC_AM_010.NoOfStages);
      await factory.sleep(4000)
      await factory.NoOfReviewDays(testData.TC_AM_054.SpecialCharacter);
      await factory.sleep(4000)
      await factory.ClickAnyPartOfScreen();
      await factory.AssertReviewDays('');
    });

    test("@Non-Smoke TC_AM_056 Verify Whether the Count in the Number of Approval stages decrease once user deletes the Stages", async({OpenApp,testData}) => {
      await allure.displayName("Verify Whether the Count in the Number of Approval stages decrease once user deletes the Stages");
      await allure.owner('Shri Ram');
      await allure.tags('Access Rights Management');
      await allure.severity('High');

      const factory = OpenApp.getAccessRightsManagementPage();
      await factory.loginAsAdmin();
      await factory.NavigateSystemPreferences();
      await factory.NavigateToAccessRights();
    //  await factory.pause();
      await factory.SelectAccessModule(Cards.EntityHierarchy);
      await factory.clickAddNewStage();
      await factory.noOFStage(testData.TC_AM_010.NoOfStages);
      await factory.DeleteStage();
    });
    
    test('@Non-Smoke TC_AM_057 Verify whether the user can save when the Number of Approval Stages is set to 0 and the "No Approval Stages Required" option is selected.', async({OpenApp,testData}) => {
      await allure.displayName('Verify whether the user can save when the Number of Approval Stages is set to 0 and the "No Approval Stages Required" option is selected.');
      await allure.owner('Shri Ram');
      await allure.tags('Access Rights Management');
      await allure.severity('High');

      const factory = OpenApp.getAccessRightsManagementPage();
      await factory.loginAsAdmin();
      await factory.NavigateSystemPreferences();
      await factory.NavigateToAccessRights();
    
      await factory.SelectAccessModule(Cards.EntityHierarchy);
      await factory.clickAddNewStage();
    //  await factory.AssertStageDetails(testData.TC_AM_006.stageName,testData.TC_AM_006.reviewdays,testData.TC_AM_006.assignedUser);
      await factory.noOFStage(testData.TC_AM_057.NoOfStages);
      await factory.SaveButton();
    //  await factory.clickAddNewStage();
      await factory.AssertNoOfApprovalStages(testData.TC_AM_057.NoOfStages);
     // await factory.
    });

    test("@Non-Smoke TC_AM_058 Verify User can close the Add new stages pop up by clicking on cross icon", async({OpenApp,testData}) => {
      await allure.displayName('Verify User can close the Add new stages pop up by clicking on cross icon');
      await allure.owner('Shri Ram');
      await allure.tags('Access Rights Management');
      await allure.severity('High');

      const factory = OpenApp.getAccessRightsManagementPage();
      await factory.loginAsAdmin();
      await factory.NavigateSystemPreferences();
      await factory.NavigateToAccessRights();
    
      await factory.SelectAccessModule(Cards.EntityHierarchy);
      await factory.clickAddNewStage();
      await factory.CloseAddNewStage();
    //  await factory.AssertAddNewStageButton();
    });

    test("@Non-Smoke TC_AM_059 Verify Whether the Count in the Number of Approval stages decrease once user deletes the Stages ", async({OpenApp,testData}) => {
      await allure.displayName('Verify Whether the Count in the Number of Approval stages decrease once user deletes the Stages');
      await allure.owner('Shri Ram');
      await allure.tags('Access Rights Management');
      await allure.severity('Medium');

      const factory = OpenApp.getAccessRightsManagementPage();
      await factory.loginAsAdmin();
      await factory.NavigateSystemPreferences();
      await factory.NavigateToAccessRights();
    
      await factory.SelectAccessModule(Cards.EntityHierarchy);
      await factory.clickAddNewStage();
      await factory.noOFStage(testData.TC_AM_059.NoOfStages);
      await factory.DeleteNoOfStages(testData.TC_AM_059.NoOfStages);
      await factory.AssertNoOfApprovalStages("0");
    });

    test("@Non-Smoke TC_AM_060 Verify whether a 'No Data' message is displayed when no matching data is available. ", async({OpenApp,testData}) => {
      await allure.displayName('Verify whether a "No Data" message is displayed when no matching data is available.');
      await allure.owner('Shri Ram');
      await allure.tags('Access Rights Management');
      await allure.severity('Medium');

      const factory = OpenApp.getAccessRightsManagementPage();
      await factory.loginAsAdmin();
      await factory.NavigateSystemPreferences();
      await factory.NavigateToAccessRights();
    
      await factory.SelectAccessModule(Cards.EntityHierarchy);
      await factory.clickAddNewStage();
      await factory.noOFStage(testData.TC_AM_059.NoOfStages);
      await factory.ClickAssignPlusIcon();
      await factory.EnterValueInDropDown(testData.TC_AM_060.Username,testData.TC_AM_060.Username);
      await factory.sleep(4000);
      await factory.AssertNoDataIsDisplayed();
    });

    test("@Non-Smoke TC_AM_061 Verify whether the same user cannot be selected multiple times. ", async({OpenApp,testData}) => {
      await allure.displayName('Verify whether the same user cannot be selected multiple times.');
      await allure.owner('Shri Ram');
      await allure.tags('Access Rights Management');
      await allure.severity('Medium');

      const factory = OpenApp.getAccessRightsManagementPage();
      await factory.loginAsAdmin();
      await factory.NavigateSystemPreferences();
      await factory.NavigateToAccessRights();
    
      await factory.SelectAccessModule(Cards.EntityHierarchy);
      await factory.clickAddNewStage();
      await factory.noOFStage(testData.TC_AM_061.NoOfStages);
      await factory.ClickAssignPlusIcon();
      //await factory.pause();
      await factory.EnterValueInDropDown(testData.TC_AM_061.assignedUser, testData.TC_AM_061.UserName);
      await factory.GetAssignedUserCount();
      await factory.EnterValueInDropDown(testData.TC_AM_061.assignedUser2, testData.TC_AM_061.UserName);
      await factory.GetAssignedUserCount();
      
    });

    test("@Non-Smoke TC_AM_062 Verify whether the same user from a different role can be selected and the same user from the previous role is removed while editing the stages.", async({OpenApp,testData}) => {
      await allure.displayName(' Verify whether the same user from a different role can be selected and the same user from the previous role is removed while editing the stages.');
      await allure.owner('Shri Ram');
      await allure.tags('Access Rights Management');
      await allure.severity('High');

      const factory = OpenApp.getAccessRightsManagementPage();
      await factory.loginAsAdmin();
      await factory.NavigateSystemPreferences();
      await factory.NavigateToAccessRights();
      await factory.SelectAccessModule(Cards.RiskHierarchy);
      await factory.clickAddNewStage();
      
     // await factory.ClickAssignPlusIcon();
      const text = await factory.PreviousUser();
      await factory.EnterValueInDropDown(testData.TC_AM_061.assignedUser2, testData.TC_AM_061.UserName);
      const text2 = await factory.GetAssignedUserCount();
      await factory.AssertNotEqual(text,text2);

    });

    test("@Non-Smoke TC_AM_063 Verify that the dropdown displays results based on partial input (e.g., typing 'Risk' shows all matching roles/users).", async({OpenApp,testData}) => {
      await allure.displayName("Verify that the dropdown displays results based on partial input (e.g., typing 'Risk' shows all matching roles/users).");
      await allure.owner('Shri Ram');
      await allure.tags('Access Rights Management');
      await allure.severity('Medium');

      const factory = OpenApp.getAccessRightsManagementPage();
      await factory.loginAsAdmin();
      await factory.NavigateSystemPreferences();
      await factory.NavigateToAccessRights();
      await factory.SelectAccessModule(Cards.EntityHierarchy);
      await factory.clickAddNewStage();
      await factory.noOFStage(testData.TC_AM_061.NoOfStages);
      await factory.ClickAssignPlusIcon(); 
      await factory.EnterValueInDropDown(testData.TC_AM_063.assignedUser, testData.TC_AM_063.UserName);
    });

    test("@Non-Smoke TC_AM_064 Verify Whether the search works irrespective of case in the Assigned User Search Bar. ", async({OpenApp,testData}) => {
      await allure.displayName("Verify Whether the search works irrespective of case in the Assigned User Search Bar. ");
      await allure.owner('Shri Ram');
      await allure.tags('Access Rights Management');
      await allure.severity('Medium');

      const factory = OpenApp.getAccessRightsManagementPage();
      await factory.loginAsAdmin();
      await factory.NavigateSystemPreferences();
      await factory.NavigateToAccessRights();
      await factory.SelectAccessModule(Cards.EntityHierarchy);
      await factory.clickAddNewStage();
      await factory.noOFStage(testData.TC_AM_061.NoOfStages);
      await factory.ClickAssignPlusIcon(); 
      await factory.EnterValueInDropDown(testData.TC_AM_064.assignedUser, testData.TC_AM_064.UserName);
      await factory.VerifyCaseInsensitiveSearch(testData.TC_AM_064.assignedUser);
    });

    test("@Non-Smoke TC_AM_065 Verify whether the user can select 'No Approval Stages' and the previously added stages are removed.", async({OpenApp,testData}) => {
      await allure.displayName('Verify whether the user can select "No Approval Stages" and the previously added stages are removed.');
      await allure.owner('Shri Ram');
      await allure.tags('Access Rights Management');
      await allure.severity('High');

      const factory = OpenApp.getAccessRightsManagementPage();
      await factory.loginAsAdmin();
      await factory.NavigateSystemPreferences();
      await factory.NavigateToAccessRights();
      await factory.SelectAccessModule(Cards.EntityHierarchy);
      await factory.clickAddNewStage();

      await factory.NoApprovalStageRequireCheckBox();
      await factory.AssertStageNotDisplayed(testData.TC_AM_007.stageName)

    });

    test("@Non-Smoke TC_AM_066 Verify whether User can see 'Please Select' when he click on the plus icon in the Assigned Users/Roles", async({OpenApp,testData}) => {
      await allure.displayName('Verify whether User can see "Please Select" when he click on the plus icon in the Assigned Users/Roles');
      await allure.owner('Shri Ram');
      await allure.tags('Access Rights Management');
      await allure.severity('Medium');

      const factory = OpenApp.getAccessRightsManagementPage();
      await factory.loginAsAdmin();
      await factory.NavigateSystemPreferences();
      await factory.NavigateToAccessRights();
      await factory.SelectAccessModule(Cards.EntityHierarchy);
      await factory.clickAddNewStage();
     await factory.noOFStage(testData.TC_AM_061.NoOfStages);
      await factory.ClickAssignPlusIcon(); 
      await factory.IsElementDisplayed();
    });

    test("@Non-Smoke TC_AM_067 Verify whether User cannot save the record when only the Stage Name field is filled and the remaining fields are empty.", async({OpenApp,testData}) => {
      await allure.displayName('Verify whether User cannot save the record when only the Stage Name field is filled and the remaining fields are empty.');
      await allure.owner('Shri Ram');
      await allure.tags('Access Rights Management');
      await allure.severity('High');

      const factory = OpenApp.getAccessRightsManagementPage();
      await factory.loginAsAdmin();
      await factory.NavigateSystemPreferences();
      await factory.NavigateToAccessRights();
      await factory.SelectAccessModule(Cards.EntityHierarchy);
      await factory.clickAddNewStage();
      await factory.noOFStage(testData.TC_AM_061.NoOfStages);

      await factory.EnterStageName(testData.TC_AM_067.StageName);
      await factory.SaveButton();
      await factory.NegativeValidation();
    });

    test("@Non-Smoke TC_AM_068 Verify whether User cannot save the record when only the Assigned Users/Roles field is filled and the remaining fields are empty.", async({OpenApp,testData}) => {
      await allure.displayName('Verify whether User cannot save the record when only the Assigned Users/Roles field is filled and the remaining fields are empty.');
      await allure.owner('Shri Ram');
      await allure.tags('Access Rights Management');
      await allure.severity('High');

      const factory = OpenApp.getAccessRightsManagementPage();
      await factory.loginAsAdmin();
      await factory.NavigateSystemPreferences();
      await factory.NavigateToAccessRights();
      await factory.SelectAccessModule(Cards.EntityHierarchy);
      await factory.clickAddNewStage();
      await factory.noOFStage(testData.TC_AM_061.NoOfStages);

      await factory.ClickAssignPlusIcon(); 
      await factory.EnterValueInDropDown(testData.TC_AM_064.assignedUser, testData.TC_AM_064.UserName);
      await factory.SaveButton();
      await factory.NegativeValidation();
    });

    test("@Non-smoke TC_AM_069 Verify whether the entity modules are sorted in descending order based on Modified Date when the user clicks the Add New role.",async({OpenApp,testData}) => {
      await allure.displayName('Verify whether the entity modules are sorted in descending order based on Modified Date(oldest entity) when the user clicks the Add new Role');
      await allure.owner('Shri Ram');
      await allure.tags('Access Rights Management');
      await allure.severity('High');

      const factory = OpenApp.getAccessRightsManagementPage();
      await factory.loginAsAdmin();
      await factory.NavigateSystemPreferences();
      await factory.NavigateToAccessRights();

      await factory.SelectAccessModule(Cards.EntityHierarchy);
      await factory.clickAddNewRole();
      const EntityName : string | null = await factory.getElementName();
      await factory.VerifyDescendingSort(EntityName!);
       //await factory.clickSortButton();

    });

    test("@Non-Smoke TC_AM_070 Verify whether the entity modules are sorted in ascending order based on Modified Date when the user clicks the up arrow.", async({OpenApp,testData}) => {
      await allure.displayName("Verify whether the entity modules are sorted in ascending order based on Modified Date when the user clicks the up arrow.");
      await allure.owner('Shri Ram');
      await allure.tags('Access Rights Management');
      await allure.severity('High');

      const factory = OpenApp.getAccessRightsManagementPage();
      await factory.loginAsAdmin();
      await factory.NavigateSystemPreferences();
      await factory.NavigateToAccessRights();

      await factory.SelectAccessModule(Cards.EntityHierarchy);
      await factory.clickAddNewRole();
     // await factory.clickSortButton();  
     const EntityName : string | null = await factory.getElementName();
      await factory.VerifyAscendingSort(EntityName!);    
    });

    test("@Non-Smoke TC_AM_071 Verify whether User can check the Disable Refer Back To Initiator", async({OpenApp, testData}) => {
    await allure.displayName("Verify whether User can check the Disable Refer Back To Initiator");
    await allure.owner('Shri Ram');
    await allure.tags('Access Rights Management');
    await allure.severity('High');

    const factory = OpenApp.getAccessRightsManagementPage();
    await factory.loginAsAdmin();
    await factory.NavigateSystemPreferences();
    await factory.NavigateToAccessRights();

    await factory.SelectAccessModule(Cards.EntityHierarchy);
  
    await factory.clickAddNewStage();
    await factory.noOFStage(testData.TC_AM_010.NoOfStages);
    await factory.VerifyInitiatorChekBoxState();
    //pending
  });

  test("@Non-Smoke TC_AM_072 Verify whether User can Uncheck the Disable Refer Back To Initiator", async({OpenApp, testData}) => {
    await allure.displayName("Verify whether User can Uncheck the Disable Refer Back To Initiator");
    await allure.owner('Shri Ram');
    await allure.tags('Access Rights Management');
    await allure.severity('High');

    const factory = OpenApp.getAccessRightsManagementPage();
    await factory.loginAsAdmin();
    await factory.NavigateSystemPreferences();
    await factory.NavigateToAccessRights();

    await factory.SelectAccessModule(Cards.EntityHierarchy);
  
    await factory.clickAddNewStage();
    await factory.noOFStage(testData.TC_AM_010.NoOfStages);
    await factory.VerifyInitiatorChekBoxState();
    await factory.VerifyUncheckInitiatorCheckBoxState();
  });

  test("@Non-Smoke TC_AM_073 Verify whether User can check the Disable Refer Back To Initiator", async({OpenApp, testData}) => {
    await allure.displayName("Verify whether User can check the Disable Refer Back To Initiator");
    await allure.owner('Shri Ram');
    await allure.tags('Access Rights Management');
    await allure.severity('High');

    const factory = OpenApp.getAccessRightsManagementPage();
    await factory.loginAsAdmin();
    await factory.NavigateSystemPreferences();
    await factory.NavigateToAccessRights();

    await factory.SelectAccessModule(Cards.EntityHierarchy);
  
    await factory.clickAddNewStage();
    await factory.noOFStage(testData.TC_AM_010.NoOfStages);
    await factory.VerifyReferBackChekBoxState();
    //pending
  });

  test("@Non-Smoke TC_AM_074 Verify whether User can Uncheck the Disable Refer Back", async({OpenApp, testData}) => {
    await allure.displayName("Verify whether User can Uncheck the Disable Refer Back");
    await allure.owner('Shri Ram');
    await allure.tags('Access Rights Management');
    await allure.severity('High');

    const factory = OpenApp.getAccessRightsManagementPage();
    await factory.loginAsAdmin();
    await factory.NavigateSystemPreferences();
    await factory.NavigateToAccessRights();

    await factory.SelectAccessModule(Cards.EntityHierarchy);
  
    await factory.clickAddNewStage();
    await factory.noOFStage(testData.TC_AM_010.NoOfStages);
    await factory.VerifyReferBackChekBoxState();
    await factory.VerifyUncheckReferBackCheckBoxState();
  });

   test("@Non-Smoke TC_AM_075 Verify whether User can check the Disable Form Edit", async({OpenApp, testData}) => {
    await allure.displayName("Verify whether User can check the Disable Form Edit");
    await allure.owner('Shri Ram');
    await allure.tags('Access Rights Management');
    await allure.severity('High');

    const factory = OpenApp.getAccessRightsManagementPage();
    await factory.loginAsAdmin();
    await factory.NavigateSystemPreferences();
    await factory.NavigateToAccessRights();

    await factory.SelectAccessModule(Cards.EntityHierarchy);
  
    await factory.clickAddNewStage();
    await factory.noOFStage(testData.TC_AM_010.NoOfStages);
    await factory.VerifyFormEditChekBoxState();
    //pending
  });

  test("@Non-Smoke TC_AM_076 Verify whether User can Uncheck the Disable Form Edit", async({OpenApp, testData}) => {
    await allure.displayName("Verify whether User can Uncheck the Disable Form Edit");
    await allure.owner('Shri Ram');
    await allure.tags('Access Rights Management');
    await allure.severity('High');

    const factory = OpenApp.getAccessRightsManagementPage();
    await factory.loginAsAdmin();
    await factory.NavigateSystemPreferences();
    await factory.NavigateToAccessRights();

    await factory.SelectAccessModule(Cards.EntityHierarchy);
  
    await factory.clickAddNewStage();
    await factory.noOFStage(testData.TC_AM_010.NoOfStages);
    await factory.VerifyFormEditChekBoxState();
    await factory.VerifyUncheckFormEditCheckBoxState();
  });

  test("@Non-Smoke TC_AM_077 Verify whether User can check the Delegate Check box", async({OpenApp,testData}) => {
    await allure.displayName("Verify whether User can check the Delegate Check box");
    await allure.owner('Shri Ram');
    await allure.tags('Access Rights Management');
    await allure.severity('Medium');

    const factory = OpenApp.getAccessRightsManagementPage();
    await factory.loginAsAdmin();
    await factory.NavigateSystemPreferences();
    await factory.NavigateToAccessRights();

    await factory.SelectAccessModule(Cards.EntityHierarchy);
  
    await factory.clickAddNewStage();
    await factory.noOFStage(testData.TC_AM_010.NoOfStages);
    await factory.VerifyFormEditCheckDelegate();
  });

  test("@Non-Smoke TC_AM_078 Verify whether User can Uncheck the Checked Delegate Check box", async({OpenApp,testData}) => {
    await allure.displayName("Verify whether User can Uncheck the Checked Delegate Check box");
    await allure.owner('Shri Ram');
    await allure.tags('Access Rights Management');
    await allure.severity('Medium');

    const factory = OpenApp.getAccessRightsManagementPage();
    await factory.loginAsAdmin();
    await factory.NavigateSystemPreferences();
    await factory.NavigateToAccessRights();

    await factory.SelectAccessModule(Cards.EntityHierarchy);
  
    await factory.clickAddNewStage();
    await factory.noOFStage(testData.TC_AM_010.NoOfStages);
    await factory.VerifyFormEditCheckDelegate();
    await factory.VerifyUncheckFormEditCheckDelegate();
  });

  test("@Non-Smoke TC_AM_079 Verify whether the Delegate checkbox is disabled when the user selects the Unanimous Approval checkbox.", async({OpenApp,testData}) => {
    await allure.displayName("Verify whether the Delegate checkbox is disabled when the user selects the Unanimous Approval checkbox.");
    await allure.owner('Shri Ram');
    await allure.tags('Access Rights Management');
    await allure.severity('High');

    const factory = OpenApp.getAccessRightsManagementPage();
    await factory.loginAsAdmin();
    await factory.NavigateSystemPreferences();
    await factory.NavigateToAccessRights();

    await factory.SelectAccessModule(Cards.EntityHierarchy);
  
    await factory.clickAddNewStage();
    await factory.noOFStage(testData.TC_AM_010.NoOfStages);
    await factory.VerifyUnanimousapprovalChekBoxState();
    await factory.IsDelegateCheckBoxDisabled();
  });

  test("@Non-Smoke TC_AM_080 Verify whether the Delegate checkbox is Enabled when the user selects the checked Unanimous Approval checkbox.", async({OpenApp,testData}) => {
    await allure.displayName("Verify whether the Delegate checkbox is disabled when the user selects the checked Unanimous Approval checkbox.");
    await allure.owner('Shri Ram');
    await allure.tags('Access Rights Management');
    await allure.severity('High');

    const factory = OpenApp.getAccessRightsManagementPage();
    await factory.loginAsAdmin();
    await factory.NavigateSystemPreferences();
    await factory.NavigateToAccessRights();

    await factory.SelectAccessModule(Cards.EntityHierarchy);
  
    await factory.clickAddNewStage();
    await factory.noOFStage(testData.TC_AM_010.NoOfStages);
    await factory.VerifyUnanimousapprovalChekBoxState();
    await factory.VerifyUnanimousapprovalUnChekBoxState();
    await factory.IsDelegateCheckBoxEnabled();
  });

  test("@Non-Smoke TC_AM_081 Verify whether the user can toggle(OFF) the “Enable delegate for initiator” switch.", async({OpenApp,testData}) => {
    await allure.displayName("Verify whether the user can toggle(OFF) the “Enable delegate for initiator” switch.");
    await allure.owner('Shri Ram');
    await allure.tags('Access Rights Management');
    await allure.severity('High');

    const factory = OpenApp.getAccessRightsManagementPage();
    await factory.loginAsAdmin();
    await factory.NavigateSystemPreferences();
    await factory.NavigateToAccessRights();

     await factory.SelectAccessModule(Cards.RA);
    await factory.clickAddNewStage();
   // await factory.ActiveToggleButton();
    await factory.InActiveToggleButton();
  });

  test("@Non-Smoke TC_AM_082 Verify whether the user can toggle(ON) the “Enable delegate for initiator” switch.", async({OpenApp,testData}) => {
    await allure.displayName("Verify whether the user can toggle(ON) the “Enable delegate for initiator” switch.");
    await allure.owner('Shri Ram');
    await allure.tags('Access Rights Management');
    await allure.severity('High');

    const factory = OpenApp.getAccessRightsManagementPage();
    await factory.loginAsAdmin();
    await factory.NavigateSystemPreferences();
    await factory.NavigateToAccessRights();

    await factory.SelectAccessModule(Cards.RA);
    await factory.clickAddNewStage();
    await factory.ActiveToggleButton();
   // await factory.InActiveToggleButton();
  });

  test("@Non-Smoke TC_AM_083 Verify whether the 'Enable Delegate' toggle button is unchecked when the user clicks on 'No Approval Stages Required'.", async({OpenApp,testData}) => {
    await allure.displayName("Verify whether the 'Enable Delegate' toggle button is unchecked when the user clicks on 'No Approval Stages Required'.");
    await allure.owner('Shri Ram');
    await allure.tags('Access Rights Management');
    await allure.severity('High');

    const factory = OpenApp.getAccessRightsManagementPage();
    await factory.loginAsAdmin();
    await factory.NavigateSystemPreferences();
    await factory.NavigateToAccessRights();

    await factory.SelectAccessModule(Cards.RA);
    await factory.clickAddNewStage();

    await factory.NoApprovalStageRequireCheckBox();
    await factory.AssertToggleState();
  });

  test("@Non-Smoke TC_AM_084 Verify whether user can't add same role to the Module twice", async({OpenApp, testData}) => {
    await allure.displayName("Verify whether user can't add same role to the Module twice");
    await allure.owner('Shri Ram');
    await allure.tags('Access Rights Management');
    await allure.severity("Medium");

    const factory = OpenApp.getAccessRightsManagementPage();
    await factory.loginAsAdmin();
    await factory.NavigateSystemPreferences();
    await factory.NavigateToAccessRights();

    await factory.SelectAccessModule(Cards.EntityHierarchy);
    await factory.clickAddNewRole();

  });

  test("@Non-Smoke TC_AM_085 Verify whether user can see the Newly Added stages for BIA under BIA Card in Application", async({OpenApp,testData}) => {
    await allure.displayName("Verify whether user can see the Newly Added stages for BIA under BIA Card in Application");
    await allure.owner('Shri Ram');
    await allure.tags('Access Rights Management');
    await allure.severity('High');

    const factory = OpenApp.getAccessRightsManagementPage();
    await factory.loginAsPoweruser('ReneDes');
    await factory.ClickOnApplication();

    await factory.ClickBIACard();
    await factory.VerifyBIAFields();
  });

  test("@Non-Smoke TC_AM_086 Verify whether user can see the Newly Added stages for IT BIA under BIA Card in Application", async({OpenApp,testData}) => {
    await allure.displayName("Verify whether user can see the Newly Added stages for IT BIA under BIA Card in Application");
    await allure.owner('Shri Ram');
    await allure.tags('Access Rights Management');
    await allure.severity('High');

    const factory = OpenApp.getAccessRightsManagementPage();
    await factory.loginAsPoweruser('ReneDes');
    await factory.ClickOnApplication();

    await factory.ClickBIACard();
    await factory.VerifyBIAFields();
  });

  // test("@Non-Smoke TC_AM_087 Verify that the Finish and Delegate button is visible for users with the Primary SPOC role.", async({OpenApp,testData}) => {
  //   await allure.displayName("Verify that the Finish and Delegate button is visible for users with the Primary SPOC role.");
  //   await allure.owner('Shri Ram');
  //   await allure.tags('Access Rights Management');
  //   await allure.severity('High');

  //   const factory = OpenApp.getAccessRightsManagementPage();
  //   await factory.loginAsPoweruser('SuryaPWD');
  //   await factory.ClickOnApplication();
  //   await factory.ClickRACard();

  //   // await factory.ClickNew();
  //   // await factory.IsFinishAndDelegateVisible();
  //   await factory.ClickRARecord();
  //   await factory.sleep(4000);
  //   await factory.ClickRiskDetails();
  //   await factory.sleep(4000);
  //   await factory.ClickEdit();
  //   await factory.sleep(5000);
  //   await factory.IsFinishAndDelegateVisible();
  // });

  // test("@Non-Smoke TC_AM_088 Verify whether the Finish and Delegate button is visible for the User who is a Primary SPOC", async({OpenApp,testData}) => {
  //   await allure.displayName("Verify whether the Finish and Delegate button is visible for the User who is a Primary SPOC");
  //   await allure.owner('Shri Ram');
  //   await allure.tags('Access Rights Management');
  //   await allure.severity('High');

  //   const factory = OpenApp.getAccessRightsManagementPage();
  //   await factory.loginAsPoweruser('SuryaPWD');
  //   await factory.ClickOnApplication();
  //   await factory.ClickRACard();

  //   // await factory.ClickNew();
  //   // await factory.IsFinishAndDelegateVisible();
  //   await factory.ClickRARecord();
  //   await factory.sleep(4000);
  //   await factory.ClickRiskDetails();
  //   await factory.sleep(4000);
  //   await factory.ClickEdit();
  //   await factory.sleep(5000);
  //   await factory.IsFinishAndDelegateNotVisible();
  // });

  // test("@Non-Smoke TC_AM_089 Verify whether the Initiator option is visible to Assigned user under particular stages", async({OpenApp,testData}) => {
  //   await allure.displayName("Verify whether the Initiator option is visible to Assigned user under particular stages");
  //   await allure.owner("Shri Ram");
  //   await allure.tags('Access Rights Management');
  //   await allure.severity('High');

  //   const factory = OpenApp.getAccessRightsManagementPage();
  //   await factory.loginAsPoweruser('Seema');
  //   await factory.ClickOnApplication();
  //   await factory.sleep(4000);
  //   await factory.ClickActionCentre();
  //   await factory.sleep(4000);
  //   await factory.ClickUpComing();
  //   await factory.sleep(4000);
  //   await factory.ClickRiskRecord(testData.TC_AM_089.TaskNo);
  //   await factory.sleep(4000);
  //   await factory.ClickReviewerAction();
  //   await factory.sleep(4000);
  //   await factory.ClickNeedForCorrection();
  //   await factory.AssertNeedsCorrectionSelected();
  //   await factory.IsInitiatorButtonDisplayed();
    
  // });

  // test("@Non-Smoke TC_AM_090 Verify whether the Initiator option is not visible to Assigned user under particular stages", async({OpenApp,testData}) => {
  //   await allure.displayName("Verify whether the Initiator option is not visible to Assigned user under particular stages");
  //   await allure.owner("Shri Ram");
  //   await allure.tags('Access Rights Management');
  //   await allure.severity('High');

  //   const factory = OpenApp.getAccessRightsManagementPage();
  //   await factory.loginAsPoweruser('Seema');
  //   await factory.ClickOnApplication();
  //   await factory.sleep(4000);
  //   await factory.ClickActionCentre();
  //   await factory.sleep(4000);
  //   await factory.ClickUpComing();
  //   await factory.sleep(4000);
  //   await factory.ClickRiskRecord(testData.TC_AM_090.TaskNo);
  //   await factory.sleep(4000);
  //   await factory.ClickReviewerAction();
  //   await factory.sleep(4000);
  //   await factory.IsNeedsCorrectionNotDisplayed();
  //   // await factory.AssertNeedsCorrectionSelected();
  //   // await factory.IsInitiatorButtonDisplayed();
  // });

  // test("@Non-Smoke TC_AM_091 Verify that the Delegate To option is visible for the stage user when the Delegate option is enabled for that stage.", async({OpenApp,testData}) => {
  //   await allure.displayName("Verify that the Delegate To option is visible for the stage user when the Delegate option is enabled for that stage.");
  //   await allure.owner('Shri Ram');
  //   await allure.tags('Access Rights Management');
  //   await allure.severity('High');

  //   const factory = OpenApp.getAccessRightsManagementPage();
  //   await factory.loginAsPoweruser('Seema');
  //   await factory.ClickOnApplication();
  //   await factory.sleep(4000);
  //   await factory.ClickActionCentre();
  //   await factory.sleep(4000);
  //   await factory.ClickUpComing();
  //   await factory.sleep(4000);
  //   await factory.ClickRiskRecord(testData.TC_AM_091.TaskNo);
  //   await factory.sleep(4000);
  //   await factory.ClickReviewerAction();
  //   await factory.sleep(4000);
  //   await factory.ClickDelegate();
  //   await factory.sleep(4000);
  //   await factory.IsDelegateToVisible();
  // });




  test.afterEach("Logout",async ({OpenApp}) => {
    const factory = OpenApp.getAccessRightsManagementPage();
    //await factory.Log.logout();
  });


  // test.afterAll("Close the browser",async ({closeApp}) => {
  //   await closeApp();
  // });

});   
