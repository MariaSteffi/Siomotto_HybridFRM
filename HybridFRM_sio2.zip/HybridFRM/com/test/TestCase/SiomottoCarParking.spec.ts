import { test } from "@playwright/test";
import SiomottoHomePage from "../../src/ui/pages/SiomottoHomePage";
import SiomottoCarParkingPage from "../../src/ui/pages/SiomottoCarParkingPage";
import SiomottoLoginPage from "../../src/ui/pages/SiomottoLoginPage";
import data from "../../src/Resources/SiomottoTestData.json";

const d = data.carParking;
test.setTimeout(240000);

test.describe("Car Parking - without login", () => {
  test.beforeEach(async ({ page }) => {
    const home = new SiomottoHomePage(page);
    await home.open();
    await home.selectLocation(data.city, data.cityResult);
    await home.openCategory(d.category);
    await new SiomottoCarParkingPage(page).searchLocation(d.location, d.suggestion);
  });

  test("CP_001 Common steps work: location, Car Parking, search location", async ({ page }) => {
    const parking = new SiomottoCarParkingPage(page);
    await parking.verifyPageLoaded();
    await parking.verifyLocationSelected(d.location);
  });

  test("CP_002 Min and Max price with Apply shows results", async ({ page }) => {
    const parking = new SiomottoCarParkingPage(page);
    await parking.applyPrice(d.min, d.max);
    await parking.verifyPriceValues(d.min, d.max);
    await parking.verifyResultsShown();
  });

  test("CP_003 Min price greater than Max price gives no results", async ({ page }) => {
    const parking = new SiomottoCarParkingPage(page);
    await parking.applyPrice(d.badMin, d.badMax);
    await parking.verifyNoResults();
  });

  test("CP_004 View Owner Contact asks for login", async ({ page }) => {
    const parking = new SiomottoCarParkingPage(page);
    await parking.applyPrice(d.min, d.max);
    await parking.clickViewContact();
    await parking.verifyLoginRequired();
  });
});

test("CP_005 View Owner Contact shows details after login", async ({ page }) => {
  const home = new SiomottoHomePage(page);
  await home.open();
  await new SiomottoLoginPage(page).loginAsUser();
  await home.selectLocation(data.city, data.cityResult);
  await home.openCategory(d.category);
  const parking = new SiomottoCarParkingPage(page);
  await parking.searchLocation(d.location, d.suggestion);
  await parking.applyPrice(d.min, d.max);
  await parking.clickViewContact();
  await parking.verifyContactDetailsShown();
});